"""MIDI parser. Splits notes by program for correct per-instrument rendering."""
import mido

MAX_PEDAL_SUSTAIN = 5.0


def _tempo_map(mid):
    evts = []
    for tr in mid.tracks:
        tick = 0
        for msg in tr:
            tick += msg.time
            if msg.type == "set_tempo":
                evts.append((tick, msg.tempo))
    evts.sort()
    if not evts or evts[0][0] != 0:
        evts.insert(0, (0, 500000))
    return evts


def _tick2sec(tick, tmap, tpb):
    sec, pt, pp = 0.0, 0, tmap[0][1]
    for tk, tp in tmap[1:]:
        if tk >= tick:
            break
        sec += (tk - pt) / tpb * pp / 1e6
        pt, pp = tk, tp
    return sec + (tick - pt) / tpb * pp / 1e6


def parse(path):
    mid = mido.MidiFile(path)
    tmap = _tempo_map(mid)
    all_notes = []

    for track in mid.tracks:
        on, on_vel = {}, {}
        pedal, held = {}, {}
        tick, progs, cpan = 0, {}, {}
        notes = []

        for msg in track:
            tick += msg.time
            t = _tick2sec(tick, tmap, mid.ticks_per_beat)
            ch = msg.channel if hasattr(msg, "channel") else 0
            if msg.type == "program_change":
                progs[ch] = msg.program
            elif msg.type == "control_change":
                if msg.control == 64:
                    if msg.value >= 64:
                        pedal[ch] = True
                    else:
                        pedal[ch] = False
                        for nn, st, vl in held.pop(ch, []):
                            d = min(max(t - st, 0.01), MAX_PEDAL_SUSTAIN)
                            notes.append((st, nn, d, vl, ch, progs.get(ch, 0)))
                elif msg.control == 10:
                    cpan[ch] = msg.value
            elif msg.type == "note_on" and msg.velocity > 0:
                key = (ch, msg.note)
                if key in on:
                    d = max(t - on[key], 0.01)
                    notes.append((on[key], msg.note, d, on_vel[key], ch, progs.get(ch, 0)))
                on[key] = t
                on_vel[key] = msg.velocity / 127.0
            elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
                key = (ch, msg.note)
                if key in on:
                    st, vl = on.pop(key), on_vel.pop(key)
                    if pedal.get(ch):
                        held.setdefault(ch, []).append((msg.note, st, vl))
                    else:
                        notes.append((st, msg.note, max(t - st, 0.01), vl, ch, progs.get(ch, 0)))

        end = _tick2sec(tick, tmap, mid.ticks_per_beat)
        for ch_, hl in held.items():
            for nn, st, vl in hl:
                notes.append((st, nn, min(max(end - st, 0.01), MAX_PEDAL_SUSTAIN), vl, ch_, progs.get(ch_, 0)))
        for (ci, nn), st in list(on.items()):
            notes.append((st, nn, max(end - st, 0.01), on_vel[(ci, nn)], ci, progs.get(ci, 0)))

        # split by program so each instrument gets its own track
        by_prog = {}
        for note in notes:
            by_prog.setdefault(note[5], []).append(note)
        for prog in sorted(by_prog):
            pn = by_prog[prog]
            all_notes.append((pn, cpan.get(pn[0][4])))

    tracks = [t for t, _ in all_notes]
    pans = [p for _, p in all_notes]
    return tracks, pans
