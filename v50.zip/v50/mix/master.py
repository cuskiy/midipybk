import numpy as np
from synth.timbre import SR

_H8_S = 1.0 / 8.0 ** 0.5


def fdn_reverb_ir(room_size=1.0, rt60=1.6, damping=0.3, dur=None):
    if dur is None:
        dur = min(rt60 * 1.5, 3.0)
    n = int(SR * dur)
    primes = [743, 829, 911, 1013, 1109, 1213, 1321, 1429]
    delays = [max(int(p * room_size), 1) for p in primes]
    g0, g1, g2, g3, g4, g5, g6, g7 = [
        10 ** (-3 * d / (SR * max(rt60, 0.1))) for d in delays
    ]
    b0, b1, b2, b3 = np.zeros(delays[0]), np.zeros(delays[1]), np.zeros(delays[2]), np.zeros(delays[3])
    b4, b5, b6, b7 = np.zeros(delays[4]), np.zeros(delays[5]), np.zeros(delays[6]), np.zeros(delays[7])
    d0, d1, d2, d3, d4, d5, d6, d7 = delays
    p0 = p1 = p2 = p3 = p4 = p5 = p6 = p7 = 0
    f0 = f1 = f2 = f3 = f4 = f5 = f6 = f7 = 0.0
    ir_l, ir_r = np.zeros(n), np.zeros(n)
    di = 1.0 - damping
    dm = damping
    s8 = _H8_S

    for i in range(n):
        o0 = b0[p0]; o1 = b1[p1]; o2 = b2[p2]; o3 = b3[p3]
        o4 = b4[p4]; o5 = b5[p5]; o6 = b6[p6]; o7 = b7[p7]
        a0 = o0+o1; a1 = o0-o1; a2 = o2+o3; a3 = o2-o3
        a4 = o4+o5; a5 = o4-o5; a6 = o6+o7; a7 = o6-o7
        c0 = a0+a2; c1 = a1+a3; c2 = a0-a2; c3 = a1-a3
        c4 = a4+a6; c5 = a5+a7; c6 = a4-a6; c7 = a5-a7
        m0 = (c0+c4)*s8; m1 = (c1+c5)*s8; m2 = (c2+c6)*s8; m3 = (c3+c7)*s8
        m4 = (c0-c4)*s8; m5 = (c1-c5)*s8; m6 = (c2-c6)*s8; m7 = (c3-c7)*s8
        f0 = di*m0+dm*f0; f1 = di*m1+dm*f1; f2 = di*m2+dm*f2; f3 = di*m3+dm*f3
        f4 = di*m4+dm*f4; f5 = di*m5+dm*f5; f6 = di*m6+dm*f6; f7 = di*m7+dm*f7
        if i == 0:
            f0 += s8; f1 += s8; f2 += s8; f3 += s8
            f4 += s8; f5 += s8; f6 += s8; f7 += s8
        b0[p0] = f0*g0; b1[p1] = f1*g1; b2[p2] = f2*g2; b3[p3] = f3*g3
        b4[p4] = f4*g4; b5[p5] = f5*g5; b6[p6] = f6*g6; b7[p7] = f7*g7
        p0 += 1; p1 += 1; p2 += 1; p3 += 1; p4 += 1; p5 += 1; p6 += 1; p7 += 1
        if p0 >= d0: p0 = 0
        if p1 >= d1: p1 = 0
        if p2 >= d2: p2 = 0
        if p3 >= d3: p3 = 0
        if p4 >= d4: p4 = 0
        if p5 >= d5: p5 = 0
        if p6 >= d6: p6 = 0
        if p7 >= d7: p7 = 0
        ir_l[i] = o0+o2+o4+o6
        ir_r[i] = o1+o3+o5+o7
    return ir_l, ir_r


def compress(l, r, thresh=0.55, ratio=2.0, att_ms=25, rel_ms=120):
    n = len(l)
    lk = np.maximum(np.abs(l), np.abs(r))
    ca = np.exp(-1 / max(int(SR * att_ms / 1000), 1))
    cr = np.exp(-1 / max(int(SR * rel_ms / 1000), 1))
    BLK = 64
    nb = (n + BLK - 1) // BLK
    padded = np.pad(lk, (0, nb * BLK - n), constant_values=0)
    blk_peaks = padded.reshape(nb, BLK).max(axis=1)
    env_blk = np.empty(nb)
    env_blk[0] = blk_peaks[0]
    for i in range(1, nb):
        cb = (ca if blk_peaks[i] > env_blk[i - 1] else cr) ** BLK
        env_blk[i] = cb * env_blk[i - 1] + (1 - cb) * blk_peaks[i]
    env = np.repeat(env_blk, BLK)[:n]
    g = np.ones(n)
    m = env > thresh
    g[m] = (thresh + (env[m] - thresh) / ratio) / env[m]
    return l * g, r * g
