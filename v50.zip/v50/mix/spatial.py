import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt
from synth.timbre import SR

HEAD_R = 0.0875
C_SOUND = 343.0

_PINNA_SOS = None
_ER_HP = None

_ER_TAPS = [
    (0.011, 0.25, -48),
    (0.020, 0.25,  50),
    (0.031, 0.18,  35),
    (0.041, 0.18, -40),
    (0.054, 0.10,  -8),
]


def _ensure_pinna():
    global _PINNA_SOS
    if _PINNA_SOS is None:
        w0 = 2 * np.pi * 7000.0 / SR
        q, depth = 2.5, 2.8
        A = 10 ** (-depth / 40.0)
        alpha = np.sin(w0) / (2 * q)
        b0 = 1 + alpha * A; b1 = -2 * np.cos(w0); b2 = 1 - alpha * A
        a0 = 1 + alpha / A; a1 = b1; a2 = 1 - alpha / A
        _PINNA_SOS = np.array([[b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]])


def _ensure_er_hp():
    global _ER_HP
    if _ER_HP is None:
        _ER_HP = butter(2, 180.0, btype='high', fs=SR, output='sos')


def apply_hrtf(mono, az_deg, length=64, pinna=False):
    if abs(az_deg) < 0.5:
        return mono.copy(), mono.copy()
    az = np.radians(az_deg)
    sa = abs(np.sin(az))
    itd = abs(HEAD_R / C_SOUND * (az + np.sin(az)))
    gn = 10 ** (abs(1.5 * np.sin(az)) / 20)
    gf = 10 ** (-abs(1.5 * np.sin(az)) / 20)
    near, far = np.zeros(length), np.zeros(length)
    near[0] = 1.0
    ds = itd * SR
    d0 = min(int(ds), length - 2)
    frac = ds - d0
    far[d0] = 1 - frac
    if d0 + 1 < length:
        far[d0 + 1] = frac
    fc = 8000 - 3500 * sa
    if sa > 0.05 and fc < SR * 0.45:
        far = sosfilt(butter(1, fc, btype='low', fs=SR, output='sos'), far)
    near *= gn
    far *= gf
    if pinna and sa > 0.1:
        _ensure_pinna()
        far = sosfilt(_PINNA_SOS, far)
    li, ri = (far, near) if az_deg >= 0 else (near, far)
    nn = len(mono)
    return fftconvolve(mono, li, mode='full')[:nn], fftconvolve(mono, ri, mode='full')[:nn]


def early_reflections(ml, mr):
    _ensure_er_hp()
    mono = (ml + mr) * 0.5
    n = len(ml)
    ol, or_ = np.zeros(n), np.zeros(n)
    for delay, gain, az in _ER_TAPS:
        l, r = apply_hrtf(mono, az)
        d = int(delay * SR)
        if d < n:
            ol[d:] += l[:n - d] * gain
            or_[d:] += r[:n - d] * gain
    return sosfilt(_ER_HP, ol), sosfilt(_ER_HP, or_)
