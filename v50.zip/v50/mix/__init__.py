"""Render pipeline: synth → split-by-program → per-track HP+norm → HRTF → reverb → compress."""
import numpy as np
import soundfile as sf
from collections import defaultdict
from scipy.signal import fftconvolve, butter, sosfilt

from synth import SR, A4, TIMBRES, PROGRAM_MAP, PANNING
from synth.gm import VOLUME, HP_FREQ
from synth import synthesize, drum
from .spatial import apply_hrtf, early_reflections
from .master import fdn_reverb_ir, compress

PIPELINE = dict(
    target_rms=0.15, track_peak_cap=2.5,
    reverb_wet=0.045, reverb_rt60=1.6, reverb_room=1.0, reverb_predelay=0,
    comp_thresh=0.55, comp_ratio=2.0, comp_att_ms=25, comp_rel_ms=120,
    peak_limit=0.92,
    az_scale=1.0, er_wet=0, pinna=False,
)

SPATIAL = dict(
    az_scale=1.12, er_wet=0.08, pinna=True,
    reverb_wet=0.055, reverb_rt60=1.8, reverb_predelay=0.018,
)

_IR_CACHE = {}
_HP_MASTER = None
_HP_CACHE = {}


def _get_ir(room, rt60):
    key = (round(room, 4), round(rt60, 4))
    if key not in _IR_CACHE:
        print("  generating reverb IR...", end="", flush=True)
        il, ir = fdn_reverb_ir(room_size=room, rt60=rt60)
        rv_hp = butter(2, 120.0, btype='high', fs=SR, output='sos')
        il, ir = sosfilt(rv_hp, il), sosfilt(rv_hp, ir)
        e = max(np.sqrt(np.sum(il**2)), np.sqrt(np.sum(ir**2)), 1e-10)
        _IR_CACHE[key] = (il / e, ir / e)
        print(" done")
    return _IR_CACHE[key]


def _ensure_hp_master():
    global _HP_MASTER
    if _HP_MASTER is None:
        _HP_MASTER = butter(3, 20.0, btype='high', fs=SR, output='sos')


def _get_hp(freq):
    key = int(freq)
    if key not in _HP_CACHE:
        _HP_CACHE[key] = butter(2, max(freq, 20.0), btype='high', fs=SR, output='sos')
    return _HP_CACHE[key]


def _tail_estimate(tb, dur):
    if dur >= 0.2:
        return min(tb.rel * 1.2 + 0.15, 2.5)
    return min(tb.rel + 0.20, 1.0)


def _split_tracks(tracks, pans):
    subs = []
    for ti, notes in enumerate(tracks):
        if not notes:
            continue
        pan_cc = pans[ti] if ti < len(pans) else None
        by_name = defaultdict(list)
        for note in notes:
            nm = "drums" if note[4] == 9 else PROGRAM_MAP.get(note[5], "default")
            by_name[nm].append(note)
        for nm, sub in by_name.items():
            subs.append((nm, sub, pan_cc))
    return subs


def render(tracks, track_pans, out_file, spatial=False):
    P = dict(PIPELINE)
    if spatial:
        P.update(SPATIAL)
    irl, irr = _get_ir(P['reverb_room'], P['reverb_rt60'])
    _ensure_hp_master()
    sub_tracks = _split_tracks(tracks, track_pans)
    mx = 0
    for nm, notes, _ in sub_tracks:
        tb = TIMBRES.get(nm, TIMBRES["default"])
        for st, note, dur, vel, ch, prog in notes:
            e = int((st + dur + _tail_estimate(tb, dur)) * SR) + SR
            if e > mx:
                mx = e
    mx += SR
    ml, mr = np.zeros(mx), np.zeros(mx)
    used_az = set()
    az_sc = P['az_scale']
    use_pinna = P['pinna']

    for ti, (tn, notes, pan_cc) in enumerate(sub_tracks):
        nn = len(notes)
        print(f"  [{ti+1}/{len(sub_tracks)}] {tn:<12s} {nn:>4d} notes", flush=True)
        buf = np.zeros(mx)
        drng = np.random.RandomState(42 + ti)
        for ni, (st, note, dur, vel, ch, prog) in enumerate(notes):
            if ch == 9:
                tone = drum(note, dur, vel, drng)
            else:
                nm = PROGRAM_MAP.get(prog, "default")
                tb = TIMBRES.get(nm, TIMBRES["default"])
                tone = synthesize(A4 * 2 ** ((note - 69) / 12.0), dur, vel, tb, nm, ni)
            s = int(st * SR)
            e = min(s + len(tone), mx)
            buf[s:e] += tone[:e - s]

        hp_f = HP_FREQ.get(tn, 60.0)
        buf = sosfilt(_get_hp(hp_f), buf)

        rms = np.sqrt(np.mean(buf * buf))
        if rms > 1e-6:
            buf *= P['target_rms'] / rms
        vol = VOLUME.get(tn, 1.0)
        if vol != 1.0:
            buf *= vol
        pk = np.max(np.abs(buf))
        if pk > P['track_peak_cap']:
            buf *= P['track_peak_cap'] / pk

        if pan_cc is not None:
            az = (pan_cc - 64) / 64.0 * 55.0
        elif tn == "drums":
            az = 0.0
        else:
            az = PANNING.get(tn, 0)
            if az in used_az:
                for off in [8, -8, 16, -16]:
                    c = az + off
                    if abs(c) <= 60 and c not in used_az:
                        az = c
                        break
            used_az.add(az)
        az = np.clip(az * az_sc, -65, 65)
        l, r = apply_hrtf(buf, az, pinna=use_pinna)
        ml += l
        mr += r

    if sub_tracks:
        ml = sosfilt(_HP_MASTER, ml)
        mr = sosfilt(_HP_MASTER, mr)

        er_w = P['er_wet']
        if er_w > 0:
            erl, err = early_reflections(ml, mr)
            ml += erl * er_w
            mr += err * er_w

        wet = P['reverb_wet']
        dry = 1 - wet
        pd = int(P['reverb_predelay'] * SR)
        use_irl = np.concatenate([np.zeros(pd), irl]) if pd > 0 else irl
        use_irr = np.concatenate([np.zeros(pd), irr]) if pd > 0 else irr
        ml = ml * dry + fftconvolve(ml, use_irl, mode='full')[:mx] * wet
        mr = mr * dry + fftconvolve(mr, use_irr, mode='full')[:mx] * wet
        ml, mr = compress(ml, mr, P['comp_thresh'], P['comp_ratio'],
                          P['comp_att_ms'], P['comp_rel_ms'])
        pk = max(np.max(np.abs(ml)), np.max(np.abs(mr)), 1e-10)
        ml *= P['peak_limit'] / pk
        mr *= P['peak_limit'] / pk

    sf.write(out_file, np.clip(np.column_stack((ml, mr)), -1, 1),
             SR, format="FLAC", subtype="PCM_24")
    print(f"  {out_file}  ({mx/SR:.1f}s, {len(sub_tracks)} sub-tracks)")
