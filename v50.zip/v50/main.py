"""v50 MIDI synthesizer — entry point."""
import argparse, os


def main():
    p = argparse.ArgumentParser(description="Render MIDI to FLAC")
    p.add_argument("input", help="MIDI file path")
    p.add_argument("-o", "--output", help="output FLAC path")
    p.add_argument("-s", "--spatial", action="store_true",
                   help="spatial audio mode")
    a = p.parse_args()
    print("v50")
    from midi import parse
    from mix import render
    tracks, pans = parse(a.input)
    out = a.output or os.path.splitext(a.input)[0] + ".flac"
    render(tracks, pans, out, spatial=a.spatial)


if __name__ == "__main__":
    main()
