"""Generate test audio for all instruments. ~14s each.
Section 1: Low→high ascending sweep (single notes)
Section 2: Short melodic passage (legato + intervals)
Section 3: Rapid-fire burst with chords
"""
import mido, sys, os, shutil

BPM = 120
TPB = 480

def s2t(s):
    return int(s * TPB * BPM / 60)

# Per-instrument range and program
INSTRUMENTS = [
    ("piano",     0,   36, 96),
    ("epiano",   14,   36, 96),
    ("harpsichord", 6, 36, 96),
    ("organ",    16,   36, 96),
    ("guitar",   27,   40, 88),
    ("nylon",    24,   40, 88),
    ("bass",     33,   28, 55),
    ("strings",  48,   36, 84),
    ("cello",    42,   28, 72),
    ("harp",     46,   40, 88),
    ("choir",    52,   48, 84),
    ("brass",    56,   36, 80),
    ("woodwind", 64,   48, 96),
    ("flute",    73,   60, 96),
    ("lead",     81,   36, 96),
    ("pad",      89,   36, 84),
    ("pluck",   117,   40, 88),
    ("celesta",   8,   60, 108),
    ("vibes",    11,   48, 84),
    ("marimba",  12,   48, 84),
]

DRUM_HITS = [36, 38, 42, 44, 46, 49, 51, 41, 43, 45, 47, 55, 57, 59]


def _make_instrument_midi(prog, lo, hi, path):
    mid = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack()
    mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    tr.append(mido.Message('program_change', program=prog, channel=0, time=0))

    rng = (hi - lo)
    mid_n = (lo + hi) // 2

    # === Section 1: Ascending sweep (low→high, ~5s) ===
    step = max(rng // 8, 2)
    gap = 0
    for nn in range(lo, hi + 1, step):
        vel = 70 + int(30 * (nn - lo) / max(rng, 1))  # gradually louder
        tr.append(mido.Message('note_on', note=nn, velocity=min(vel, 127), channel=0, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=0, time=s2t(0.45)))
        gap = s2t(0.08)

    # === Section 2: Melodic passage (~5s) ===
    # A simple melody using scale degrees from mid range
    base = mid_n - 7  # start a fifth below middle
    # Melody: ascending scale, then leap, then descending — mix of durations
    melody = [
        (base,     0.5,  80),
        (base+2,   0.3,  85),
        (base+4,   0.3,  90),
        (base+5,   0.5,  85),
        (base+7,   0.6,  95),  # held note
        (base+12,  0.4, 100),  # octave leap
        (base+11,  0.25, 90),
        (base+9,   0.25, 85),
        (base+7,   0.5,  80),
        (base+5,   0.8,  75),  # long sustained
    ]
    gap = s2t(0.25)
    for nn, dur, vel in melody:
        nn = max(lo, min(nn, hi))
        tr.append(mido.Message('note_on', note=nn, velocity=vel, channel=0, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=0, time=s2t(dur)))
        gap = s2t(0.02)

    # === Section 3: Rapid-fire + chords (~4s) ===
    gap = s2t(0.2)

    # Fast single-note burst
    for i in range(8):
        nn = mid_n + (i % 5) - 2
        nn = max(lo, min(nn, hi))
        tr.append(mido.Message('note_on', note=nn, velocity=95 + (i % 3) * 10, channel=0, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=0, time=s2t(0.08)))
        gap = s2t(0.02)

    # Two chords (3 notes each)
    gap = s2t(0.15)
    chord1 = [mid_n - 5, mid_n, mid_n + 4]  # roughly a minor triad
    chord2 = [mid_n - 3, mid_n, mid_n + 5]   # shifted
    for chord in [chord1, chord2]:
        for j, nn in enumerate(chord):
            nn = max(lo, min(nn, hi))
            tr.append(mido.Message('note_on', note=nn, velocity=100, channel=0, time=gap if j == 0 else 0))
        for j, nn in enumerate(chord):
            nn = max(lo, min(nn, hi))
            tr.append(mido.Message('note_off', note=nn, velocity=0, channel=0, time=s2t(0.5) if j == 0 else 0))
        gap = s2t(0.12)

    # Final rapid descending flourish
    gap = s2t(0.1)
    for i in range(6):
        nn = mid_n + 6 - i * 2
        nn = max(lo, min(nn, hi))
        tr.append(mido.Message('note_on', note=nn, velocity=110, channel=0, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=0, time=s2t(0.06)))
        gap = s2t(0.015)

    mid.save(path)


def _make_drum_midi(path):
    mid = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack()
    mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))

    # Section 1: Individual hits parade
    gap = 0
    for nn in DRUM_HITS:
        tr.append(mido.Message('note_on', note=nn, velocity=100, channel=9, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=9, time=s2t(0.3)))
        gap = s2t(0.05)

    # Section 2: Simple groove (kick-hat-snare-hat pattern)
    gap = s2t(0.3)
    for bar in range(3):
        for beat in range(4):
            if beat % 2 == 0:  # kick
                tr.append(mido.Message('note_on', note=36, velocity=100, channel=9, time=gap))
                tr.append(mido.Message('note_off', note=36, velocity=0, channel=9, time=s2t(0.05)))
                gap = 0
            if beat % 2 == 1:  # snare
                tr.append(mido.Message('note_on', note=38, velocity=90, channel=9, time=gap))
                tr.append(mido.Message('note_off', note=38, velocity=0, channel=9, time=s2t(0.05)))
                gap = 0
            # hi-hat on every beat
            tr.append(mido.Message('note_on', note=42, velocity=70, channel=9, time=gap))
            tr.append(mido.Message('note_off', note=42, velocity=0, channel=9, time=s2t(0.05)))
            gap = s2t(0.4)

    # Section 3: Fill — rapid toms + crash
    gap = s2t(0.1)
    fill = [47, 45, 43, 41, 43, 41, 38, 36]
    for i, nn in enumerate(fill):
        tr.append(mido.Message('note_on', note=nn, velocity=110, channel=9, time=gap))
        tr.append(mido.Message('note_off', note=nn, velocity=0, channel=9, time=s2t(0.06)))
        gap = s2t(0.02)
    # Final crash + kick
    tr.append(mido.Message('note_on', note=49, velocity=120, channel=9, time=s2t(0.05)))
    tr.append(mido.Message('note_on', note=36, velocity=110, channel=9, time=0))
    tr.append(mido.Message('note_off', note=49, velocity=0, channel=9, time=s2t(0.8)))
    tr.append(mido.Message('note_off', note=36, velocity=0, channel=9, time=0))

    mid.save(path)


if __name__ == "__main__":
    test_dir = os.path.dirname(os.path.abspath(__file__))
    proj_dir = os.path.dirname(test_dir)
    sys.path.insert(0, proj_dir)

    out_dir = os.path.join(test_dir, "samples")
    os.makedirs(out_dir, exist_ok=True)

    from midi import parse
    from mix import render

    targets = set(sys.argv[1:]) if len(sys.argv) > 1 else None

    for label, prog, lo, hi in INSTRUMENTS:
        if targets and label not in targets:
            continue
        mp = os.path.join(out_dir, f"{label}.mid")
        fp = os.path.join(out_dir, f"{label}.flac")
        _make_instrument_midi(prog, lo, hi, mp)
        print(f"\n=== {label} (prog={prog}, {lo}-{hi}) ===")
        tracks, pans = parse(mp)
        render(tracks, pans, fp)

    if not targets or "drums" in targets:
        mp = os.path.join(out_dir, "drums.mid")
        fp = os.path.join(out_dir, "drums.flac")
        _make_drum_midi(mp)
        print(f"\n=== drums ===")
        tracks, pans = parse(mp)
        render(tracks, pans, fp)

    print(f"\nAll done. Samples in {out_dir}/")
