# Code Conduct

## Architecture
- synth/ produces mono audio per note; mix/ handles pipeline.
- Timbre parameters: instruments.py. Engine routing: gm.py. Pipeline params: PIPELINE dict.

## Rules
- All changes tested through full pipeline. Never bypass mix for quality assessment.
- Body IR/EQ removed by design. Do not re-add.
- Reverb IR energy-normalized (L2). All IR convolutions likewise.
- KS for plucked sounds only; sustained notes (>=0.8s) route to additive.
- Sustained instruments (bow/breath/organ): d2=2-4 for wind/strings, d2>=20 for organ/pad.
- Plucked/struck: d2=0.5-3.0.
- Bowed strings lock harmonics (micro=0). Free vibration (piano/epiano): micro=1.0.
- Choose correct physical model over parameter tuning.
- Self-test before delivery: verify spectrum, envelope, release.
- Leslie effect: vibrato only (single rotation), not vibrato+tremolo simultaneously.
- Formants work best above 400Hz; avoid low-frequency bandpass formants on low instruments.
- ref_amp must include sub + sub_third. Sub/sub_third need decay when d2 < 10.
- Organ/pad must set vd=0 explicitly to prevent sustain decay.
- track_peak_cap must stay >= 0.85 for percussive instrument dynamics.
- PIPELINE values are authoritative; do not hardcode filter frequencies elsewhere.
- harm_amps overrides rolloff. Use for instruments needing specific harmonic recipes.
- Formants use peaking EQ biquads (not bandpass mix). Gain parameter 0-1 maps to 0-24dB boost.
- Formants apply to BOTH additive AND KS output (via synth/__init__.py routing).
- bow_noise for bowed strings only. breath_noise for wind instruments only.
- lip_shape for brass family only (velocity-dependent waveshaping).
- tw_leak for organ only (tonewheel crosstalk simulation).
- Dynamic floor is 0.15+0.85*v in both additive and KS engines.
- Release tail must accommodate instrument's rel parameter (not hardcapped).
- Release rate adapts to rel (5/rel for long notes); never hardcode rate.
- HRTF head-shadow lowpass skipped at small angles (sa < 0.05) to prevent center imbalance.
- Brass/woodwind attack must be >= 20ms at mf (no percussive onset for blown instruments).
