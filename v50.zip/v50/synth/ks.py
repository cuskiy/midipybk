"""Karplus-Strong plucked string with position-dependent excitation."""
import numpy as np
from .timbre import SR, vc

KS_T60 = 2.0
KS_MUTE = 0.985
KS_LP_BASE = 0.55
KS_LP_VEL = 0.08
KS_CLICK_AMP = 0.12

def synthesize_plucked(freq, dur, vel, tim, name="guitar", nid=0):
    tail = min(tim.rel * 1.2 + 0.35, 2.5)
    n = int(SR * (dur + tail))
    if n == 0:
        return np.zeros(0)
    v = vc(vel)
    rng = np.random.RandomState((int(freq * 100 + vel * 1000) + nid * 7919) % (2**31))

    period = SR / freq
    dl_len = max(int(np.floor(period)), 2)
    frac = period - dl_len
    lp = (tim.ks_lp if tim.ks_lp > 0 else KS_LP_BASE) + KS_LP_VEL * v

    # Position-dependent excitation: triangle peaked at pluck point.
    # Near bridge (pos~0.12) → narrow → rich harmonics.
    # Near center (pos~0.50) → broad → fundamental dominant.
    pos = tim.strike_pos if tim.strike_pos > 0.01 else 0.14
    pk_idx = max(1, min(int(pos * dl_len), dl_len - 2))
    exc = np.zeros(dl_len)
    exc[:pk_idx + 1] = np.linspace(0, 1, pk_idx + 1)
    exc[pk_idx:] = np.linspace(1, 0, dl_len - pk_idx)
    exc *= v * 0.8

    # Add noise scaled by ks_click (pick scrape)
    noise_amt = tim.ks_click if tim.ks_click > 0 else 0.05
    exc += rng.randn(dl_len) * noise_amt * v * 0.3

    loss = 10 ** (-3 / (max(freq, 40) * KS_T60))
    noff = int(SR * dur)

    dl, ptr, prev = exc.copy(), 0, 0.0
    out = np.zeros(n)
    for i in range(n):
        idx1 = (ptr + 1) % dl_len
        val = dl[ptr] + frac * (dl[idx1] - dl[ptr])
        filt = lp * val + (1 - lp) * prev
        prev = filt
        out[i] = val
        dl[ptr] = filt * (loss if i < noff else loss * KS_MUTE)
        ptr = (ptr + 1) % dl_len

    pk = np.max(np.abs(out))
    if pk > 1e-6:
        out /= pk

    att_n = min(int(SR * 0.002), n)
    if att_n > 1:
        out[:att_n] *= np.linspace(0, 1, att_n) ** 0.5

    # Pluck transient click
    click = tim.ks_click if tim.ks_click > 0 else KS_CLICK_AMP
    cn = min(int(SR * 0.001), n)
    if cn > 0:
        out[:cn] += rng.randn(cn) * click * v * np.exp(-np.arange(cn) * 20.0 / cn)

    ac = min(128, n)
    if ac > 1:
        out[-ac:] *= 0.5 * (1 + np.cos(np.linspace(0, np.pi, ac)))
    return out * (0.15 + 0.85 * v)
