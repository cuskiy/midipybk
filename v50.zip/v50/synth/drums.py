import numpy as np
from .timbre import SR

_MAP = {
    35: (150,42,0.12,0.06,0.95,0.22), 36: (155,45,0.11,0.055,0.95,0.22),
    37: (800,800,0.025,0.025,0.30,0.80), 38: (185,125,0.07,0.20,0.45,0.75),
    39: (250,200,0.05,0.08,0.30,0.85), 40: (175,120,0.065,0.18,0.45,0.75),
    41: (95,65,0.20,0.08,0.82,0.35), 42: (0,0,0.01,0.030,0.0,0.82),
    43: (110,78,0.17,0.07,0.78,0.40), 44: (0,0,0.01,0.020,0.0,0.82),
    45: (125,88,0.15,0.07,0.72,0.42), 46: (0,0,0.01,0.12,0.0,0.75),
    47: (145,98,0.13,0.06,0.68,0.42), 48: (165,115,0.11,0.055,0.62,0.42),
    49: (0,0,0.01,0.40,0.0,0.68), 50: (190,190,0.08,0.05,0.50,0.50),
    51: (0,0,0.01,0.28,0.08,0.68), 52: (0,0,0.01,0.45,0.0,0.65),
    55: (0,0,0.01,0.06,0.0,0.75), 57: (0,0,0.01,0.42,0.0,0.68),
    59: (0,0,0.01,0.22,0.0,0.70),
}
_METAL = {
    42:[3400,6100,8800], 44:[3200,5800,8400],
    46:[2800,5200,7800], 49:[2200,4800,7200,10000],
    51:[2600,5000,7600], 52:[2400,4600,7000,10000],
    55:[3600,6400,9200], 57:[2300,4900,7300,10000],
    59:[2700,5100,7700],
}
_SNARE = {38, 40}

def drum(note, dur, vel, rng):
    f0,f1,td,nd,tm,nm = _MAP.get(note, (200,150,0.08,0.08,0.50,0.50))
    length = max(dur, max(td,nd)*3.5)
    n = int(SR*length)
    if n == 0: return np.zeros(0)
    tv = np.linspace(0, length, n, endpoint=False)
    out = np.zeros(n)

    if tm > 0 and f0 > 0:
        sweep = f1 + (f0-f1)*np.exp(-tv/0.012)
        phase = 2*np.pi*np.cumsum(sweep)/SR
        env = np.exp(-tv/max(td, 0.005))
        out += np.sin(phase)*env*tm
        out += 0.25*np.sin(phase*1.59+rng.random()*6.28)*env*tm*np.exp(-tv/(td*0.4))

    if nm > 0:
        ns = rng.randn(n)
        nenv = np.exp(-tv/max(nd, 0.005))
        if note in _METAL:
            metal = sum(np.sin(2*np.pi*mf*(1+0.025*rng.randn())*tv+rng.random()*6.28)
                        * (0.55**i) * np.exp(-tv/max(nd*(0.6+0.4*rng.random()),0.01))
                        for i,mf in enumerate(_METAL[note]))
            out += (0.45*ns*nenv + 0.55*metal)*nm
        else:
            out += ns*nenv*nm*0.5

    if note in _SNARE:
        wn = min(int(SR*nd*2.5), n)
        wire = rng.randn(wn)*0.3*np.sin(2*np.pi*(4500+rng.random()*1000)*np.linspace(0,wn/SR,wn))
        wire *= np.exp(-np.arange(wn,dtype=np.float64)/(SR*nd*1.5))
        out[:wn] += wire*vel

    out *= vel
    pk = np.max(np.abs(out))
    if pk > 1: out /= pk
    ac = min(128, n)
    if ac > 1: out[-ac:] *= 0.5*(1+np.cos(np.linspace(0, np.pi, ac)))
    return out
