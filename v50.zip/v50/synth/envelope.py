import numpy as np
from .timbre import SR, lf, vc

def envelope(tim, dur, n, vel, freq, noff):
    _l, v = lf(freq), vc(vel)
    at = min(tim.att * (1 - tim.va*v), dur*0.25)
    d1t = min(tim.d1, dur*0.4)
    an, dn = int(SR*at), int(SR*d1t)
    ds = an + dn
    rs = min(noff if noff is not None else n, n)
    env = np.zeros(n)

    if an > 0:
        t_att = np.linspace(0, 1, an)
        pw = 0.8 + 0.5*(1-v) + 0.3*_l
        env[:an] = 0.4*(1 - np.cos(np.pi*t_att))/2 + 0.6*t_att**pw
    if dn > 0:
        dl = min(tim.d1l + (1-tim.d1l)*v*0.15 + tim.ps*_l, 0.995)
        env[an:an+dn] = dl + (1-dl)*np.exp(-2.7*(1-0.35*_l)*np.linspace(0, 1, dn))

    d2n = max(0, rs-ds)
    if d2n > 0:
        sl = env[ds-1] if ds > 0 else tim.d1l
        tau = max(tim.d2*(1+tim.vd*v), 0.05) * (1+(tim.pdm-1)*_l)
        d2t = np.linspace(0, d2n/SR, d2n)
        if tim.d2s > 0 and tim.pr < 1:
            ts = tim.d2s*(1+0.5*_l)
            env[ds:rs] = sl * (tim.pr*np.exp(-d2t/tau) + (1-tim.pr)*np.exp(-d2t/ts))
        else:
            env[ds:rs] = sl * np.exp(-d2t/tau)

    if rs < n:
        sv = env[rs-1] if rs > 0 else 0
        rate = 5.0 / max(tim.rel, 0.02) if dur >= 0.2 else 10.0
        env[rs:] = sv * np.exp(-rate*np.arange(n-rs, dtype=np.float64)/SR)

    if tim.live > 0 and n > SR*0.08:
        ta = np.linspace(0, n/SR, n, endpoint=False)
        rs_ = np.random.RandomState(int(freq*100+vel*1000) % (2**31))
        r1, r2 = 2+rs_.random()*2, 4.5+rs_.random()*3
        on = np.clip(ta/0.12, 0, 1)
        env *= 1 + tim.live*on*(0.6*np.sin(2*np.pi*r1*ta+rs_.random()*6.28)
                                 + 0.4*np.sin(2*np.pi*r2*ta+rs_.random()*6.28))

    ac = min(128, n)
    if ac > 1: env[-ac:] *= 0.5*(1 + np.cos(np.linspace(0, np.pi, ac)))
    return env
