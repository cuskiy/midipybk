# v50

## Changes from v49

### Spatial audio mode (`-s`)
- **Early reflections**: 5-tap discrete room model with HRTF-panned reflections
- **Pinna notch**: 4dB peaking cut at 5.5kHz on contralateral ear for externalization
- **Wider stage**: azimuth scaled 1.12× for panoramic spread
- **Reverb**: longer RT60 (1.8s), 18ms pre-delay, slightly wetter (0.055)
- Parameter-driven: SPATIAL dict overrides PIPELINE, zero branching in render path

### Architecture
- IR generation keyed by (room, rt60), cached per-config
- `render()` accepts `spatial=False`; `-s` flag in CLI

### No default audio changes
- Without `-s`, output is bit-identical to v49.

## Cumulative changes from v46
- Per-instrument HP filtering for mix clarity
- Drum VOLUME 0.55→0.78
- Piano/epiano/guitar/nylon spectral improvements
- KS/additive equal-power crossfade with gain calibration
- track_peak_cap 0.85→2.5
- Buffer tail formula fix
- Lazy reverb IR, HRTF center bypass
- Scalar math optimizations (numpy→math for per-partial ops)
- Cached ref_amp/harm_amps per Timbre
- KS calibration 12→6 calls
- Vectorized compressor
- Spatial audio mode with early reflections, pinna modeling, stage widening
