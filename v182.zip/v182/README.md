# GoldenScore — MIDI-to-FLAC Renderer

Offline synthesizer that renders Standard MIDI files to 24-bit/44.1 kHz FLAC.
No samples, no soundfonts — every sound is generated from mathematical models
of the underlying instrument.

## Sound Aesthetic

> 温柔融进，点点夕阳灿烂，碎光如金
>
> *Gentle merging, dots of sunset brilliance, scattered golden light*

GoldenScore targets a **warm-but-detailed-and-clean** sound — like golden
sunset light falling softly across a landscape. Warm fundamentals envelop
the listener, while subtle upper-partial shimmer catches the ear like
scattered sunlight.

### Design Principles

1. **Golden onset**: Every struck or plucked note carries a brief burst of
   upper-partial brightness (`spec_b`) in the first 50-60 ms. This is the
   "golden glow" — you feel it as presence and clarity, but it melts into
   the note body before you consciously notice it.

2. **Warm foundation**: Spectral rolloff (0.65-0.85 for natural instruments)
   ensures fundamentals and lower harmonics dominate. The sound is warm
   first, detailed second.

3. **Scattered light** (碎光如金): Targeted formant peaks at 4.5-5.5 kHz add
   sparkle at specific frequencies — not a broad HF boost, but focused
   shimmer like light glinting off water. Every instrument has at least
   minimal presence energy above 4 kHz.

4. **Natural dynamics**: Gentle master compression (ratio 1.8, threshold 0.30)
   preserves the dynamic range. The limiter sits at 0.89 — plenty of
   headroom for peaks to breathe.

5. **Transparent chain**: Master EQ lifts air at 6 kHz (not 8 kHz) to target
   the frequency range where instruments actually have content. Reverb
   darkening is gentle (-0.6 dB effective) so the tail retains golden
   shimmer.

## Philosophy

Do one thing well. The renderer takes one MIDI file in and writes one FLAC
file out. There are no quality presets, no `--fast` / `--hq` knobs, no
runtime tuning parameters. The defaults *are* the best the project can
produce; if you want a different sound, edit a constant and re-run.

## Usage

```
python main.py input.mid                       # → input.flac
python main.py input.mid -o out.flac           # custom output path
python main.py input.mid --spatial             # binaural HRTF (headphones)
python main.py input.mid --stems               # also write per-instrument stems
python main.py input.mid --stems-dir ./stems   # custom stems directory
python main.py input.mid --start 30 --end 60   # partial render (seconds)
```

### Stems vs main mix

When `--stems` is used, each stem FLAC is a **post-master** render of
that instrument family at the same absolute level as the main mix.
Stems are intended for re-mastering or remixing in a DAW.

## Requirements

```
pip install mido soundfile scipy numpy
```

## Architecture

```
main.py            Entry point, CLI
config.py          Centralized constants (CC, sympathetic, additive tuning)
schema.py          Shared data types (Note, ChannelData, PipelineConfig)
midi.py            MIDI parser (notes, CCs, pitch bend, RPN)
synth/             Synthesis engines + instrument definitions
  timbre.py        Timbre parameter class (67 fields), pitch helpers
  instruments.py   24 instrument presets — Golden Hour tuning
  gm.py            GM program routing, per-instrument mix params (InstrumentMix)
  additive.py      Additive synthesis (inline spectral envelope)
  fm.py            FM synthesis (multi-operator, oversampled)
  ks.py            Karplus-Strong physical model (LP-compensated)
  inharmonic.py    Filtered-noise texture (3-band, GM 120-127)
  drums.py         Percussion synthesis (55 GM drum sounds)
  envelope.py      ADSR envelope generator with liveness modulation
  dsp.py           Shared DSP: filters, BoundedCache, biquad helpers
  calibrate.py     Standalone tool: re-derives KS_GAIN table
  __init__.py      Engine dispatcher + crossfade + peak headroom
mix/               Render pipeline + mastering
  track_render.py  Per-track synthesis, DSP chain, sympathetic resonance
  pipeline.py      Master chain, parallel dispatch, FLAC output, progress
  dsp_module.py    Stateful block-based DSP modules (HP, chorus, Leslie, ...)
  cc.py            CC interpolation (zero-order hold), smoothing, pitch bend
  routing.py       Track splitting and merging by (instrument, channel)
  master.py        FDN reverb IR, stereo compressor, master EQ stages
  spatial.py       HRTF, early reflections, binaural crossfeed
  __init__.py      Re-exports: render, clear_caches, BLOCK_SIZE
test/              Tests (45 tests)
tools/             gen_all.py — render every instrument to sample FLAC
```

## Technical Reference

See [docs/TECHNICAL.md](docs/TECHNICAL.md) for synthesis engine details,
pipeline parameters, per-instrument settings, and GM compliance notes.

## Development

See `CODE_CONDUCT.md` for methodology and common pitfalls.
