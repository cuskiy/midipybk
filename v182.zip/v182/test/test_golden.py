"""Golden audio fingerprint test.

Synthesizes a fixed in-code MIDI fixture (no external .mid file needed)
and checks that coarse audio metrics stay within tolerance across
refactors. Catches "refactor that subtly changed the mix" — something
test_regression.py cannot see because it only tests individual engines.

Metrics compared:
  rms, peak, centroid, lo_energy, mid_energy, hi_energy

v160 improvements (items 11, 12):
  - Golden values live in test/golden.json, not as Python literals, so
    `git log test/golden.json` becomes "listening history" and regenerations
    don't noise up code diffs.
  - Tolerances tightened from v159 wave-D levels to catch medium drift
    (e.g. 0.15 DC jump on BrightnessModule transitions) while still
    surviving intentional ±0.5 dB mix tuning.
  - Run `python test/test_golden.py update` to regenerate the JSON.
"""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from schema import Note, ChannelData, ParseResult

GOLDEN_PATH = os.path.join(os.path.dirname(__file__), "golden.json")


# v160 item 12: tightened tolerances. Still loose enough to absorb
# intentional ±0.5 dB mix tuning but tight enough to catch medium
# drift (chorus gain changes, sympa density changes, 0.15 DC jumps).
TOLERANCES = {
    "rms":        0.012,   # ±0.012 absolute (was 0.020)
    "peak":       0.015,   # ±0.015 absolute (was 0.020)
    "centroid":   120.0,   # ±120 Hz (was 200)
    "lo_energy":  0.05,    # ±5% absolute (was 8%)
    "mid_energy": 0.05,
    "hi_energy":  0.02,    # ±2% absolute (was 3%)
}


def _build_fixture_result() -> ParseResult:
    """Deterministic multi-instrument notes — no external MIDI file."""
    notes = []
    # Piano C major scale over 2 s (program 0)
    for i, midi in enumerate([60, 62, 64, 65, 67, 69, 71, 72]):
        notes.append(Note(start=i * 0.25, midi=midi, dur=0.22,
                          vel=0.8, ch=0, prog=0))
    # Bass pedal at C2 (program 32) — two long notes
    notes.append(Note(start=0.0, midi=36, dur=1.0, vel=0.7, ch=1, prog=32))
    notes.append(Note(start=1.0, midi=36, dur=1.0, vel=0.7, ch=1, prog=32))
    # Strings chord (program 48) — sustained
    for midi in (60, 64, 67):
        notes.append(Note(start=0.5, midi=midi, dur=1.4, vel=0.6, ch=2, prog=48))
    ch_data = {0: ChannelData(), 1: ChannelData(), 2: ChannelData()}
    return ParseResult(notes=notes, ch_data=ch_data, channel_pans={})


def _compute_metrics(path: str) -> dict:
    import soundfile as sf
    x, sr = sf.read(path)
    if x.ndim == 2:
        x = x.mean(axis=1)
    spec = np.abs(np.fft.rfft(x))
    freqs = np.fft.rfftfreq(len(x), 1.0 / sr)
    tot = float(np.sum(spec ** 2)) + 1e-20
    return {
        "rms":        float(np.sqrt(np.mean(x * x))),
        "peak":       float(np.max(np.abs(x))),
        "centroid":   float(np.sum(freqs * spec) / (np.sum(spec) + 1e-20)),
        "lo_energy":  float(np.sum(spec[freqs < 250] ** 2) / tot),
        "mid_energy": float(np.sum(spec[(freqs >= 250) & (freqs < 2000)] ** 2) / tot),
        "hi_energy":  float(np.sum(spec[freqs >= 2000] ** 2) / tot),
    }


def _render_fixture() -> dict:
    from mix import render, clear_caches
    result = _build_fixture_result()
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "golden.flac")
        clear_caches()
        render(result, out, region=(0, 2.0))
        return _compute_metrics(out)


def _load_golden() -> dict:
    with open(GOLDEN_PATH) as f:
        data = json.load(f)
    return {k: v for k, v in data.items() if not k.startswith("_")}


def test_golden_audio_fingerprint():
    """Coarse fingerprint of a 2-second multi-instrument fixture render.

    Run ``python test/test_golden.py update`` if you intentionally
    retuned the mix, then add a note in docs/CHANGES.md explaining the
    retune.
    """
    golden = _load_golden()
    measured = _render_fixture()
    failures = []
    for k, want in golden.items():
        tol = TOLERANCES[k]
        got = measured[k]
        if abs(got - want) > tol:
            failures.append(f"{k}: got {got:.4f}, want {want:.4f} ± {tol:.4f}")
    if failures:
        print("Current metrics:")
        for k, v in measured.items():
            print(f"  {k:<12s} {v:.4f}")
        print("Golden:")
        for k, v in golden.items():
            print(f"  {k:<12s} {v:.4f} ± {TOLERANCES[k]:.4f}")
    assert not failures, "Golden drift:\n  " + "\n  ".join(failures)


def _update_golden():
    measured = _render_fixture()
    data = {"_comment": ("Golden audio fingerprint. Regenerate with "
                         "`python test/test_golden.py update`.")}
    data.update(measured)
    with open(GOLDEN_PATH, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    print(f"Updated {GOLDEN_PATH}:")
    for k, v in measured.items():
        print(f"  {k:<12s} {v:.4f}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "update":
        _update_golden()
    else:
        # v168 fix: the previous __main__ only printed metrics and never
        # invoked the assertion, so `python test/test_golden.py` always
        # returned success even when the fingerprint had drifted. A test
        # that doesn't assert is not a test. Now we actually run the
        # assertion and exit non-zero on drift.
        measured = _render_fixture()
        print("Measured fixture metrics:")
        for k, v in measured.items():
            print(f"  {k:<12s} {v:.4f}")
        try:
            test_golden_audio_fingerprint()
            print("\ngolden fingerprint: OK")
        except AssertionError as e:
            print(f"\ngolden fingerprint: FAIL\n{e}")
            sys.exit(1)
