"""Regression tests for v159 fixes.

Run: python test/test_fixes.py   (or pytest test/test_fixes.py)
"""
import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from synth.timbre import SR, A4
from synth.instruments import TIMBRES
from synth.additive import synthesize as additive
from synth import synthesize as dispatch
from mix.cc import interp_cc
from config import CC7_LAW_EXP


def _f(midi):
    return A4 * 2 ** ((midi - 69) / 12.0)


def test_nid_decorrelation():
    """Two different nids on identical (freq, vel) must produce different jitter.

    If RMS difference is below 1% they were bit-identical (the v158 collision bug).
    """
    tim = TIMBRES["piano"]
    a = additive(_f(60), 0.4, 0.8, tim, "piano", nid=0)
    b = additive(_f(60), 0.4, 0.8, tim, "piano", nid=100001)
    n = min(len(a), len(b))
    diff_rms = float(np.sqrt(np.mean((a[:n] - b[:n]) ** 2)))
    a_rms = float(np.sqrt(np.mean(a[:n] ** 2)))
    rel = diff_rms / max(a_rms, 1e-9)
    assert rel > 0.01, f"nid decorrelation failed: rel diff = {rel:.4f}"
    print(f"  nid_decorrelation        rel_diff={rel:.3f}  OK")


def test_pb_pitch_down_no_click():
    """Negative pitch bend must not leave a silent / click tail."""
    tim = TIMBRES["guitar"]
    n = int(SR * 0.4)
    pb = np.full(n, -2.0)  # 2 semitones down for the entire note
    out = dispatch(_f(60), 0.4, 0.8, tim, "guitar", nid=1, pb_curve=pb)
    # Last 10ms should not be all zero
    tail = out[-int(SR * 0.01):]
    tail_rms = float(np.sqrt(np.mean(tail * tail)))
    assert tail_rms > 1e-7, f"pitch-down tail is silent: rms={tail_rms:.2e}"
    # And no abrupt jump (click) at the join: max sample-to-sample diff
    diffs = np.abs(np.diff(out))
    max_jump = float(np.max(diffs))
    assert max_jump < 0.5, f"pitch-down click detected: max_jump={max_jump:.3f}"
    print(f"  pb_pitch_down_no_click   tail_rms={tail_rms:.2e}  max_jump={max_jump:.3f}  OK")


def test_cc7_law_is_x_to_1_5():
    """CC7=80/127 with x^1.5 law should give ~0.50.
    sqrt(x) ≈ 0.79 (the v158 bug); x² ≈ 0.40; x^1.5 ≈ 0.50.
    """
    norm = 80.0 / 127.0
    expected = norm ** CC7_LAW_EXP
    assert abs(CC7_LAW_EXP - 1.5) < 1e-6, f"CC7_LAW_EXP changed: {CC7_LAW_EXP}"
    assert 0.45 < expected < 0.55, f"CC7=80 → {expected:.3f}, expected ~0.50"
    sqrt_val = math.sqrt(norm)
    assert sqrt_val > 0.75, "sanity"
    assert abs(expected - sqrt_val) > 0.2, "law collapsed back to sqrt"
    print(f"  cc7_law_is_x_to_1_5      CC7=80 → {expected:.3f}  OK")


def test_interp_cc_zoh_step():
    """interp_cc must be a true zero-order hold, not a ramp."""
    # First event late (>0.1s) so default is held in the prelude
    events = [(0.5, 0.5), (0.9, 0.9)]
    n = int(SR * 1.0)
    curve = interp_cc(events, n, default=0.0)
    # Pre-event default holds
    assert abs(curve[int(0.2 * SR)] - 0.0) < 1e-6, f"prelude default broken: {curve[int(0.2*SR)]}"
    # First event value held until next event (ZOH, no ramp)
    assert abs(curve[int(0.7 * SR)] - 0.5) < 1e-6, f"ZOH broken at t=0.7: {curve[int(0.7*SR)]}"
    # Second event value
    assert abs(curve[int(0.95 * SR)] - 0.9) < 1e-6, f"ZOH broken at t=0.95: {curve[int(0.95*SR)]}"
    # Verify it's a step (no linear ramp): diff at t=0.7 should be 0
    sample_idx = int(0.7 * SR)
    assert abs(curve[sample_idx] - curve[sample_idx + 1]) < 1e-9, "ZOH should be flat between events"
    print(f"  interp_cc_zoh_step       OK")


def test_sympathetic_density_bound():
    """Sympathetic gain must not blow up in dense passages."""
    from mix.track_render import _apply_sympathetic
    from schema import Note
    # 30 notes of overlapping piano clusters
    notes = []
    for i in range(30):
        midi = 48 + (i * 7) % 24
        notes.append(Note(start=i * 0.05, midi=midi, dur=0.6,
                          vel=0.8, ch=0, prog=0))
    buf_len = int(SR * 3.0)
    silent = np.zeros(buf_len)
    out = _apply_sympathetic(silent.copy(), notes, buf_len)
    pk = float(np.max(np.abs(out)))
    assert pk < 0.05, f"sympathetic blew up: peak={pk:.3f}"
    assert pk > 1e-7, f"sympathetic produced no output at all: peak={pk:.3e}"
    print(f"  sympathetic_density      peak={pk:.4f}  OK")


def test_additive_baseline_rms():
    """Baseline RMS / peak ranges per instrument. Detect drift."""
    cases = [
        ("piano", 60, 0.8, (0.05, 0.30)),
        ("piano", 84, 0.6, (0.03, 0.35)),
        ("strings", 60, 0.7, (0.03, 0.40)),
        ("flute", 72, 0.7, (0.03, 0.40)),
    ]
    for name, midi, vel, (lo, hi) in cases:
        tim = TIMBRES[name]
        w = additive(_f(midi), 0.5, vel, tim, name, nid=0)
        rms = float(np.sqrt(np.mean(w * w)))
        assert lo <= rms <= hi, f"{name} m={midi} v={vel} rms={rms:.3f} not in [{lo},{hi}]"
        print(f"  additive_baseline {name:<10s} m={midi} v={vel} rms={rms:.3f}  OK")


def test_dur_field_removed_from_noteevent():
    """NoteEvent must not have a dur field anymore."""
    from schema import NoteEvent
    fields = NoteEvent._fields
    assert "dur" not in fields, f"NoteEvent still has dur: {fields}"
    print(f"  noteevent_no_dur         fields={fields}  OK")


def test_voice_module_deleted():
    """synth.voice must be gone (was dead code)."""
    try:
        import synth.voice  # noqa
        raise AssertionError("synth.voice still importable")
    except ModuleNotFoundError:
        print(f"  voice_module_deleted     OK")


def test_block_iter_brightness_varies():
    """BrightnessModule with time-varying CC74 must produce different output
    over time when called via block iteration. With single-call processing
    (the v158 bug) the entire song would be filtered with one fixed gain.
    """
    from mix.dsp_module import BrightnessModule, DspChain
    from mix.track_render import _process_chain_blocked
    n = int(SR * 2.0)
    # CC74 ramp from 0.2 (dark) to 0.8 (bright)
    cc = np.linspace(0.2, 0.8, n)
    mod = BrightnessModule(cc, n)
    chain = DspChain([mod])
    sig = np.sin(2 * np.pi * 4000.0 * np.arange(n) / SR)
    out = _process_chain_blocked(chain, sig)
    # Compare RMS of first vs last quarter — bright section should be louder at 4kHz
    q = n // 4
    rms_dark = float(np.sqrt(np.mean(out[:q] ** 2)))
    rms_bright = float(np.sqrt(np.mean(out[-q:] ** 2)))
    ratio = rms_bright / max(rms_dark, 1e-9)
    assert ratio > 1.05, f"brightness time-variation broken: dark={rms_dark:.3f} bright={rms_bright:.3f} ratio={ratio:.3f}"
    print(f"  block_iter_brightness    dark={rms_dark:.3f} bright={rms_bright:.3f} ratio={ratio:.3f}  OK")


def test_program_map_baseline():
    """Pin a few critical PROGRAM_MAP entries that have churned."""
    from synth.gm import PROGRAM_MAP
    expected = {
        0: "piano", 4: "epiano", 14: "vibes", 15: "harp",
        24: "nylon", 25: "guitar", 32: "bass", 38: "synbass",
        40: "strings", 42: "cello", 43: "contrabass",
        56: "brass", 73: "flute", 80: "lead", 88: "pad", 120: "sfx",
    }
    for prog, name in expected.items():
        got = PROGRAM_MAP.get(prog)
        assert got == name, f"PROGRAM_MAP[{prog}] = {got}, expected {name}"
    print(f"  program_map_baseline     {len(expected)} entries OK")


def test_instrument_restoration():
    """v159: piano/lead/pad/cello/synbass restored from over-damped v158."""
    p = TIMBRES["piano"]
    assert p.coupling >= 0.25, f"piano coupling regressed: {p.coupling}"
    assert p.phantom >= 0.015, f"piano phantom regressed: {p.phantom}"
    assert p.micro >= 0.18, f"piano micro regressed: {p.micro}"

    lead = TIMBRES["lead"]
    assert lead.harm_amps != "", "lead lost harm_amps (collapsed to sine)"
    assert lead.det_c >= 4.0, f"lead lost detune: det_c={lead.det_c}"

    pad = TIMBRES["pad"]
    assert pad.n >= 8, f"pad collapsed to n={pad.n} (need partials for wash)"
    assert pad.det_c >= 5.0, f"pad lost detune ensemble: det_c={pad.det_c}"

    cello = TIMBRES["cello"]
    assert cello.bow_noise >= 0.012, f"cello lost bow noise: {cello.bow_noise}"

    synbass = TIMBRES["synbass"]
    assert synbass.drive <= 0.05, f"synbass drive too high (nasal): {synbass.drive}"

    print(f"  instrument_restoration   piano coupling={p.coupling} phantom={p.phantom} micro={p.micro}  OK")
    print(f"                           lead det_c={lead.det_c} drive={lead.drive}")
    print(f"                           pad n={pad.n} det_c={pad.det_c}")
    print(f"                           cello bow_noise={cello.bow_noise}")
    print(f"                           synbass drive={synbass.drive}")


def test_no_quality_knobs():
    """UNIX philosophy: no runtime quality switches in main.py or config."""
    import config
    for forbidden in ("ADDITIVE_OS_DRIVE_THRESHOLD", "ADDITIVE_DC_REMOVE",
                      "SYMPA_DENSITY_NORM"):
        assert not hasattr(config, forbidden), f"{forbidden} should be removed"
    with open(os.path.join(os.path.dirname(__file__), "..", "main.py")) as f:
        main_src = f.read()
    for forbidden in ("--quality", "--profile", "--seed", "--quiet"):
        assert forbidden not in main_src, f"main.py still has {forbidden}"
    print(f"  no_quality_knobs         OK")


def main():
    tests = [
        test_nid_decorrelation,
        test_pb_pitch_down_no_click,
        test_cc7_law_is_x_to_1_5,
        test_interp_cc_zoh_step,
        test_sympathetic_density_bound,
        test_additive_baseline_rms,
        test_dur_field_removed_from_noteevent,
        test_voice_module_deleted,
        test_block_iter_brightness_varies,
        test_program_map_baseline,
        test_instrument_restoration,
        test_no_quality_knobs,
    ]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"  FAIL  {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERR   {t.__name__}: {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{len(tests) - failed}/{len(tests)} tests passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
