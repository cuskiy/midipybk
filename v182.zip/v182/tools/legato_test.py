"""Legato test — mimics the chord-stab pattern from faded.mid.

For synbass and contrabass we generate a 6-second pattern with
4-voice chords retriggered every 333 ms (dur=292 ms, gap=41 ms) —
exactly the structure that produced the "嘟嘟嘟" / "呼噜" / "啵啵波"
artefacts in v170-v174a. After the legato merge in midi.py + the
flat-sustain envelope fix in instruments.py, the rendered audio
should sound like a single held chord per pitch run, not a
machine-gun.

Three test files:
  legato_synbass.flac    — synbass chord stabs
  legato_contrabass.flac — contrabass repeated bass note
  legato_chord_change.flac — synbass with a chord change mid-pattern
                              (verifies the crossfade between merged runs)
"""
import os, sys, mido

TPB = 480
BPM = 120
def s2t(s): return int(s * TPB * BPM / 60)


def _stab_pattern(prog, ch, pitches, n_stabs, dur=0.292, ioi=0.333, vel=80):
    """Generate a list of (note, dur, time-since-prev) for retrigger pattern."""
    msgs = []
    msgs.append(mido.Message('program_change', program=prog, channel=ch, time=0))
    for i in range(n_stabs):
        # all pitches at once
        for j, p in enumerate(pitches):
            t = s2t(ioi - dur) if (i > 0 and j == 0) else 0
            msgs.append(mido.Message('note_on', note=p, velocity=vel, channel=ch, time=t))
        for j, p in enumerate(pitches):
            t = s2t(dur) if j == 0 else 0
            msgs.append(mido.Message('note_off', note=p, velocity=0, channel=ch, time=t))
    return msgs


def make_synbass_test(path):
    mid = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack(); mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    # 4-voice chord, 18 stabs ≈ 6 s
    for m in _stab_pattern(38, 0, [42, 54, 58, 61], 18):
        tr.append(m)
    mid.save(path)


def make_contrabass_test(path):
    mid = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack(); mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    # single sub-bass pitch, 18 stabs (matches the faded pattern: 88% same-pitch)
    for m in _stab_pattern(43, 0, [27], 18):
        tr.append(m)
    mid.save(path)


def make_chord_change_test(path):
    """Two chord runs back-to-back — tests the crossfade between merged notes."""
    mid = mido.MidiFile(ticks_per_beat=TPB)
    tr = mido.MidiTrack(); mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    # Chord A: 9 stabs (~3s), then chord B: 9 stabs (~3s)
    for m in _stab_pattern(38, 0, [42, 54, 58, 61], 9):
        tr.append(m)
    for m in _stab_pattern(38, 0, [37, 49, 53, 56], 9):
        tr.append(m)
    mid.save(path)


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    proj = os.path.dirname(here)
    sys.path.insert(0, proj)
    out = os.path.join(here, "samples")
    os.makedirs(out, exist_ok=True)

    from midi import parse
    from mix import render

    cases = [
        ("legato_synbass", make_synbass_test),
        ("legato_contrabass", make_contrabass_test),
        ("legato_chord_change", make_chord_change_test),
    ]
    for name, fn in cases:
        mp = os.path.join(out, f"{name}.mid")
        fp = os.path.join(out, f"{name}.flac")
        fn(mp)
        print(f"\n=== {name} ===")
        result = parse(mp)
        render(result, fp)
    print(f"\nDone. Files in {out}/")
