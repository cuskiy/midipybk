"""Centralized constants used across modules.

Everything here is a constant of the renderer. No runtime quality knobs:
the project follows the UNIX philosophy of one good default. If you want
a different sound, edit the value and rebuild your ear.

Parameter dependency notes (v160):
  BLOCK_SIZE           — used by mix/dsp_module ring buffer sizing. If
                         you change it, every DspModule automatically
                         adjusts ring_len. Raising it improves throughput
                         at the cost of latency; lowering below 512 will
                         start showing per-block overhead in hot loops.
  PARALLEL_MIN_*       — gates for ProcessPoolExecutor fan-out. The
                         spawn overhead of a fresh numpy/scipy import is
                         ~0.5-1s per worker, so small jobs stay serial.
  SYMPA_*              — sympathetic resonance tuning. SYMPA_WINDOW is
                         derived from MAX_PEDAL_SUSTAIN so the two
                         "maximum reach of an active note" constants
                         stay in sync.
  ADDITIVE_*           — low-level additive synthesis tuning. These are
                         ear-chosen thresholds and their acceptable
                         range is empirical; edit with test_golden.py
                         as your safety net.
"""

# ── MIDI parser ──────────────────────────────────────────────────────
MAX_PEDAL_SUSTAIN: float = 5.0          # cap pedal-held note duration (s)
MAX_NOTE_DUR: float = 30.0             # absolute cap on any note duration (s)
GHOST_DUR_THRESH: float = 0.012        # notes shorter than this are discarded (s)

# ── Legato merge ─────────────────────────────────────────────────
# Some MIDI files express sustained chord pads as repeated short notes
# (e.g. faded.mid synbass: dur=0.292, IOI=0.333 → 41 ms gap, 3 Hz AM).
# For inherently sustained instruments we merge consecutive same-pitch
# same-channel notes whose gap is below LEGATO_MAX_GAP into a single
# long note. This eliminates the retrigger AM at the source — no
# spectrum/filter trick can fix it after the fact.
#
# Excluded by design: percussive families (piano/guitar/pluck/perc)
# where each retrigger IS the music; bass (articulated by design);
# lead (user feedback says v173 lead is fine — don't risk articulation
# loss).
LEGATO_MAX_GAP: float = 0.08
LEGATO_INSTRUMENTS: frozenset = frozenset({"synbass", "contrabass"})

# ── Mix pipeline ─────────────────────────────────────────────────────
CC_FLOOR: float = 0.02                  # CC7/CC11 floor (avoids hard mute)
CC_SCALE: float = 0.98                  # = 1 - CC_FLOOR
BLOCK_SIZE: int = 4096                  # block size for DspChain iteration
CC7_LAW_EXP: float = 1.5                # GM volume law gain = (CC7/127)^EXP

# ── Sympathetic resonance (piano-family) ─────────────────────────────
SYMPA_GAIN: float = 0.00035             # per-pair amplitude before density norm
SYMPA_MAX_H: int = 8                    # max harmonic order to consider
SYMPA_TOLERANCE: float = 0.006          # relative freq tolerance for resonance
SYMPA_MAX_NOTES: int = 40               # cap per window (not global!)
SYMPA_WINDOW: float = MAX_PEDAL_SUSTAIN * 0.8   # derived — keeps in sync (#8)

# ── Parallel rendering ───────────────────────────────────────────────
PARALLEL_MIN_TRACKS: int = 4            # need at least this many tracks
PARALLEL_MIN_CORES: int = 3             # need at least this many CPU cores
PARALLEL_MIN_TOTAL_NOTES: int = 50      # and at least this many notes total (#23)

# ── Additive synthesis tuning ────────────────────────────────────────
ADDITIVE_PARTIAL_THRESHOLD: float = 0.0003   # drop partials below this amplitude
ADDITIVE_NID_PHASE_OFFSET: float = 2.399     # phase decorrelation per nid step
ADDITIVE_NYQUIST_FADE_RATIO: float = 0.7     # cosine fade from 0.7 × Nyquist
