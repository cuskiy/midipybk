# Code Conduct

Lessons from v140→v167. Not a mandatory checklist — a memory, for the
next time someone (human or AI) is about to make a bad decision.

## The goal

**Golden Sunset.** Every change is measured against whether it makes
Golden Sunset sound more like itself. Features that don't serve this
goal don't belong in the project. The renderer is not a general-purpose
toolkit; it is one thing aimed at one outcome.

## Principles

**KISS — the chain does subtraction.** v162→v164 got worse by *adding*:
master air shelf, presence boost, boom_cut on every instrument, comp
threshold 0.30, extra early reflections. v165 got better by *deleting*
all of it. Every new module is a potential source of unnatural color.
The default action on any proposed new processing stage is: don't.

**UNIX — one good default.** No `--quality`, no `--profile`, no runtime
quality switches. If you want a different sound, edit the value and
rebuild your ear. `main.py` is input → output; everything else is
constants. Options are how projects die.

**Root cause, not parameters.** If tuning doesn't fix it, the engine
is wrong. Contrabass at 31 Hz was unfixable with additive synthesis —
stacked sines can't produce rich sub-bass spectra. Switching to KS
solved it in one commit after three rounds of wasted rolloff tuning.
Before turning another knob, ask: is this the right model for this
instrument at this register?

**Don't fabricate problems.** When reading existing code, separate
*cosmetic* (dead comments, 0 dB no-ops, stylistic drift) from *root*
(wrong output, crashes, audible artifacts). Cosmetic issues are not
bugs. "I found ten problems in this working file" is almost always
AI ego, not engineering. If the listening test passes and the
automated tests pass, the code is correct — whatever a linter thinks.

**Don't blindly copy, don't blindly reject.** v48 had warmth that v164
lost, but v48 also had no `b2` formula, no `formant_decay`, no KS
improvements, no sympathetic resonance. Keep what's proven. Inherit
what's better. Reason about each parameter. "Because v48 did it"
is not a reason. Physics of the instrument is a reason.

## The v162→v167 synthesis lesson

Organic timbre has three load-bearing ingredients that took six
versions of backtracking to re-learn:

1. **`rolloff ≈ 1.0` is natural.** Pushing toward 0.6 for "brightness"
   produces bells and doorbells, not pianos. The 1/k harmonic series
   is what real bowed/struck strings do.

2. **Organic features are load-bearing, not decoration.** `micro`,
   `noise`, `drive`, `coupling`, `spec_b` are what blend bare partials
   into cohesive timbre. Without them the ear hears "敲盆" (beating
   a metal pan). Keep them high — piano micro=0.75, drive=0.07,
   coupling=0.6, etc.

3. **Post-processing is where warmth dies.** Master EQ should be
   nearly flat. Compression threshold ≥ 0.45. No per-instrument
   `boom_cut` except where physically justified (contrabass, pad
   sub buildup). Every dB of "presence" boost you add is a dB of
   warmth you subtracted from the synth engine's output.

## Multi-track phase coherence

Any engine that may be instantiated multiple times on the same pitch
MUST decorrelate on `nid` (note/instance ID). If two instances produce
bit-identical waveforms, N stacked tracks sum to N× peak (not √N×)
and crush the compressor.

| Engine   | Decorrelation method                              |
|----------|---------------------------------------------------|
| Additive | `ph_nid = nid * 2.399` added to phase accumulator |
| FM       | Same `nid * 2.399` on carrier phase               |
| KS       | Sub-period output delay (`nid * period / 5.3`)    |

Stride: `nid_base = track_idx * 100000`. Worker tracks must not collide.

## CC processing

- **Zero-order hold** for all CC values — GM says a CC takes effect
  immediately and holds until the next event. Linear interpolation
  between sparse events fabricates ramps that aren't in the score.
- **GM defaults** until the first event, always.
- **Smoothing is downstream**, not inside interpolation.

## Common pitfalls

- `sosfiltfilt` doubles dB — a "+1 dB" parameter gives +2 dB effective
  because the filter runs forward then backward. Halve your numbers.
- KS delay lines converge to the same steady state regardless of
  excitation. Decorrelation must happen *after* synthesis, not by
  varying the initial excitation.
- Empty CC lists should short-circuit to a scalar default, not
  allocate a full-buffer array. The 100+ MB wasted here is silent.
- Deterministic phase = correlation. RNG-seeded noise on top of
  identical oscillator phase doesn't count as decorrelation.

## Testing methodology

1. **Real MIDI files**, not just synthetic patterns. Real arrangements
   expose edge cases (extreme registers, aggressive CC automation,
   multi-track unison) that synthetic tests miss.

2. **Multi-track stacking test**: render the same note with nid 0..4,
   sum, check combined peak < 3.5× individual peak.

3. **Extreme register test**: every instrument at its lowest and
   highest reasonable MIDI notes. Check harmonic content reaches
   above the fundamental, especially below 100 Hz.

4. **Full-pipeline render**: don't test synth engines in isolation.
   Normalization → CC → compression → EQ can amplify or mask issues
   invisible at the engine level.

5. **If a test file has a `__main__` runner, that runner MUST actually
   call the assertions.** A test that only prints metrics is not a
   test. (See v167→v168 test_golden fix.)

## Versioning

Version numbers go up. A released version is never overwritten. Every
`_version.py` bump must correspond to a real change — either to code
or to this document.
