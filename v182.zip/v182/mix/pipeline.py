"""Top-level render pipeline: track dispatch, master chain, FLAC output."""
from __future__ import annotations

import math
import os
import time
import zlib
from collections import defaultdict, Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace as dc_replace
from typing import Dict, List, Optional, Tuple

import numpy as np
import soundfile as sf
from scipy.signal import oaconvolve, butter, sosfilt

from config import PARALLEL_MIN_TRACKS, PARALLEL_MIN_CORES, PARALLEL_MIN_TOTAL_NOTES
from schema import Note, ChannelData, PipelineConfig, ParseResult
from synth import SR, TIMBRES
from synth.dsp import BoundedCache
from synth.gm import inst_mix
from .spatial import apply_hrtf, early_reflections, binaural_enhance
from .master import fdn_reverb_ir, compress, reverb_darken
from .track_render import render_track, _tail_estimate
from .routing import split_and_merge_tracks, track_channel

_SPATIAL_OVERRIDES: dict = dict(
    az_scale=1.15, er_wet=0.10, pinna=True, immersive_er=True,
    reverb_wet=0.065, reverb_rt60=1.8, reverb_predelay=0.018,
)

_IR_CACHE: Dict[Tuple[float, float], Tuple[np.ndarray, np.ndarray]] = {}
_HP_MASTER: Optional[np.ndarray] = None

# IR truncation: cut tail when trailing energy falls below this fraction.
_IR_ENERGY_THRESHOLD = 1e-4   # ≈ -80 dB


# v160 #14: ModuleCache registry. Each module that holds module-level
# lazy caches registers a clear callback here, and clear_caches() walks
# the registry. Previously clear_caches() had to know about every
# module's private variables and was a bug magnet every time a new
# cache was added.
_CLEAR_HOOKS: "List[callable]" = []


def register_clear_hook(hook) -> None:
    """Register a zero-arg callable to be run by ``clear_caches``.

    Each module with module-level lazy state (filter SOS, IR dict,
    whatever) calls this at import time with a lambda that resets the
    module's state. ``clear_caches`` will run all registered hooks.
    """
    _CLEAR_HOOKS.append(hook)


def clear_caches() -> None:
    """Clear every registered per-process cache.

    Safe to call at any time. Used mostly by tests that need a clean
    slate between renders. Worker processes have their own independent
    caches which are cleared when the worker exits.
    """
    BoundedCache.clear_all()
    _IR_CACHE.clear()
    for hook in _CLEAR_HOOKS:
        try:
            hook()
        except Exception:
            pass
    # Legacy caches still owned by pipeline.py itself
    global _HP_MASTER
    _HP_MASTER = None


def _register_builtin_hooks() -> None:
    """Register the clear hooks for every module that has module-level state."""
    def _clear_spatial():
        from . import spatial as _sp
        _sp._PINNA_SOS = None
        _sp._ER_HP = None
        _sp._XOVER = None
        _sp._XFEED_LP = None
        _sp._CEILING_SOS = None

    def _clear_master():
        import mix.master as _m
        _m._REV_DARK_SOS = None

    register_clear_hook(_clear_spatial)
    register_clear_hook(_clear_master)


_register_builtin_hooks()


def _truncate_ir(ir: np.ndarray) -> np.ndarray:
    """Drop the tail once trailing energy falls below threshold."""
    if len(ir) == 0:
        return ir
    energy = ir * ir
    total = float(np.sum(energy))
    if total < 1e-20:
        return ir
    cum = np.cumsum(energy)
    keep = int(np.searchsorted(cum, total * (1.0 - _IR_ENERGY_THRESHOLD)))
    return ir[:max(keep + 1, SR // 4)]


def _ir_cache_dir() -> Optional[str]:
    """Location of the on-disk FDN IR cache. Returns None if the cache
    directory cannot be created (read-only FS, sandboxed CI, etc.) so
    the caller transparently falls back to in-memory only.
    """
    base = os.environ.get('XDG_CACHE_HOME') or os.path.expanduser('~/.cache')
    path = os.path.join(base, 'goldenscore')
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        return None
    return path


def _get_ir(room: float, rt60: float) -> Tuple[np.ndarray, np.ndarray]:
    """Cached FDN reverb IR lookup.

    Lookup order: in-memory → on-disk (`~/.cache/goldenscore/ir_<crc32>.npz`) →
    freshly generated. Disk cache avoids the ~1s generation cost across runs.
    """
    key = (round(room, 2), round(rt60, 2))
    if key in _IR_CACHE:
        return _IR_CACHE[key]

    # Disk lookup
    cache_dir = _ir_cache_dir()
    disk_path: Optional[str] = None
    if cache_dir is not None:
        key_bytes = f"{key[0]:.2f},{key[1]:.2f}".encode('utf-8')
        fname = f"ir_{zlib.crc32(key_bytes):08x}.npz"
        disk_path = os.path.join(cache_dir, fname)
        if os.path.exists(disk_path):
            try:
                data = np.load(disk_path)
                irl, irr = data['irl'], data['irr']
                _IR_CACHE[key] = (irl, irr)
                print(f"  reverb IR     cached  rt60={rt60}s room={room} (IR {len(irl)/SR:.2f}s)", flush=True)
                return _IR_CACHE[key]
            except Exception:
                pass  # Corrupted cache, regenerate

    # Fresh generation
    t0 = time.time()
    irl, irr = fdn_reverb_ir(room_size=room, rt60=rt60)
    irl, irr = _truncate_ir(irl), _truncate_ir(irr)
    _IR_CACHE[key] = (irl, irr)
    if disk_path is not None:
        try:
            np.savez(disk_path, irl=irl, irr=irr)
        except Exception:
            pass  # Disk cache is best-effort
    print(f"  reverb IR     {time.time()-t0:5.2f}s  rt60={rt60}s room={room} (IR {len(irl)/SR:.2f}s)", flush=True)
    return _IR_CACHE[key]


def _print_song_info(sub_tracks: list, buf_len: int) -> None:
    total_notes = sum(len(ns) for _, ns, _ in sub_tracks)
    dur = buf_len / SR
    inst = Counter()
    for nm, ns, _ in sub_tracks:
        inst[nm] += len(ns)
    inst_str = " ".join(f"{nm}:{c}" for nm, c in inst.most_common())
    print(f"  song          {dur:5.1f}s  {total_notes} notes  {len(sub_tracks)} tracks", flush=True)
    print(f"  instruments   {inst_str}", flush=True)


def _ensure_hp_master() -> None:
    global _HP_MASTER
    if _HP_MASTER is None:
        _HP_MASTER = butter(3, 20.0, btype='high', fs=SR, output='sos')


def _get_hp_master() -> np.ndarray:
    _ensure_hp_master()
    assert _HP_MASTER is not None
    return _HP_MASTER


# ── Master chain ─────────────────────────────────────────────────────

def _master_chain(
    mix_l: np.ndarray, mix_r: np.ndarray,
    rev_mono: np.ndarray, cfg: PipelineConfig,
    irl: np.ndarray, irr: np.ndarray, buf_len: int,
) -> Tuple[np.ndarray, np.ndarray, float]:
    hp = _get_hp_master()
    mix_l = sosfilt(hp, mix_l)
    mix_r = sosfilt(hp, mix_r)

    if cfg.er_wet > 0:
        erl, err = early_reflections(mix_l, mix_r,
                                     immersive=cfg.immersive_er, pinna=cfg.pinna)
        mix_l += erl * cfg.er_wet
        mix_r += err * cfg.er_wet

    wet = cfg.reverb_wet
    mix_l *= (1.0 - wet)
    mix_r *= (1.0 - wet)
    pd = int(cfg.reverb_predelay * SR)
    use_irl = np.concatenate([np.zeros(pd), irl]) if pd > 0 else irl
    use_irr = np.concatenate([np.zeros(pd), irr]) if pd > 0 else irr

    from .track_render import _get_hp
    rev_filt = reverb_darken(sosfilt(_get_hp(120.0), rev_mono))
    # oaconvolve: overlap-add. Faster than fftconvolve when one input is much
    # shorter than the other (long mix × short truncated IR).
    mix_l += oaconvolve(rev_filt, use_irl, mode='full')[:buf_len] * wet
    mix_r += oaconvolve(rev_filt, use_irr, mode='full')[:buf_len] * wet
    if cfg.immersive_er:
        offset = int(0.002 * SR)
        mix_r = np.roll(mix_r, offset)
        mix_r[:offset] = 0

    mix_l, mix_r = compress(mix_l, mix_r, cfg.comp_thresh, cfg.comp_ratio,
                            cfg.comp_att_ms, cfg.comp_rel_ms,
                            knee_db=3.0, sc_hp=cfg.comp_sc_hp)
    if cfg.immersive_er:
        mix_l, mix_r = binaural_enhance(mix_l, mix_r)
    pk = max(np.max(np.abs(mix_l)), np.max(np.abs(mix_r)), 1e-10)
    mix_l *= cfg.peak_limit / pk
    mix_r *= cfg.peak_limit / pk
    return mix_l, mix_r, pk


# ── Parallel track-render wrapper ────────────────────────────────────

def _render_track_worker(args: tuple) -> Tuple[int, str, Optional[np.ndarray], Optional[np.ndarray]]:
    track_idx, inst_name, notes, pan_cc, chan_data, buf_len, track_gain, density_scale, cfg = args
    result = render_track(inst_name, notes, pan_cc, chan_data,
                          buf_len, track_gain, density_scale, cfg, track_idx)
    return (track_idx, inst_name,
            result.audio if result.audio is not None else None,
            result.reverb_bus if result.reverb_bus is not None else None)


# ── Track preparation ────────────────────────────────────────────────

def _prepare_tracks(
    notes: List[Note], channel_pans: Dict[int, int],
    region: Optional[Tuple[Optional[float], Optional[float]]],
) -> Tuple[list, int, float, Optional[float]]:
    sub_tracks = split_and_merge_tracks(notes, channel_pans)
    reg_start = region[0] if region and region[0] is not None else 0.0
    reg_end = region[1] if region and region[1] is not None else None

    if reg_start > 0 or reg_end is not None:
        clipped: list = []
        for nm, ns, pc in sub_tracks:
            kept: list = []
            for n in ns:
                if n.start + n.dur <= reg_start:
                    continue
                if reg_end is not None and n.start >= reg_end:
                    continue
                if reg_end is not None and n.start + n.dur > reg_end:
                    kept.append(n._replace(dur=max(reg_end - n.start, 0.05)))
                else:
                    kept.append(n)
            if kept:
                clipped.append((nm, kept, pc))
        sub_tracks = clipped

    buf_len = SR * 10
    for nm, ns, _ in sub_tracks:
        tb = TIMBRES.get(nm) or TIMBRES["default"]
        for note in ns:
            end = int((note.start + note.dur + _tail_estimate(tb, note.dur)) * SR) + SR
            if end > buf_len:
                buf_len = end
    buf_len += SR
    if reg_end is not None:
        buf_len = min(buf_len, int(reg_end * SR) + SR * 2)

    sub_tracks = [(nm, sorted(ns, key=lambda n: n.start), pc)
                  for nm, ns, pc in sub_tracks]
    return sub_tracks, buf_len, reg_start, reg_end


def _should_parallelize(n_tracks: int, n_total_notes: int,
                        max_jobs: Optional[int] = None) -> Tuple[bool, int]:
    """Returns (use_parallel, n_workers). max_jobs: None=auto, 0=serial."""
    if max_jobs is not None and max_jobs == 0:
        return False, 1
    if n_tracks < PARALLEL_MIN_TRACKS:
        return False, 1
    if (os.cpu_count() or 1) < PARALLEL_MIN_CORES:
        return False, 1
    if n_total_notes < PARALLEL_MIN_TOTAL_NOTES:
        return False, 1
    n_workers = min(n_tracks, os.cpu_count() or 1)
    if max_jobs is not None and max_jobs > 0:
        n_workers = min(n_workers, max_jobs)
    return True, n_workers


# ── Mix tracks ───────────────────────────────────────────────────────

def _resolve_azimuth(inst_name: str, pan_cc: Optional[int],
                     used_az: set, inst_az: dict,
                     az_scale: float) -> float:
    if pan_cc is not None and pan_cc not in (0, 64):
        az = (pan_cc - 64) / 64.0 * 55.0
    elif inst_mix(inst_name).center_lock:
        az = 0.0
    elif inst_name in inst_az:
        az = inst_az[inst_name]
    else:
        az = inst_mix(inst_name).pan
        if az in used_az:
            for off in [8, -8, 16, -16, 24, -24]:
                cand = az + off
                if abs(cand) <= 55 and cand not in used_az:
                    az = cand
                    break
        used_az.add(az)
        inst_az[inst_name] = az
    return float(np.clip(az * az_scale, -65, 65))


def _mix_tracks(
    sub_tracks: list, ch_data: Dict[int, ChannelData],
    cfg: PipelineConfig, buf_len: int, stems: bool = False,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, list]:
    """Render and mix. Each track is HRTF-panned and accumulated
    immediately, then discarded — peak memory is O(buf_len) not
    O(n_tracks × buf_len)."""
    n_sub = max(len(sub_tracks), 1)
    density_scale = 1.0 / math.sqrt(max(n_sub / 4.0, 1.0))

    mix_l, mix_r = np.zeros(buf_len), np.zeros(buf_len)
    rev_mono = np.zeros(buf_len)
    used_az: set = set()
    inst_az: dict = {}
    stem_data: list = []

    work_items: list = []
    for track_idx, (inst_name, notes, pan_cc) in enumerate(sub_tracks):
        chan_data = ch_data.get(track_channel(notes), ChannelData())
        work_items.append((track_idx, inst_name, notes, pan_cc,
                           chan_data, buf_len, cfg.track_gain,
                           density_scale, cfg))

    n_tracks = len(sub_tracks)
    n_total_notes = sum(len(ns) for _, ns, _ in sub_tracks)
    use_parallel, n_workers = _should_parallelize(
        n_tracks, n_total_notes, cfg.max_jobs)
    t_render = time.time()

    def _log_done(done_idx, tidx, iname, t_track):
        n_notes = len(sub_tracks[tidx][1])
        print(f"  [{done_idx:>2d}/{n_tracks}] {iname:<12s}{n_notes:>4d} notes  {t_track:5.2f}s",
              flush=True)

    def _mix_one(tidx, iname, audio, rev_bus):
        if audio is None:
            return
        if rev_bus is not None:
            rev_mono[:] += rev_bus
        pan_cc = sub_tracks[tidx][2]
        az = _resolve_azimuth(iname, pan_cc, used_az, inst_az, cfg.az_scale)
        left, right = apply_hrtf(audio, az, pinna=cfg.pinna)
        mix_l[:] += left
        mix_r[:] += right
        if stems:
            stem_data.append((iname, left, right))

    if use_parallel:
        try:
            with ProcessPoolExecutor(max_workers=n_workers) as pool:
                futures = {pool.submit(_render_track_worker, w): (w[0], time.time())
                           for w in work_items}
                done = 0
                for future in as_completed(futures):
                    track_idx, t_sub = futures[future]
                    tidx, iname, audio, rev_bus = future.result()
                    _mix_one(tidx, iname, audio, rev_bus)
                    done += 1
                    _log_done(done, tidx, iname, time.time() - t_sub)
        except Exception:
            use_parallel = False

    if not use_parallel:
        for done, w in enumerate(work_items, 1):
            t_sub = time.time()
            tidx, iname, audio, rev_bus = _render_track_worker(w)
            _mix_one(tidx, iname, audio, rev_bus)
            _log_done(done, tidx, iname, time.time() - t_sub)

    mode = f"parallel x{n_workers}" if use_parallel else "serial"
    print(f"  tracks        {time.time()-t_render:5.2f}s  ({mode})", flush=True)
    return mix_l, mix_r, rev_mono, stem_data


# ── Finalize ─────────────────────────────────────────────────────────

def _finalize(
    mix_l: np.ndarray, mix_r: np.ndarray,
    rev_mono: np.ndarray, cfg: PipelineConfig,
    irl: np.ndarray, irr: np.ndarray, buf_len: int,
    out_file: str, stems: bool, stems_dir: Optional[str],
    stem_data: list, out_start: int, out_end: int, has_audio: bool,
) -> None:
    if has_audio:
        t_master = time.time()
        mix_l, mix_r, pk = _master_chain(mix_l, mix_r, rev_mono, cfg, irl, irr, buf_len)
        print(f"  master        {time.time()-t_master:5.2f}s  (EQ + comp + reverb)", flush=True)
    else:
        pk = 1e-10
    t_write = time.time()
    sl = slice(out_start, out_end)
    stereo = np.column_stack((mix_l[sl], mix_r[sl]))
    # Fade-in/out when region slicing cuts into sustaining notes
    fade_n = min(int(SR * 0.008), len(stereo))  # 8ms cosine fade
    if out_start > 0 and fade_n > 1:
        fade_in = 0.5 * (1 - np.cos(np.linspace(0, np.pi, fade_n)))
        stereo[:fade_n] *= fade_in[:, np.newaxis]
    if out_end < buf_len and fade_n > 1:
        fade_out = 0.5 * (1 + np.cos(np.linspace(0, np.pi, fade_n)))
        stereo[-fade_n:] *= fade_out[:, np.newaxis]
    lsb = 1.0 / (2**23)
    dither = (np.random.default_rng(42).random(stereo.shape)
              - np.random.default_rng(137).random(stereo.shape)) * lsb
    sf.write(out_file, np.clip(stereo + dither, -1, 1), SR,
             format="FLAC", subtype="PCM_24")
    print(f"  write         {time.time()-t_write:5.2f}s  → {out_file}  ({(out_end-out_start)/SR:.1f}s audio)", flush=True)

    if stems and stem_data:
        stem_out = stems_dir or (out_file.rsplit(".", 1)[0] + "_stems")
        os.makedirs(stem_out, exist_ok=True)
        groups: dict = defaultdict(lambda: ([], []))
        for nm, sl_, sr_ in stem_data:
            groups[nm][0].append(sl_)
            groups[nm][1].append(sr_)
        master_gain = cfg.peak_limit / pk if pk > 1e-10 else 1.0
        for nm, (ls, rs) in groups.items():
            cl = sum(ls)[out_start:out_end] * master_gain
            cr = sum(rs)[out_start:out_end] * master_gain
            # #32 fix: single normalization pass. Previously the stem
            # was scaled by master_gain AND then independently rescaled
            # if the result exceeded 1.0 — the two cancelled each other
            # non-deterministically depending on which stem's peak was
            # louder than the master sum. Now: normalize only if the
            # master-gained stem still clips, with a single clear
            # scale factor.
            spk = max(np.max(np.abs(cl)), np.max(np.abs(cr)))
            if spk > cfg.peak_limit:
                scale = cfg.peak_limit / spk
                cl *= scale
                cr *= scale
            sd = np.column_stack((cl, cr))
            # Same fade as mix to prevent pops on region boundaries
            if out_start > 0 and fade_n > 1:
                sd[:fade_n] *= fade_in[:, np.newaxis]
            if out_end < buf_len and fade_n > 1:
                sd[-fade_n:] *= fade_out[:, np.newaxis]
            # #6 fix: use zlib.crc32 for deterministic cross-process seed.
            # Python's built-in hash() is PYTHONHASHSEED-randomized.
            rng_seed = zlib.crc32(nm.encode('utf-8'))
            sd_dither = (np.random.default_rng(rng_seed).random(sd.shape)
                         - np.random.default_rng(rng_seed + 1).random(sd.shape)) * lsb
            sf.write(os.path.join(stem_out, f"{nm}.flac"),
                     np.clip(sd + sd_dither, -1, 1), SR,
                     format="FLAC", subtype="PCM_24")
        print(f"  stems         → {stem_out}/ ({len(groups)} instruments)", flush=True)


def _print_cache_stats() -> None:
    stats = BoundedCache.all_stats()
    if not stats:
        return
    print("  cache stats", flush=True)
    for name, hits, misses, evicts, size, maxsize in stats:
        total = hits + misses
        rate = (100 * hits / total) if total else 0.0
        print(f"    {name:<22s} {hits:>6d}h {misses:>4d}m  {rate:5.1f}%  "
              f"size={size}/{maxsize}  evict={evicts}", flush=True)


# ── Top-level render ─────────────────────────────────────────────────

def render(
    result: ParseResult, out_file: str,
    spatial: bool = False,
    stems: bool = False, stems_dir: Optional[str] = None,
    region: Optional[Tuple[Optional[float], Optional[float]]] = None,
    max_jobs: Optional[int] = None,
) -> None:
    """Render MIDI to 24-bit FLAC."""
    overrides = dict(_SPATIAL_OVERRIDES) if spatial else {}
    if max_jobs is not None:
        overrides['max_jobs'] = max_jobs
    cfg = dc_replace(PipelineConfig(), **overrides) if overrides else PipelineConfig()
    t_total = time.time()
    irl, irr = _get_ir(cfg.reverb_room, cfg.reverb_rt60)
    _ensure_hp_master()

    sub_tracks, buf_len, reg_start, reg_end = _prepare_tracks(
        result.notes, result.channel_pans, region)
    _print_song_info(sub_tracks, buf_len)
    mix_l, mix_r, rev_mono, stem_data = _mix_tracks(
        sub_tracks, result.ch_data, cfg, buf_len, stems=stems)

    out_start = int(reg_start * SR) if reg_start > 0 else 0
    out_end = min(int(reg_end * SR) if reg_end is not None else buf_len, buf_len)
    has_audio = len(sub_tracks) > 0 and max(
        np.max(np.abs(mix_l)), np.max(np.abs(mix_r))) > 1e-10

    _finalize(mix_l, mix_r, rev_mono, cfg, irl, irr, buf_len,
              out_file, stems, stems_dir, stem_data,
              out_start, out_end, has_audio)
    print(f"  total         {time.time()-t_total:5.2f}s", flush=True)
    _print_cache_stats()