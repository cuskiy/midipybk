"""Stateful DSP modules for the per-track effects chain.

Each module carries filter zi state, ring buffers, and sample counters
across calls. The chain is iterated in BLOCK_SIZE chunks by
mix.track_render._process_chain_blocked, so module state is exercised
in true streaming fashion: ring buffer wraparound, filter zi continuity,
and per-block CC re-sampling all happen on every block.

v159 wave A fixes:
  - #1 ring buffers now sized for BLOCK_SIZE + max_delay so that
       (wpos + arange(BLOCK_SIZE)) % ring_len produces unique indices
  - #3 BrightnessModule replaced: fixed LTI shelf + per-sample wet/dry
       mix avoids using a changing SOS with stale zi state
"""
import math
from typing import List, Optional
import numpy as np
from scipy.signal import sosfilt, butter
from config import BLOCK_SIZE
from synth.timbre import SR, biquad_high_shelf


class DspModule:
    """Base protocol for block-based audio processing."""
    def process(self, block: np.ndarray) -> np.ndarray:
        return block

    def reset(self) -> None:
        pass


class FilterModule(DspModule):
    """sosfilt wrapper with zi state across blocks."""
    def __init__(self, sos: np.ndarray) -> None:
        self.sos = sos
        self.zi: Optional[np.ndarray] = None

    def process(self, block: np.ndarray) -> np.ndarray:
        if self.zi is None:
            self.zi = np.zeros((self.sos.shape[0], 2))
        out, self.zi = sosfilt(self.sos, block, zi=self.zi)
        return out

    def reset(self) -> None:
        self.zi = None


class BrightnessModule(DspModule):
    """CC74-driven brightness via fixed LTI shelf + wet/dry mix.

    The v158 implementation rebuilt a high-shelf SOS per block with a
    different gain and reused the previous SOS's zi state — mathematically
    meaningless, and audibly clicky at every CC74 transition. The fix:

      1. Build ONE fixed +6 dB high shelf at 4 kHz, once.
      2. Filter the input with that shelf (proper LTI, continuous zi).
      3. Per sample, mix dry and wet with a coefficient derived from
         CC74. This is a time-varying GAIN on a static signal, which is
         safe — gain interpolation introduces no phase artifacts.

    CC74 = 0.504 (GM default) → mix coefficient 0 → pure dry (flat response).
    CC74 = 1.0                → mix coefficient +1 → pure bright (+6 dB shelf).
    CC74 = 0.0                → mix coefficient -1 → pure dark (-6 dB shelf).

    The dark side is implemented by subtracting the shelf contribution.
    """
    _REF_GAIN_DB = 4.5     # v158 parity: (b74 - 0.504)/0.504 * 4.5 dB
    _REF_FC = 4000.0
    _MID = 64.0 / 127.0    # GM default CC74

    def __init__(self, cc_curve: np.ndarray, buf_len: int) -> None:
        if len(cc_curve) < buf_len:
            self.cc_curve = np.pad(cc_curve, (0, buf_len - len(cc_curve)), mode='edge')
        else:
            self.cc_curve = cc_curve
        self.sos = biquad_high_shelf(self._REF_FC, self._REF_GAIN_DB)
        self.zi: Optional[np.ndarray] = None
        self.sample_pos = 0

    def process(self, block: np.ndarray) -> np.ndarray:
        n = len(block)
        if self.zi is None:
            self.zi = np.zeros((self.sos.shape[0], 2))
        # Full-brightness wet signal (continuous LTI — zi always valid)
        wet, self.zi = sosfilt(self.sos, block, zi=self.zi)
        # Mix coefficient from CC74 per sample
        cc_slice = self.cc_curve[self.sample_pos:self.sample_pos + n]
        if len(cc_slice) < n:
            cc_slice = np.pad(cc_slice, (0, n - len(cc_slice)), mode='edge')
        mix = (cc_slice - self._MID) / self._MID   # in [-1, +1]
        # Output = dry + mix*(wet - dry). mix ∈ [-1, +1], so at mix=+1 we
        # get full wet, at mix=-1 we get dry - shelf (dark).
        out = block + mix * (wet - block)
        self.sample_pos += n
        return out

    def reset(self) -> None:
        self.zi = None
        self.sample_pos = 0


class _RingBufferBase(DspModule):
    """Shared ring-buffer sizing logic.

    The ring must hold at least BLOCK_SIZE + max_delay samples so that
    within a single process() call, write indices and read indices
    never collide. This fixes v158's silent-chorus bug (#1).
    """
    @staticmethod
    def _ring_size(max_delay_samples: int) -> int:
        # +4 guard against fractional-read interpolation overreach
        return BLOCK_SIZE + max_delay_samples + 4


class ChorusModule(_RingBufferBase):
    """Two modulated-delay voices with dynamic depth from CC93 curve."""
    _RATES = [(0.7, 0.0), (1.1, 2.1)]
    _BASE_DELAY = 0.008
    _MOD_DEPTH = 0.004
    _MIX = 0.15

    def __init__(self, depth_curve: np.ndarray, buf_len: int) -> None:
        if len(depth_curve) < buf_len:
            self.depth_curve = np.pad(depth_curve, (0, buf_len - len(depth_curve)), mode='edge')
        else:
            self.depth_curve = depth_curve
        self.max_delay = int(SR * (self._BASE_DELAY + self._MOD_DEPTH)) + 2
        self.ring_len = self._ring_size(self.max_delay)
        self.ring = np.zeros(self.ring_len)
        self.wpos = 0
        self.sample_count = 0

    def process(self, block: np.ndarray) -> np.ndarray:
        n = len(block)
        # Per-sample depth over this block
        depth_block = self.depth_curve[self.sample_count:self.sample_count + n]
        if len(depth_block) < n:
            depth_block = np.pad(depth_block, (0, n - len(depth_block)), mode='edge')
        # Item 21: bypass only when the WHOLE block stays below threshold;
        # otherwise depth starts changing mid-block and we'd miss the
        # onset by up to one BLOCK_SIZE.
        if float(np.max(depth_block)) < 0.01:
            indices = (self.wpos + np.arange(n)) % self.ring_len
            self.ring[indices] = block
            self.wpos = (self.wpos + n) % self.ring_len
            self.sample_count += n
            return block
        # Write block to ring — indices are guaranteed unique because
        # ring_len >= BLOCK_SIZE + max_delay + 4 > n.
        indices = (self.wpos + np.arange(n)) % self.ring_len
        self.ring[indices] = block
        # Read delayed samples for each voice
        wet = np.zeros(n)
        tv = (np.arange(n) + self.sample_count) / SR
        for rate, phase in self._RATES:
            delay_samples = SR * self._BASE_DELAY + SR * self._MOD_DEPTH * np.sin(
                2 * math.pi * rate * tv + phase)
            read_f = self.wpos + np.arange(n, dtype=np.float64) - delay_samples
            ri0 = np.floor(read_f).astype(np.int64) % self.ring_len
            ri1 = (ri0 + 1) % self.ring_len
            frac = read_f - np.floor(read_f)
            wet += self.ring[ri0] * (1 - frac) + self.ring[ri1] * frac
        wet *= self._MIX
        # Per-sample wet/dry mix using depth_block instead of scalar depth
        rms_in = float(np.sqrt(np.mean(block ** 2)) + 1e-10)
        rms_wet = float(np.sqrt(np.mean(wet ** 2)) + 1e-10)
        if rms_wet > rms_in * self._MIX * 2.0:
            wet *= (rms_in * self._MIX) / rms_wet
        out = block + depth_block * wet
        self.wpos = (self.wpos + n) % self.ring_len
        self.sample_count += n
        return out

    def reset(self) -> None:
        self.ring[:] = 0
        self.wpos = 0
        self.sample_count = 0


class LeslieModule(_RingBufferBase):
    """Leslie speaker: independent LP/HP split + rotor AM/Doppler."""
    _MAX_DELAY_S = 0.0004

    def __init__(self) -> None:
        self.lp_sos = butter(3, 800.0, btype='low', fs=SR, output='sos')
        self.hp_sos = butter(3, 800.0, btype='high', fs=SR, output='sos')
        self.lp_zi: Optional[np.ndarray] = None
        self.hp_zi: Optional[np.ndarray] = None
        self.max_delay = int(self._MAX_DELAY_S * SR) + 2
        self.ring_len = self._ring_size(self.max_delay)
        self.ring = np.zeros(self.ring_len)
        self.wpos = 0
        self.sample_count = 0

    def process(self, block: np.ndarray) -> np.ndarray:
        n = len(block)
        if self.lp_zi is None:
            self.lp_zi = np.zeros((self.lp_sos.shape[0], 2))
            self.hp_zi = np.zeros((self.hp_sos.shape[0], 2))
        lo, self.lp_zi = sosfilt(self.lp_sos, block, zi=self.lp_zi)
        hi, self.hp_zi = sosfilt(self.hp_sos, block, zi=self.hp_zi)
        # Capture per-branch input RMS BEFORE any modulation so we can
        # compensate each branch against its own clean input (item 6
        # fix: v159 compensated `lo+hd` against the whole-block RMS,
        # which hid a small drift because the doppler-interpolated hi
        # branch has slightly lower RMS than the clean high path).
        rms_lo_in = float(np.sqrt(np.mean(lo * lo)) + 1e-10)
        rms_hi_in = float(np.sqrt(np.mean(hi * hi)) + 1e-10)

        tv = (np.arange(n) + self.sample_count) / SR
        hp = 2 * math.pi * 6.8 * tv
        hi *= 1.0 + 0.30 * np.sin(hp)
        # Ring buffer large enough that writes don't alias
        indices = (self.wpos + np.arange(n)) % self.ring_len
        self.ring[indices] = hi
        # Doppler read
        dop = self._MAX_DELAY_S * SR * np.sin(hp + 1.57)
        read_f = self.wpos + np.arange(n, dtype=np.float64) - dop
        ri0 = np.floor(read_f).astype(np.int64) % self.ring_len
        ri1 = (ri0 + 1) % self.ring_len
        frac = read_f - np.floor(read_f)
        hd = self.ring[ri0] * (1 - frac) + self.ring[ri1] * frac

        lo *= 1.0 + 0.15 * np.sin(2 * math.pi * 5.5 * tv + 0.8)
        # Per-branch normalization
        rms_lo_out = float(np.sqrt(np.mean(lo * lo)) + 1e-10)
        rms_hd_out = float(np.sqrt(np.mean(hd * hd)) + 1e-10)
        if rms_lo_out > 1e-10:
            lo *= rms_lo_in / rms_lo_out
        if rms_hd_out > 1e-10:
            hd *= rms_hi_in / rms_hd_out
        out = lo + hd
        self.wpos = (self.wpos + n) % self.ring_len
        self.sample_count += n
        return out

    def reset(self) -> None:
        self.lp_zi = None
        self.hp_zi = None
        self.ring[:] = 0
        self.wpos = 0
        self.sample_count = 0


class ModVibratoModule(_RingBufferBase):
    """CC1-driven pitch vibrato via modulated delay.

    The delay oscillates around a center point so it is always
    positive (reads behind the write head). Previous implementation
    allowed negative delay which read AHEAD of the write position
    into stale ring data, producing periodic clicks at the vibrato
    rate.
    """
    _VIB_RATE = 5.5
    _MAX_CENTS = 50.0

    def __init__(self, mod_curve: np.ndarray, buf_len: int) -> None:
        if len(mod_curve) < buf_len:
            self.mod_curve = np.pad(mod_curve, (0, buf_len - len(mod_curve)), mode='edge')
        else:
            self.mod_curve = mod_curve
        self.peak_delay_samples = (self._MAX_CENTS * 0.000578) / (2 * math.pi * self._VIB_RATE) * SR
        # Ring must hold center + peak so the furthest read is always valid
        self.max_delay = int(self.peak_delay_samples * 2) + 4
        self.ring_len = self._ring_size(self.max_delay)
        self.ring = np.zeros(self.ring_len)
        self.wpos = 0
        self.sample_count = 0

    def process(self, block: np.ndarray) -> np.ndarray:
        n = len(block)
        mod_vals = self.mod_curve[self.sample_count:self.sample_count + n]
        if len(mod_vals) < n:
            mod_vals = np.pad(mod_vals, (0, n - len(mod_vals)), mode='edge')
        # Always write to ring (keeps data fresh for when mod activates)
        indices = (self.wpos + np.arange(n)) % self.ring_len
        self.ring[indices] = block
        if float(np.max(mod_vals)) < 0.001:
            self.wpos = (self.wpos + n) % self.ring_len
            self.sample_count += n
            return block
        tv = (np.arange(n) + self.sample_count) / SR
        # Center the swing: delay = center + swing, always >= 0
        center = mod_vals * self.peak_delay_samples
        swing = mod_vals * self.peak_delay_samples * np.sin(
            2 * math.pi * self._VIB_RATE * tv)
        delay = center + swing  # ranges [0, 2*mod*peak], never negative
        read_f = self.wpos + np.arange(n, dtype=np.float64) - delay
        ri0 = np.floor(read_f).astype(np.int64) % self.ring_len
        ri1 = (ri0 + 1) % self.ring_len
        frac = read_f - np.floor(read_f)
        out = self.ring[ri0] * (1 - frac) + self.ring[ri1] * frac
        self.wpos = (self.wpos + n) % self.ring_len
        self.sample_count += n
        return out

    def reset(self) -> None:
        self.ring[:] = 0
        self.wpos = 0
        self.sample_count = 0


class DspChain:
    """Ordered list of DspModules processed sequentially."""
    def __init__(self, modules: Optional[List[DspModule]] = None) -> None:
        self.modules: List[DspModule] = modules or []

    def process(self, block: np.ndarray) -> np.ndarray:
        for m in self.modules:
            block = m.process(block)
        return block

    def reset(self) -> None:
        for m in self.modules:
            m.reset()
