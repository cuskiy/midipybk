# mix/

Rendering pipeline and master processing.

- `pipeline.py` — Top-level render: track dispatch, parallel workers, master chain, FLAC output
- `track_render.py` — Per-track rendering: DSP chain, note synthesis, sympathetic resonance
- `dsp_module.py` — Stateful DSP modules: filter, brightness, chorus, Leslie, mod vibrato
- `cc.py` — CC interpolation (zero-order hold), smoothing, pitch bend curves
- `routing.py` — Track splitting, merging, deduplication
- `spatial.py` — Frequency-dependent HRTF, pinna notch, early reflections
- `master.py` — FDN reverb IR, stereo compressor, master EQ stages
