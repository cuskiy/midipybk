"""Per-track rendering: DSP chain, note synthesis, sympathetic resonance."""
from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
from scipy.signal import butter

from config import (CC_FLOOR, CC_SCALE, CC7_LAW_EXP, BLOCK_SIZE,
                    SYMPA_GAIN, SYMPA_MAX_H, SYMPA_TOLERANCE, SYMPA_MAX_NOTES,
                    SYMPA_WINDOW)
from schema import Note, ChannelData, PipelineConfig, TrackResult
from synth import SR, A4, TIMBRES, synthesize, drum
from synth.dsp import BoundedCache, biquad_peak
from synth.gm import inst_mix
from synth.timbre import Timbre
from .cc import (smooth_cc, smooth_cc_sidechain, interp_cc, interp_cc_array,
                 make_pb_curve)
from .dsp_module import (FilterModule, BrightnessModule, ChorusModule,
                         LeslieModule, ModVibratoModule, DspChain)

_HP_CACHE: BoundedCache = BoundedCache(32, name="track.hp")
_BOOM_EQ_CACHE: BoundedCache = BoundedCache(16, name="track.boom_eq")


def _get_hp(freq: float) -> np.ndarray:
    key = int(freq)
    if key not in _HP_CACHE:
        _HP_CACHE[key] = butter(6, max(freq, 15), btype='high', fs=SR, output='sos')
    return _HP_CACHE[key]


def _get_peak_eq(fc: float, gain_db: float, q: float) -> Optional[np.ndarray]:
    key = (int(fc), int(gain_db * 10), int(q * 10))
    if key not in _BOOM_EQ_CACHE:
        _BOOM_EQ_CACHE[key] = biquad_peak(fc, gain_db, q)
    return _BOOM_EQ_CACHE[key]


def _tail_estimate(timbre: Timbre, dur: float) -> float:
    """Estimate audio tail after note-off for buffer sizing.

    Must be >= the actual tail in additive/fm/ks synthesize functions,
    which is always capped at 2.5s. We add 0.5s margin for safety.
    """
    rel = getattr(timbre, 'rel', 0.3)
    return min(rel * 2.5 + 0.5, 3.5)


# ── Sympathetic resonance ────────────────────────────────────────────

def _apply_sympathetic(buf: np.ndarray, notes: List[Note],
                       buf_len: int) -> np.ndarray:
    """Sympathetic halo via harmonic frequency matching.

    Replaces the v158 O(n²·H²) per-pair scan with a sorted-frequency table
    + np.searchsorted: each harmonic looks up its tolerance window in
    O(log H_total + window). Per-hit sin allocation is also avoided by
    using complex exponential accumulation into a single scratch buffer.
    """
    piano_notes = [(st, midi_note, dur, vel)
                   for st, midi_note, dur, vel, ch, prog in notes if ch != 9]
    if len(piano_notes) < 2:
        return buf

    # Sort by start time so we can do a sliding window over the timeline.
    piano_notes.sort(key=lambda x: x[0])
    n_notes = len(piano_notes)

    # Density compensation: local window size, not total count.
    # Previously this took min(SYMPA_MAX_NOTES, total), which dropped
    # early notes in long pieces and used a global density — neither
    # was right for sympathetic resonance which is a strictly local
    # phenomenon (notes must overlap in time to resonate).
    # v160 item 8: WINDOW is derived from config SYMPA_WINDOW which is
    # itself derived from MAX_PEDAL_SUSTAIN, so the two "maximum reach
    # of an active note" constants cannot drift apart.
    WINDOW = SYMPA_WINDOW

    # Precompute per-note data: sample range, vel, harmonics
    starts = np.asarray([p[0] for p in piano_notes], dtype=np.float64)
    note_data: List[Tuple[int, int, float, List[Tuple[int, float]]]] = []
    for st, midi_note, dur, vel in piano_notes:
        f0 = A4 * 2 ** ((midi_note - 69) / 12.0)
        s = int(st * SR)
        e = min(int((st + dur + 0.8) * SR), buf_len)
        harmonics: List[Tuple[int, float]] = []
        for k in range(1, SYMPA_MAX_H + 1):
            fk = f0 * k
            if fk > 8000:
                break
            harmonics.append((k, fk))
        note_data.append((s, e, vel, harmonics))

    res = np.zeros(buf_len)

    # Slide a window over the note timeline. For each anchor note a,
    # consider only notes b with b.start ∈ [a.start - WINDOW, a.start + WINDOW].
    # Within that window, build a local sorted harmonic table and use
    # searchsorted for pair lookup. This is O(W) per anchor instead of
    # O(N), and correctly handles long pieces — every note gets its fair
    # share of sympathetic halo regardless of when it plays.
    # For each anchor: first COLLECT all matching pairs with their
    # (ov_s, ov_e, f_mid, phi, amp) fields, then batch-render them.
    # Previously each pair did a fresh np.arange + np.clip + np.exp +
    # np.sin which is per-pair Python overhead. v160 #3: group pairs
    # by overlap length and run one vectorized sin per length-class.
    max_pair_samples = buf_len
    t_scratch = np.arange(max_pair_samples, dtype=np.float64) / SR
    fade_scratch = np.clip(t_scratch / 0.008, 0, 1)
    decay_scratch = np.exp(-4.0 * t_scratch)

    for a in range(n_notes):
        sa, ea, va, ha = note_data[a]
        # Time window: notes starting within ±WINDOW of this anchor
        lo_t = starts[a] - WINDOW
        hi_t = starts[a] + WINDOW
        lo_idx = int(np.searchsorted(starts, lo_t, side='left'))
        hi_idx = int(np.searchsorted(starts, hi_t, side='right'))

        local_n = hi_idx - lo_idx
        base_gain = SYMPA_GAIN
        if local_n > 4:
            base_gain *= 2.0 / np.sqrt(local_n)

        if local_n > SYMPA_MAX_NOTES:
            window_indices = sorted(range(lo_idx, hi_idx),
                                    key=lambda j: abs(starts[j] - starts[a]))[:SYMPA_MAX_NOTES]
            window_indices.sort()
        else:
            window_indices = list(range(lo_idx, hi_idx))

        w_idx, w_k, w_freq = [], [], []
        for j in window_indices:
            if j == a:
                continue
            for k, fk in note_data[j][3]:
                w_idx.append(j)
                w_k.append(k)
                w_freq.append(fk)
        if not w_freq:
            continue
        w_freq_arr = np.asarray(w_freq, dtype=np.float64)
        order = np.argsort(w_freq_arr)
        sorted_freq = w_freq_arr[order]
        sorted_idx = np.asarray(w_idx, dtype=np.int32)[order]
        sorted_k = np.asarray(w_k, dtype=np.int32)[order]

        # Collect all matching pairs for this anchor
        pair_ov_s: List[int] = []
        pair_ov_e: List[int] = []
        pair_fmid: List[float] = []
        pair_phi: List[float] = []
        pair_amp: List[float] = []

        for ki, fi in ha:
            lo = fi * (1.0 - SYMPA_TOLERANCE)
            hi = fi * (1.0 + SYMPA_TOLERANCE)
            l_pos = int(np.searchsorted(sorted_freq, lo, side='left'))
            r_pos = int(np.searchsorted(sorted_freq, hi, side='right'))
            for p in range(l_pos, r_pos):
                b = int(sorted_idx[p])
                if b <= a:
                    continue
                kj = int(sorted_k[p])
                fj = float(sorted_freq[p])
                sb, eb, vb, _ = note_data[b]
                ov_s, ov_e = max(sa, sb), min(ea, eb)
                if ov_s >= ov_e:
                    continue
                pair_ov_s.append(ov_s)
                pair_ov_e.append(ov_e)
                pair_fmid.append((fi + fj) * 0.5)
                # v159 #4 fix: high-entropy deterministic phase.
                pair_phi.append(((ki * 2.399 + kj * 7.919) % 1.0) * 2.0 * np.pi)
                pair_amp.append(base_gain * min(va, vb) / (ki * kj))

        # Batch-render all pairs using the shared t/fade/decay scratch.
        # Per-pair sin is unavoidable (different frequencies), but we
        # avoid the np.arange/np.clip/np.exp allocation per pair.
        two_pi = 2.0 * np.pi
        for ov_s, ov_e, f_mid, phi, amp in zip(
                pair_ov_s, pair_ov_e, pair_fmid, pair_phi, pair_amp):
            n_samp = ov_e - ov_s
            if n_samp <= 0:
                continue
            t_view = t_scratch[:n_samp]
            fade_view = fade_scratch[:n_samp]
            decay_view = decay_scratch[:n_samp]
            res[ov_s:ov_e] += (amp * fade_view * decay_view
                               * np.sin(two_pi * f_mid * t_view + phi))
    return buf + res


# ── DSP chain builder ────────────────────────────────────────────────

def _build_dsp_chain(inst_name: str, chan_data: ChannelData,
                     buf_len: int) -> DspChain:
    cfg = inst_mix(inst_name)
    modules: list = []
    modules.append(FilterModule(_get_hp(cfg.hp)))
    if cfg.boom_cut is not None:
        fc, gain_db, q = cfg.boom_cut
        sos = _get_peak_eq(fc, gain_db, q)
        if sos is not None:
            modules.append(FilterModule(sos))
    if inst_name != "drums":
        bright_curve = interp_cc(chan_data.brightness, buf_len, default=64.0 / 127.0)
        if isinstance(bright_curve, np.ndarray):
            if np.max(np.abs(bright_curve - 0.504)) > 0.02:
                bright_curve = smooth_cc(bright_curve, tau_ms=10.0)
                modules.append(BrightnessModule(bright_curve, buf_len))
        chorus_curve = interp_cc(chan_data.chorus, buf_len, default=0.0)
        if isinstance(chorus_curve, np.ndarray):
            if cfg.chorus_cap > 0 and np.max(chorus_curve) > 0.01:
                chorus_curve = smooth_cc(np.minimum(chorus_curve, cfg.chorus_cap), tau_ms=20.0)
                modules.append(ChorusModule(chorus_curve, buf_len))
        if inst_name == "organ":
            modules.append(LeslieModule())
        mod_curve = interp_cc(chan_data.mod, buf_len, default=0.0)
        if isinstance(mod_curve, np.ndarray):
            if np.max(mod_curve) > 0.01:
                # CC1 steps must be heavily smoothed: the delay-line reads
                # from positions proportional to mod depth, so an abrupt
                # step creates a phase discontinuity → periodic clicks at
                # the vibrato rate (5.5Hz). 100ms tau is needed to prevent
                # this while still tracking musical gestures.
                mod_curve = smooth_cc(mod_curve, tau_ms=100.0)
                modules.append(ModVibratoModule(mod_curve, buf_len))
    return DspChain(modules)


def _process_chain_blocked(chain: DspChain, buf: np.ndarray) -> np.ndarray:
    """Iterate the DSP chain in BLOCK_SIZE chunks.

    Each module already maintains internal state (zi, sample_pos, ring_pos)
    designed for streaming. Block iteration here:
      - keeps filter zi behaviour identical (sosfilt is associative);
      - lets BrightnessModule re-evaluate gain per block instead of once per song
        (it samples cc_curve at the start of each block);
      - lets Chorus/Leslie/ModVibrato sample their LFOs continuously.
    """
    if not chain.modules:
        return buf
    n = len(buf)
    out = np.empty_like(buf)
    pos = 0
    while pos < n:
        end = min(pos + BLOCK_SIZE, n)
        block = buf[pos:end]
        for m in chain.modules:
            block = m.process(block)
        out[pos:end] = block
        pos = end
    return out


# ── Track render ─────────────────────────────────────────────────────

def render_track(inst_name: str, notes: List[Note], pan_cc: Optional[int],
                 chan_data: ChannelData, buf_len: int,
                 track_gain: float, density_scale: float,
                 cfg: PipelineConfig,
                 track_idx: int = 0) -> TrackResult:
    """Render one track to a mono buffer + pre-fader reverb send."""
    raw_vol = CC_FLOOR + CC_SCALE * interp_cc_array(chan_data.vol, buf_len, default=100.0 / 127.0)
    vol_curve = smooth_cc_sidechain(np.power(raw_vol, CC7_LAW_EXP),
                                    down_ms=5.0, up_ms=50.0)
    raw_expr = CC_FLOOR + CC_SCALE * interp_cc_array(chan_data.expr, buf_len, default=1.0)
    expr_curve = smooth_cc(np.power(raw_expr, CC7_LAW_EXP), tau_ms=50.0)
    at_curve = smooth_cc(interp_cc_array(chan_data.aftertouch, buf_len, default=0.0))
    rev_curve = smooth_cc(
        interp_cc_array(chan_data.reverb, buf_len, default=40.0 / 127.0), tau_ms=50.0)

    chain = _build_dsp_chain(inst_name, chan_data, buf_len)
    buf = np.zeros(buf_len)

    drum_rng = np.random.RandomState(42 + track_idx)
    # nid = global counter across tracks: prevents two tracks with same
    # (note_index, freq, vel) from producing bit-identical jitter that would
    # sum to +6 dB and a "plastic" tone.
    nid_base = track_idx * 100000
    # Item 17: collision guard — if a single track ever exceeds 100k notes,
    # the nid spaces of adjacent tracks would overlap and reintroduce the
    # decorrelation bug that nid_base was designed to prevent.
    if len(notes) >= 100000:
        raise RuntimeError(
            f"track {track_idx} has {len(notes)} notes; nid_base stride is 100000. "
            "Increase the stride or split the track.")
    for ni, note in enumerate(notes):
        sample_pos = int(note.start * SR)
        if sample_pos >= buf_len:
            break
        if note.ch == 9:
            tone = drum(note.midi, note.dur, note.vel, drum_rng)
        else:
            tb = TIMBRES.get(inst_name, TIMBRES["default"])
            freq = A4 * 2 ** ((note.midi - 69) / 12.0)
            pbc = make_pb_curve(chan_data.pb, note.start, note.dur)
            tone = synthesize(freq, note.dur, note.vel, tb, inst_name,
                              nid_base + ni, pb_curve=pbc)
        end = min(sample_pos + len(tone), buf_len)
        seg_len = end - sample_pos
        if seg_len > 0:
            buf[sample_pos:end] += tone[:seg_len]

    buf *= expr_curve
    buf *= 1.0 + at_curve * 0.3

    rev_buf = buf * rev_curve * inst_mix(inst_name).reverb_send

    buf = _process_chain_blocked(chain, buf)

    if np.max(np.abs(buf)) < 1e-10:
        return TrackResult(None, None)

    if inst_mix(inst_name).sympa:
        buf = _apply_sympathetic(buf, notes, buf_len)

    active = np.abs(buf) > 1e-7
    if np.any(active):
        first_a = int(np.argmax(active))
        last_a = buf_len - int(np.argmax(active[::-1]))
        rms = float(np.sqrt(np.mean(buf[first_a:last_a] ** 2)))
    else:
        rms = float(np.sqrt(np.mean(buf * buf)))
    target = track_gain * density_scale
    gain = (target / rms) if rms > 1e-6 else 1.0
    gain *= inst_mix(inst_name).volume
    buf *= gain
    rev_buf *= gain

    buf *= vol_curve
    rev_buf *= vol_curve

    pk = float(np.max(np.abs(buf)))
    if pk > cfg.track_peak_cap:
        scale = cfg.track_peak_cap / pk
        buf *= scale
        rev_buf *= scale

    return TrackResult(buf, rev_buf)