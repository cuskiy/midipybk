"""Shared DSP utilities: filters, waveform helpers, bounded cache."""
import math
from collections import OrderedDict
from typing import Any, ClassVar
import weakref
import numpy as np
from scipy.signal import butter as _butter

SR = 44100
A4 = 440.0


class BoundedCache:
    """Fixed-size LRU cache with global clear and hit/miss stats.

    v159 #21: access-order maintained via OrderedDict.move_to_end. On
    each cache hit we promote the key to the MRU end; eviction removes
    the LRU head. Previously v158 used pure FIFO which evicted
    frequently-accessed items before stale ones.

    v160 #24 limitation: hit/miss counters are per-process. When
    rendering in parallel via ProcessPoolExecutor, each worker has its
    own independent cache with its own stats, and the main process
    only sees the stats from serial work it did itself. The
    end-of-render "cache stats" printout therefore *underestimates*
    true cache activity during parallel renders — it's only showing
    what the main process hit. A future aggregation path would pass
    stats back through the worker return values; for now treat the
    printed numbers as a lower bound on true hit counts.
    """
    _registry: ClassVar = weakref.WeakSet()

    def __init__(self, maxsize: int = 64, name: str = "") -> None:
        self._data: "OrderedDict[Any, Any]" = OrderedDict()
        self._maxsize = maxsize
        self._name = name
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        BoundedCache._registry.add(self)

    def __contains__(self, key: Any) -> bool:
        hit = key in self._data
        if hit:
            self._hits += 1
        else:
            self._misses += 1
        return hit

    def __getitem__(self, key: Any) -> Any:
        value = self._data[key]
        self._data.move_to_end(key)   # promote to MRU
        return value

    def __setitem__(self, key: Any, value: Any) -> None:
        if key in self._data:
            self._data[key] = value
            self._data.move_to_end(key)
            return
        if len(self._data) >= self._maxsize:
            self._data.popitem(last=False)   # evict LRU head
            self._evictions += 1
        self._data[key] = value

    def __len__(self) -> int:
        return len(self._data)

    def get(self, key: Any, default: Any = None) -> Any:
        if key in self._data:
            self._hits += 1
            self._data.move_to_end(key)
            return self._data[key]
        self._misses += 1
        return default

    def clear(self) -> None:
        self._data.clear()

    def stats(self) -> tuple:
        return (self._name or "?", self._hits, self._misses,
                self._evictions, len(self._data), self._maxsize)

    @classmethod
    def clear_all(cls) -> None:
        for c in cls._registry:
            c.clear()

    @classmethod
    def all_stats(cls) -> list:
        out = []
        for c in cls._registry:
            if c._hits or c._misses:
                out.append(c.stats())
        return sorted(out)


_BP_CACHE = BoundedCache(64, name="dsp.bp")


def csv_parse(s: str) -> list:
    return [float(x) for x in s.split(",")] if s else []


def get_bp(lo: float, hi: float):
    key = (int(lo / 10) * 10, int(hi / 50) * 50)
    if key not in _BP_CACHE:
        lo_c, hi_c = max(key[0], 20), min(key[1], int(SR * 0.45))
        _BP_CACHE[key] = _butter(2, [lo_c, hi_c], btype='band', fs=SR, output='sos') if hi_c > lo_c + 50 else None
    return _BP_CACHE[key]


def biquad_peak(fc: float, gain_db: float, q: float):
    fc = max(fc, 30.0)
    if fc >= SR * 0.45:
        return None
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * fc / SR
    alpha = math.sin(w0) / (2 * max(q, 0.3))
    cw = math.cos(w0)
    b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A
    a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A
    return np.array([[b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]])


def biquad_low_shelf(fc: float, gain_db: float, q: float = 0.707):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * fc / SR
    cw, sw = math.cos(w0), math.sin(w0)
    alpha = sw / (2 * q)
    sqA = math.sqrt(A)
    b0 = A * ((A+1) - (A-1)*cw + 2*sqA*alpha)
    b1 = 2*A * ((A-1) - (A+1)*cw)
    b2 = A * ((A+1) - (A-1)*cw - 2*sqA*alpha)
    a0 = (A+1) + (A-1)*cw + 2*sqA*alpha
    a1 = -2 * ((A-1) + (A+1)*cw)
    a2 = (A+1) + (A-1)*cw - 2*sqA*alpha
    return np.array([[b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]])


def biquad_high_shelf(fc: float, gain_db: float, q: float = 0.707):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * fc / SR
    cw, sw = math.cos(w0), math.sin(w0)
    alpha = sw / (2 * q)
    sqA = math.sqrt(A)
    b0 = A * ((A+1) + (A-1)*cw + 2*sqA*alpha)
    b1 = -2*A * ((A-1) + (A+1)*cw)
    b2 = A * ((A+1) + (A-1)*cw - 2*sqA*alpha)
    a0 = (A+1) - (A-1)*cw + 2*sqA*alpha
    a1 = 2 * ((A-1) - (A+1)*cw)
    a2 = (A+1) - (A-1)*cw - 2*sqA*alpha
    return np.array([[b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]])

