"""Instrument timbre presets.

Design philosophy: warm-but-detailed-and-clean, like sunset light
gently fading across the landscape. No harsh brightness transients
(spec_b kept low), minimal saturation (drive kept low). Warmth
comes from natural harmonic structure and body resonance, not from
added distortion. Detail comes from clean transients and good
separation between instruments.

Key principles:
- rolloff ≈ 1.0 matches natural harmonic series of most instruments
- bright ≈ 0.15-0.35 gives appropriate per-partial damping
- micro/noise/coupling are essential, not decorative
- spec_b kept low — no HF brightness bursts at note onset
- drive omitted from additive/KS instruments (below 0.05 threshold)
- pad uses formant_decay — body resonance fades over time (abstract
  texture, not a real instrument, so tonal evolution is artistic)
- Post-processing EQ should be nearly flat
"""
from .timbre import Timbre

TIMBRES = {
    # ── Piano ────────────────────────────────────────────────────────
    # Real piano: ~1/k harmonic rolloff, velocity-dependent brightness,
    # hammer felt noise, 3 strings (2 in tenor, 1 in bass via
    # strings_for_freq), string-soundboard coupling. body_lf=80 models
    # the soundboard's radiation efficiency: below 80Hz, the board
    # can't radiate efficiently, so the fundamental of low bass notes
    # is naturally attenuated and the 2nd-4th harmonics carry the
    # perceived pitch. Formants at 280/550/2800 Hz model the three
    # main soundboard resonances (bass bar, top plate, bridge).
    "piano": Timbre(
        n=14, rolloff=1.0, bright=0.28, bright_lo=0.35, bright_hi=0.15, hammer_hard=2.0,
        strike_pos=0.12, strike_depth=0.35, inh=0.00015, inh_stretch=3.0,
        b1=0.18, b2=0.03, b3=0.03, rel_damp=3.5, coupling=0.6, phantom=0.05,
        att=0.003, d1=0.28, d1l=0.42, d2=0.9, d2s=3.5, pr=0.55, rel=0.35,
        va=0.6, vd=0.3, ps=0.25, pdm=1.8, n_strings=3,
        noise=0.010, noise_d=55.0, noise_peak=10.0, noise_hi=2.5, vn=0.8, live=0.010,
        spec_b=0.40, spec_tau=0.080, n_extra=4,
        fc_base=5000.0, fc_min=0.35, hammer_p=2.5, fc_alpha=1.5, decay_exp=0.65,
        formant_freqs="180,2800",
        formant_gains="0.10,0.06",
        formant_qs="1.0,2.5",
        micro=0.75, body_lf=80.0,
    ),

    # ── Electric Piano ───────────────────────────────────────────────
    # FM tine piano: bell-like onset with warm sustain. Tremolo essential.
    # Gentle drive for warm body without harshness.
    "epiano": Timbre(
        harm_amps="0.75,1.0,0.60,0.35,0.18,0.10,0.05,0.03",
        n=8, inh=0.00025, inh_stretch=2.8,
        b1=0.40, b3=0.06, rel_damp=3.0,
        att=0.002, d1=0.10, d1l=0.18, d2=2.8, d2s=5.5, pr=0.50, rel=0.30,
        va=0.55, vd=0.2, ps=0.05, pdm=1.2, n_strings=1,
        trem_r=4.8, trem_d=0.10,
        noise=0.004, noise_d=140.0, noise_peak=14.0, noise_hi=1.5, vn=0.2,
        spec_b=0.15, spec_tau=0.060, drive=0.10,
        fc_base=5000.0, fc_min=0.25, hammer_p=2.0, fc_alpha=1.5, decay_exp=0.7,
        formant_freqs="200", formant_gains="0.20", formant_qs="1.2",
        micro=0.80,
    ),

    # ── Harpsichord ──────────────────────────────────────────────────
    # Deliberately bright — plucked mechanism creates sharp attack.
    # High b1/b3 for fast decay. KS engine handles short notes.
    "harpsichord": Timbre(
        n=12, rolloff=0.7, bright=0.15, vel_bright=0.12,
        strike_pos=0.15, strike_depth=0.30, inh=0.00004,
        b1=0.85, b3=0.14, rel_damp=5.5, coupling=0.8, phantom=0.03,
        att=0.001, d1=0.06, d1l=0.10, d2=1.5, rel=0.10,
        va=0.15, vn=0.6, ps=0.06, pdm=1.3, n_strings=2,
        noise=0.020, noise_d=160.0, noise_peak=15.0, noise_hi=1.2,
        spec_b=0.20, spec_tau=0.006, 
        fc_base=5500.0, fc_min=0.40, fc_alpha=2.0, decay_exp=0.6,
        formant_freqs="500,2200", formant_gains="0.18,0.10", formant_qs="1.5,1.2",
        micro=0.7, ks_lp=0.82, ks_click=0.22,
    ),

    # ── Organ ────────────────────────────────────────────────────────
    # Tonewheel organ: drawbar registration for warm full tone.
    # harm_amps represent 8' 4' 2-2/3' 2' 1-3/5' 1-1/3' 1' stops.
    # Sub-oscillators for 16' and 5-1/3' stops.
    "organ": Timbre(
        harm_amps="1.0,0.45,0.30,0.25,0.12,0.08,0.04,0.02",
        n=8, sub=0.80, sub_third=0.80,
        att=0.001, d1=0.005, d1l=0.99, d2=80.0, rel=0.012,
        va=0.0, vd=0.0,
        vib_r=6.7, vib_d=4, vib_del=0.05,
        key_click=0.10, micro=0.0,
        tw_leak=0.08, drive=0.06,
    ),

    # ── Guitar ───────────────────────────────────────────────────────
    # Steel string: KS engine for realistic pluck, additive for long notes.
    # rolloff=1.0, bright=0.35 for natural steel string character.
    # Higher b1=0.42 since guitar partials die faster than piano.
    "guitar": Timbre(
        n=10, rolloff=1.0, bright=0.35, bright_lo=0.38, bright_hi=0.20, hammer_hard=1.8,
        strike_pos=0.14, strike_depth=0.30, inh=0.00003,
        b1=0.42, b2=0.04, b3=0.06, phantom=0.03,
        att=0.001, d1=0.12, d1l=0.18, d2=2.5, d2s=5.0, pr=0.68, rel=0.20,
        va=0.5, vd=0.3, ps=0.10, pdm=1.5, det_c=0.6, det_m=0.03,
        noise=0.008, noise_d=100.0, noise_peak=8.0, noise_hi=1.0, vn=0.7,
        rel_damp=4.0, live=0.005, spec_b=0.12, spec_tau=0.020,
        fc_base=4500.0, fc_min=0.30, fc_alpha=1.6, decay_exp=0.6,
        formant_freqs="480,2800", formant_gains="0.35,0.18", formant_qs="2.0,1.5",
        micro=0.6, ks_lp=0.65, ks_click=0.08, body_lf=55.0,
    ),

    # ── Nylon Guitar ─────────────────────────────────────────────────
    # Softer than steel but not dead: ks_lp=0.50 (was 0.35) lets the
    # KS delay line keep natural harmonics through 2-4 kHz, matching
    # real nylon samples. Formants at 220/2200 (body/bridge) instead
    # of 350/1600 — the old 350 Hz sat right on typical fundamentals
    # (midi 60-67 = 262-392 Hz) and post-formant RMS normalization
    # then crushed the harmonics. ks_always in gm.py keeps KS at all
    # durations — nylon is a plucked instrument, not bowed.
    "nylon": Timbre(
        n=10, rolloff=1.1, bright=0.25, bright_lo=0.30, bright_hi=0.18, hammer_hard=1.0,
        strike_pos=0.20, strike_depth=0.15, b1=0.40, b3=0.05,
        att=0.004, d1=0.20, d1l=0.14, d2=1.6, d2s=3.0, pr=0.75, rel=0.25,
        va=0.30, vn=0.3, ps=0.05, pdm=1.2,
        noise=0.002, noise_d=40.0, noise_peak=4.0, noise_hi=0.2,
        rel_damp=2.5, spec_b=0.20, spec_tau=0.028,
        fc_base=2500.0, fc_min=0.50, fc_alpha=2.0, decay_exp=0.35,
        formant_freqs="220,2200", formant_gains="0.25,0.12", formant_qs="1.5,1.8",
        micro=0.5, ks_lp=0.50, ks_click=0.10,
    ),

    # ── Bass ─────────────────────────────────────────────────────────
    # Electric bass: few partials, sub emphasis, tight decay.
    # Fingered bass: warm fundamental. 120Hz formant removed — it sat
    # right on bass fundamentals (midi 28-48 = 41-131Hz) causing buzz.
    # drive reduced for cleaner tone.
    "bass": Timbre(
        n=6, rolloff=1.8, bright=0.55, strike_pos=0.50, strike_depth=0.35,
        b1=0.45, b3=0.08, sub=0.22,
        att=0.004, d1=0.05, d1l=0.48, d2=0.9, rel=0.08,
        va=0.30, vn=0.2, ps=0.12, pdm=1.2,
        noise=0.004, noise_d=50.0, noise_peak=3.5,
        fc_base=1800.0, fc_min=0.50, fc_alpha=2.5,
        micro=0.4,
    ),

    # ── Synth Bass ───────────────────────────────────────────────────
    # Paired with the legato gap-fill in midi.py. The merged sustains
    # are several seconds long, so d2 must be huge or the sustain
    # decays and bumps back at every chord change. Same fix as
    # contrabass: d1l=0.96, d2=25.0 (flat sustain), att/rel matched
    # so consecutive chords crossfade smoothly.
    # v175: b1/b3 lowered — v174 values (0.18/0.02) were tuned for
    # short pre-merge notes; after legato merge, harmonics decayed to
    # sine wave within 1s. fc_base raised from 1100 to 2200 because
    # faded.mid plays synbass at midi 78-87 (740-1245 Hz) where the
    # old filter left only the fundamental.
    "synbass": Timbre(
        n=8, rolloff=0.95, bright=0.05,
        b1=0.03, b2=0.01, b3=0.004,
        att=0.050, d1=0.05, d1l=0.96, d2=25.0, rel=0.050, rel_cos=1,
        va=0.20, vn=0.15, ps=0.10, pdm=1.2,
        noise=0.003, noise_d=50.0, noise_peak=3.0,
        fc_base=2200.0, fc_min=0.55, fc_alpha=1.8,
        live=0.003, spec_b=0.0, spec_tau=0.0, micro=0.12,
    ),

    # ── Harp ─────────────────────────────────────────────────────────
    # Plucked strings with resonant body. Sympathetic resonance is
    # physically real for harp (open strings resonate).
    "harp": Timbre(
        n=10, rolloff=0.75, bright=0.20, vel_bright=0.15,
        strike_pos=0.42, strike_depth=0.35, inh=0.00003,
        b1=0.35, b2=0.03, b3=0.05, phantom=0.08, coupling=0.6,
        att=0.002, d1=0.08, d1l=0.28, d2=4.5, d2s=9.0, pr=0.50, rel=0.55,
        va=0.40, vn=0.3, ps=0.08, pdm=1.5, det_c=0.4, det_m=0.015,
        noise=0.002, noise_d=50.0, noise_peak=5.0, noise_hi=0.3,
        rel_damp=2.0, spec_b=0.45, spec_tau=0.025,
        fc_base=5500.0, fc_min=0.40, fc_alpha=1.8, decay_exp=0.45,
        formant_freqs="350,1200", formant_gains="0.25,0.20", formant_qs="1.5,1.2",
        micro=0.5, ks_lp=0.42, ks_click=0.03,
    ),

    # ── Pluck Synth ──────────────────────────────────────────────────
    "pluck": Timbre(
        n=10, rolloff=0.85, bright=0.20, vel_bright=0.20,
        strike_pos=0.20, strike_depth=0.30, b1=0.85, b3=0.14,
        att=0.001, d1=0.12, d1l=0.08, d2=2.0, d2s=4.5, pr=0.65, rel=0.22,
        va=0.45, vn=0.5, ps=0.06, pdm=1.3, det_c=1.5, det_m=0.05,
        noise=0.008, noise_d=120.0, noise_peak=9.0, noise_hi=0.8,
        rel_damp=3.5, spec_b=0.12, spec_tau=0.015, 
        fc_base=4500.0, fc_min=0.25, fc_alpha=1.8, decay_exp=0.5,
        formant_freqs="2200,4500", formant_gains="0.30,0.15", formant_qs="3.0,2.5",
        micro=0.5,
    ),

    # ── Strings ──────────────────────────────────────────────────────
    # Ensemble strings: warm body, bow friction noise for realism.
    # rolloff=1.0 matches bowed string harmonic series.
    # Formants at body resonance (450Hz) and bridge (2800Hz).
    # micro=0.0 because ensemble averaging smooths individual variation.
    "strings": Timbre(
        n=8, rolloff=1.0, bright=0.18, b1=0.03, b3=0.002,
        att=0.08, d1=0.10, d1l=0.75, d2=2.5, rel=0.25,
        va=0.3, vib_r=5.5, vib_d=5, vib_del=0.30,
        noise=0.002, noise_d=2.0,
        formant_freqs="450,2800", formant_gains="0.30,0.18", formant_qs="2.0,1.5",
        bow_noise=0.020, spec_b=0.08, spec_tau=0.040, micro=0.0,
    ),

    # ── Cello ────────────────────────────────────────────────────────
    # Solo cello: richer harmonics than ensemble, strong body formant.
    "cello": Timbre(
        n=12, rolloff=0.80, bright=0.06, b1=0.018, b3=0.001,
        att=0.12, d1=0.14, d1l=0.70, d2=2.5, rel=0.35,
        va=0.20, vib_r=4.2, vib_d=7, vib_del=0.45,
        noise=0.005, noise_d=1.5,
        formant_freqs="700,2200", formant_gains="0.40,0.15", formant_qs="1.8,1.5",
        bow_noise=0.030, spec_b=0.08, spec_tau=0.060, micro=0.0,
    ),

    # ── Contrabass ───────────────────────────────────────────────────
    # Sub-bass bowed string (midi 23-48 ≈ 31-130 Hz). Two orthogonal
    # things had to happen here:
    #   1. Avoid the phase-coherent partial pulse train (motorcycle
    #      engine effect at sub-bass): random phase init in additive.py
    #      + mild inharmonicity (partials drift out of harmonic lock)
    #      + 3-string ensemble (beating) + audible vibrato (period
    #      jitter) + strong noise content (continuous fill).
    #   2. Survive the legato gap-fill from midi.py: merged notes are
    #      seconds long, so d1l=0.96 + d2=25.0 keeps sustain flat
    #      instead of ramping down + bumping back up at chord changes.
    "contrabass": Timbre(
        n=24, rolloff=0.85, bright=0.20, vel_bright=0.15,
        inh=0.0012, inh_stretch=2.0,
        b1=0.020, b3=0.002, n_extra=4, n_strings=3,
        att=0.150, d1=0.20, d1l=0.96, d2=25.0, rel=0.150, rel_cos=1,
        va=0.20, vib_r=4.5, vib_d=8, vib_del=0.30,
        noise=0.030, noise_d=1.5, live=0.012,
        formant_freqs="180,500,1200",
        formant_gains="0.22,0.18,0.10",
        formant_qs="1.0,1.2,1.5",
        bow_noise=0.080, micro=1.5, spec_b=0.08, spec_tau=0.080,
    ),

    # ── Brass ────────────────────────────────────────────────────────
    # Brass: strong upper harmonics (rolloff=0.35), lip reed nonlinearity.
    # vel_bright gives dynamic range from warm pp to bright ff.
    "brass": Timbre(
        n=14, rolloff=0.35, bright=0.04, vel_bright=0.45,
        b1=0.06, b3=0.003,
        att=0.050, d1=0.06, d1l=0.72, d2=2.5, rel=0.14,
        va=0.35, det_c=0.5, det_m=0.015,
        vib_r=5.0, vib_d=5, vib_del=0.35,
        noise=0.008, noise_d=6.0, live=0.008,
        spec_b=0.08, spec_tau=0.05,
        formant_freqs="1300,2500", formant_gains="0.35,0.15", formant_qs="1.8,1.5",
        lip_shape=0.35, breath_noise=0.008, micro=0.0,
    ),

    # ── Woodwind ─────────────────────────────────────────────────────
    # Even-harmonic attenuation (cylindrical bore), breath noise essential.
    "woodwind": Timbre(
        n=14, rolloff=0.55, bright=0.08, vel_bright=0.15, even_atten=0.75,
        b1=0.04, b3=0.002,
        att=0.030, d1=0.04, d1l=0.70, d2=2.5, rel=0.10,
        va=0.35, vn=0.5, vib_r=4.5, vib_d=5, vib_del=0.35,
        noise=0.010, noise_d=2.5, noise_peak=5.0, noise_hi=0.3,
        live=0.008,
        formant_freqs="1500,2800", formant_gains="0.28,0.12", formant_qs="2.2,1.8",
        breath_noise=0.022, spec_b=0.06, spec_tau=0.040, micro=0.0,
    ),

    # ── Flute ────────────────────────────────────────────────────────
    # Very few harmonics (n=4), breath is the character.
    "flute": Timbre(
        n=4, rolloff=1.8, bright=0.06, vel_bright=0.08,
        b1=0.02, b3=0.001,
        att=0.035, d1=0.05, d1l=0.74, d2=3.0, rel=0.20,
        va=0.15, vn=0.7, vib_r=5.0, vib_d=5, vib_del=0.30,
        noise=0.008, noise_d=1.8, noise_peak=4.0, noise_hi=0.3, live=0.006,
        formant_freqs="800", formant_gains="0.20", formant_qs="2.0",
        fc_base=2200.0, fc_min=0.45, fc_alpha=2.0,
        breath_noise=0.040, spec_b=0.08, spec_tau=0.030, micro=0.0,
    ),

    # ── Choir ────────────────────────────────────────────────────────
    # Vowel formants are essential (700, 1100, 2600Hz).
    # Detune for ensemble width. Breath noise for realism.
    "choir": Timbre(
        n=8, rolloff=0.95, bright=0.12, b1=0.018, b3=0.001,
        att=0.16, d1=0.10, d1l=0.80, d2=2.5, rel=0.45,
        va=0.12, det_c=5.0, det_m=0.16, vib_r=5.5, vib_d=5, vib_del=0.50,
        noise=0.006, noise_d=1.5, live=0.010,
        formant_freqs="700,1100,2600", formant_gains="0.55,0.30,0.12", formant_qs="2.5,2.2,2.0",
        breath_noise=0.012, spec_b=0.06, spec_tau=0.080, micro=0.0,
    ),

    # ── Lead ─────────────────────────────────────────────────────────
    # Synth lead: explicit harmonic amps, drive for character.
    # Lead synth: sawtooth-like spectrum. Low drive and spec_b for
    # clean warm tone — faded.mid stacks 5 lead channels.
    "lead": Timbre(
        harm_amps="1.0,0.50,0.33,0.25,0.20,0.17,0.14,0.12,0.11,0.10",
        n=10, att=0.003, d1=0.05, d1l=0.62, d2=1.5, rel=0.10,
        va=0.55, det_c=4.5, det_m=0.14, vib_r=5.5, vib_d=7, vib_del=0.10,
        spec_b=0.08, spec_tau=0.06,
        fc_base=4000.0, fc_min=0.30, fc_alpha=1.8,
        micro=0.15,
    ),

    # ── Pad ──────────────────────────────────────────────────────────
    # "sunset afterglow" — warm, diffuse, with body formants that melt
    # away slowly. rolloff=1.0 (was 1.7) so low-register pads (midi
    # 35-51 in faded.mid) have audible harmonics instead of pure sine.
    # b1/b3 lowered from defaults (0.50/0.08) so harmonics survive the
    # 1.1s attack. Formants at 350/900 Hz (was 700/1800) — the old
    # frequencies were above all 8 partials at midi 39 (78 Hz, highest
    # partial = 622 Hz), making formant_decay decorative. formant_decay
    # = 5.0 (was 3.0) for longer lingering warmth.
    "pad": Timbre(
        n=8, rolloff=1.0, bright=0.05,
        b1=0.02, b3=0.003,
        att=1.10, d1=0.30, d1l=0.88, d2=28.0, rel=2.8,
        va=0.04, vd=0.0, det_c=9.0, det_m=0.25,
        vib_r=2.5, vib_d=3, vib_del=1.5,
        noise=0.001, noise_d=1.0, micro=0.10,
        fc_base=1500.0, fc_min=0.55, fc_alpha=2.2,
        formant_freqs="350,900", formant_gains="0.22,0.12",
        formant_qs="1.5,1.3", formant_decay=5.0,
        breath_noise=0.003,
    ),

    # ── Celesta ──────────────────────────────────────────────────────
    "celesta": Timbre(
        n=8, rolloff=0.45, bright=0.12, bright_lo=0.22, bright_hi=0.06, hammer_hard=2.2,
        strike_pos=0.50, strike_depth=0.12, inh=0.0006, inh_stretch=3.0,
        b1=1.10, b3=0.22,
        att=0.001, d1=0.05, d1l=0.06, d2=2.5, d2s=5.0, pr=0.45, rel=0.40,
        va=0.25, noise=0.004, noise_d=180.0, noise_peak=14.0, noise_hi=2.0,
        rel_damp=3.5, spec_b=0.25, spec_tau=0.006, drive=0.02,
        fc_base=7500.0, fc_min=0.25, fc_alpha=1.6, decay_exp=1.0, micro=0.8,
    ),

    # ── Vibes ────────────────────────────────────────────────────────
    "vibes": Timbre(
        n=8, rolloff=0.45, bright=0.06, bright_lo=0.12, bright_hi=0.04, hammer_hard=1.6,
        inh=0.0003, inh_stretch=2.0, b1=0.40, b3=0.05,
        att=0.002, d1=0.10, d1l=0.25, d2=3.8, d2s=7.5, pr=0.45, rel=0.55,
        va=0.30, trem_r=5.5, trem_d=0.15,
        noise=0.003, noise_d=50.0, noise_peak=6.0, noise_hi=0.5,
        spec_b=0.35, spec_tau=0.020, drive=0.02,
        formant_freqs="1500,3500", formant_gains="0.22,0.10", formant_qs="2.0,1.5",
        micro=0.6,
    ),

    # ── Marimba ──────────────────────────────────────────────────────
    "marimba": Timbre(
        n=5, rolloff=0.35, bright=0.35, bright_lo=0.50, bright_hi=0.22, hammer_hard=2.0,
        b1=2.0, b3=0.35,
        att=0.001, d1=0.03, d1l=0.04, d2=1.4, rel=0.10,
        va=0.5, vn=0.5,
        noise=0.015, noise_d=80.0, noise_peak=6.0, noise_hi=0.6,
        spec_b=0.65, spec_tau=0.005, drive=0.03,
        formant_freqs="800", formant_gains="0.28", formant_qs="1.5",
        micro=0.35,
    ),

    # ── Default ──────────────────────────────────────────────────────
    "default": Timbre(
        n=8, rolloff=1.0, bright=0.35, vel_bright=0.15,
        strike_pos=0.12, strike_depth=0.25, b1=0.50, b3=0.08,
        att=0.005, d1=0.20, d1l=0.30, d2=1.5, rel=0.20,
        va=0.3, vn=0.3, ps=0.08, pdm=1.3, det_c=1.2, det_m=0.05,
        noise=0.004, noise_d=40.0, noise_peak=8.0, noise_hi=0.5, drive=0.05, micro=0.3,
    ),

    # ── SFX ──────────────────────────────────────────────────────────
    "sfx": Timbre(
        n=8, rolloff=0.6,
        att=0.025, d1=0.10, d1l=0.60, d2=3.0, rel=0.45,
        va=0.40, vd=0.1, micro=0.0,
        noise=0.0, drive=0.0, live=0.003,
    ),
}