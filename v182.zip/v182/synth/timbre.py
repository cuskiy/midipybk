"""Timbre parameter class and pitch-register helpers.

Also re-exports a handful of dsp utilities (biquad_*, get_bp) so that
upstream modules can import them from a single namespace.
"""
import math
from typing import ClassVar, Dict, Tuple
from synth.dsp import (SR, A4, csv_parse, get_bp,
                       biquad_peak, biquad_low_shelf, biquad_high_shelf)
# Re-exported for legacy imports — used by mix.master, mix.spatial,
# mix.dsp_module, synth.fm.
__all__ = ["SR", "A4", "Timbre", "csv_parse", "get_bp",
           "biquad_peak", "biquad_low_shelf", "biquad_high_shelf",
           "MAX_DET", "TUNE", "pr", "lf", "vc",
           "strings_for_freq", "detune_scale"]

MAX_DET = 5
TUNE = {1: [1.0], 2: [0.9998, 1.0002], 3: [1.00005, 1.00020, 0.99975]}
_LOG2_C4 = math.log2(261.63)


def strings_for_freq(freq: float, max_strings: int) -> int:
    if max_strings <= 1: return 1
    if freq < 30: return 1
    if freq < 220: return min(2, max_strings)
    return max_strings


def detune_scale(freq: float) -> float:
    if freq >= 300: return 1.0
    if freq <= 80: return 0.08
    return 0.08 + 0.92 * ((freq - 80) / 220)


def pr(f: float) -> float:
    return max(0.0, min((math.log2(f) - _LOG2_C4 + 2) / 4, 1.0))

def lf(f: float) -> float:
    return max(0.0, min(1.0 - (math.log2(f) - _LOG2_C4 + 2) / 4, 1.0))

def vc(v: float) -> float:
    return v ** 0.65


_FIELDS = dict(
    # ── Harmonics ──
    n=10,               # partial count (1-30)
    rolloff=1.0,        # spectral rolloff exponent (0-2)
    bright=0.3,         # HF damping per partial (0-1)
    bright_lo=0.0,      # bright at low vel (hammer_hard mode)
    bright_hi=0.0,      # bright at high vel (hammer_hard mode)
    hammer_hard=0.0,    # vel→brightness curve (0=off, 1-3)
    vel_bright=0.0,     # linear vel→brightness (0-1)
    strike_pos=0.0,     # string strike position (0-0.5)
    strike_depth=0.0,   # strike notch depth (0-1)
    # ── Noise ──
    noise=0.0,          # noise amplitude (0-0.05)
    noise_d=30.0,       # noise decay rate (1-200)
    noise_peak=8.0,     # noise BP upper freq multiplier
    noise_hi=0.0,       # extra noise at high pitch (0-2)
    vn=0.5,             # vel→noise scale (0-1)
    # ── Inharmonicity ──
    inh=0.0,            # inharmonicity B (0-0.001)
    inh_stretch=0.0,    # B stretch with register (0-5)
    b1=0.50,            # per-partial decay linear (0-3)
    b2=0.0,             # per-partial decay k^1.5 mid-range (0-0.3)
    b3=0.08,            # per-partial decay quadratic (0-0.5)
    rel_damp=0.0,       # extra HF damping in release (0-8)
    coupling=0.0,       # string coupling (0-1)
    phantom=0.0,        # combination tone amp (0-0.1)
    n_strings=1,        # strings per note (1-3)
    n_extra=0,          # extra partials at low pitch (0-15)
    # ── Spectral dynamics ──
    spec_b=0.0,         # brightness transient depth (0-1)
    spec_tau=0.015,     # brightness transient decay (s)
    drive=0.0,          # tanh saturation (0-0.3)
    # ── ADSR ──
    att=0.005,          # attack (s, 0.001-0.5)
    d1=0.4,             # decay1 time (s)
    d1l=0.35,           # decay1 end level (0-1)
    d2=2.0,             # sustain decay tau (s)
    d2s=0.0,            # secondary decay tau (s, 0=off)
    pr=1.0,             # primary/secondary ratio (0-1)
    rel=0.3,            # release (s)
    rel_cos=0,          # release shape: 0=exp (default), 1=cosine over `rel` s
                        #   cosine pairs with the attack curve so consecutive
                        #   legato notes (synbass/contrabass after the merge in
                        #   midi.py) crossfade with no envelope dip. Math: a
                        #   raised-cosine release + raised-cosine attack of
                        #   matched length sum to a constant.
    # ── Velocity / pitch ──
    va=0.5,             # vel→attack shortening (0-1)
    vd=0.3,             # vel→sustain lengthening (0-1)
    ps=0.0,             # pitch→sustain boost (0-1)
    pdm=1.0,            # pitch→decay multiplier (0.5-3)
    det_c=0.0,          # sympathetic detune cents (0-8)
    det_m=0.0,          # sympathetic mix amp (0-0.2)
    # ── Vibrato / tremolo ──
    vib_r=5.0,          # vibrato rate (Hz)
    vib_d=0.0,          # vibrato depth (cents, 0=off)
    vib_del=0.3,        # vibrato onset delay (s)
    trem_r=0.0,         # tremolo rate (Hz)
    trem_d=0.0,         # tremolo depth (0-0.3)
    # ── Sub-oscillators ──
    sub=0.0,            # sub-octave amp (0-1)
    sub_third=0.0,      # 3rd harmonic sub amp (0-1)
    live=0.0,           # envelope liveness (0-0.01)
    # ── Filter ──
    fc_base=0.0,        # vel-sensitive LP base Hz (0=off)
    fc_min=0.3,         # fc ratio at vel=0 (0-1)
    hammer_p=2.5,       # vel→fc exponent
    fc_alpha=2.0,       # LP steepness (1-3)
    decay_exp=0.0,      # partial decay pitch scaling (0-1)
    # ── Character ──
    micro=0.5,          # pitch/amp micro-variation (0-1)
    even_atten=0.0,     # even harmonic atten (0-1)
    key_click=0.0,      # key click amp (0-0.2)
    # ── KS engine ──
    ks_lp=0.0,          # delay line LP coeff (0=default)
    ks_click=0.0,       # excitation click (0-0.5)
    # ── Formants (CSV) ──
    formant_freqs="",   # resonance freqs
    formant_gains="",   # resonance gains
    formant_qs="",      # resonance Q factors
    formant_decay=0.0,  # formant fade time (s, 0=permanent)
    # ── Harmonic amps (CSV, overrides rolloff/bright) ──
    harm_amps="",
    # ── Extended ──
    bow_noise=0.0,      # bowed string noise (0-0.02)
    breath_noise=0.0,   # breath noise (0-0.02)
    lip_shape=0.0,      # brass lip nonlinearity (0-0.5)
    tw_leak=0.0,        # organ tonewheel leak (0-0.1)
    body_lf=0.0,        # body radiation -3dB freq (Hz, 0=off)
                        #   Models soundboard/body radiation efficiency:
                        #   partials below this freq are attenuated because
                        #   the resonant body is too small to radiate them.
                        #   Real piano boards roll off below ~80Hz; guitar
                        #   bodies below ~55Hz. Electronic instruments: 0.
)

# ── v160 #4: sub-dataclass authoring form ────────────────────────────
#
# These are typed keyword bundles for readability when writing complex
# Timbre presets. They are flattened into Timbre.__slots__ at construction
# time; the hot-path representation is unchanged. A field set to None on
# a sub-dataclass means "use Timbre default" rather than "override with None".
#
# Groups are additive: you can pass some via sub-dataclasses and some as
# flat kwargs in the same Timbre() call. Flat kwargs always win on conflict.

from dataclasses import dataclass


@dataclass
class Harmonics:
    """Spectral shape: partial count, rolloff, brightness, strike notch."""
    n: "int | None" = None
    rolloff: "float | None" = None
    bright: "float | None" = None
    bright_lo: "float | None" = None
    bright_hi: "float | None" = None
    hammer_hard: "float | None" = None
    vel_bright: "float | None" = None
    strike_pos: "float | None" = None
    strike_depth: "float | None" = None
    even_atten: "float | None" = None
    harm_amps: "str | None" = None


@dataclass
class Envelope:
    """ADSR and release damping."""
    att: "float | None" = None
    d1: "float | None" = None
    d1l: "float | None" = None
    d2: "float | None" = None
    d2s: "float | None" = None
    pr: "float | None" = None
    rel: "float | None" = None
    rel_damp: "float | None" = None
    va: "float | None" = None
    vd: "float | None" = None
    ps: "float | None" = None
    pdm: "float | None" = None


@dataclass
class Articulation:
    """Live character: vibrato, tremolo, noise, micro-variation."""
    noise: "float | None" = None
    noise_d: "float | None" = None
    noise_peak: "float | None" = None
    noise_hi: "float | None" = None
    vn: "float | None" = None
    vib_r: "float | None" = None
    vib_d: "float | None" = None
    vib_del: "float | None" = None
    trem_r: "float | None" = None
    trem_d: "float | None" = None
    micro: "float | None" = None
    live: "float | None" = None
    key_click: "float | None" = None
    bow_noise: "float | None" = None
    breath_noise: "float | None" = None
    lip_shape: "float | None" = None
    tw_leak: "float | None" = None


@dataclass
class EngineSpecific:
    """Engine-specific parameters: inharmonicity, filter, drive, KS."""
    inh: "float | None" = None
    inh_stretch: "float | None" = None
    b1: "float | None" = None
    b2: "float | None" = None
    b3: "float | None" = None
    coupling: "float | None" = None
    phantom: "float | None" = None
    n_strings: "int | None" = None
    n_extra: "int | None" = None
    spec_b: "float | None" = None
    spec_tau: "float | None" = None
    drive: "float | None" = None
    fc_base: "float | None" = None
    fc_min: "float | None" = None
    hammer_p: "float | None" = None
    fc_alpha: "float | None" = None
    decay_exp: "float | None" = None
    sub: "float | None" = None
    sub_third: "float | None" = None
    det_c: "float | None" = None
    det_m: "float | None" = None
    ks_lp: "float | None" = None
    ks_click: "float | None" = None
    body_lf: "float | None" = None


@dataclass
class Formants:
    """Resonance formant filter bank (CSV strings)."""
    formant_freqs: "str | None" = None
    formant_gains: "str | None" = None
    formant_qs: "str | None" = None
    formant_decay: "float | None" = None


# Recognized sub-dataclass kwarg names
_GROUP_NAMES = {"harmonics", "envelope", "articulation",
                "engine_specific", "formants"}


class Timbre:
    """Synthesis parameter container.

    v160 big item #4: the 67 fields are logically organized into groups
    (Harmonics, Envelope, Articulation, EngineSpecific, Formants), but
    the runtime representation is kept flat in ``__slots__`` for
    hot-path performance. Hot loops in synth/additive.py read
    ``tim.bright`` and ``tim.att`` millions of times per render — any
    indirection through ``tim.envelope.att`` would be a catastrophic
    regression.

    Authors can use either form interchangeably:

        # Flat (v159 style) — still works, fastest to type
        Timbre(n=10, bright=0.3, att=0.005, rel=0.3, ...)

        # Grouped (v160 style) — clearer for complex presets
        Timbre(
            harmonics=Harmonics(n=10, bright=0.3),
            envelope=Envelope(att=0.005, rel=0.3),
            ...
        )

    Both are flattened into ``__slots__`` in ``__init__``, so the
    runtime cost is identical.
    """
    __slots__ = tuple(_FIELDS.keys()) + ('_ref_amp', '_ha_cache')

    def __init__(self, **kw):
        # Step 1: explode any sub-dataclass groups passed as kwargs.
        # The sub-dataclasses are typed keyword bundles; we extract
        # their __dict__ and merge into flat kwargs, preferring
        # explicit flat kwargs when they conflict.
        flat_kw = {}
        for group_name in _GROUP_NAMES:
            if group_name in kw:
                grp = kw.pop(group_name)
                if grp is not None:
                    flat_kw.update({k: v for k, v in grp.__dict__.items()
                                    if v is not None})
        # Explicit flat kwargs win over group defaults
        flat_kw.update(kw)

        unknown = set(flat_kw) - set(_FIELDS)
        if unknown:
            raise TypeError(f"Unknown Timbre fields: {unknown}")
        for k, v in _FIELDS.items():
            setattr(self, k, flat_kw.get(k, v))
        self._ref_amp = None
        self._ha_cache = None
        self._validate()

    # Item 5 (v160): range checks for fields that have a clear physical
    # or perceptual range. Missing checks made it possible to write
    # bright=3.0 (should be 0–1) and have it silently produce non-
    # physical partial attenuation. Ranges derived from the v160
    # instruments.py presets and expanded by 50% margin for future
    # tuning headroom.
    _RANGES: "ClassVar[Dict[str, Tuple[float, float]]]" = {
        # harmonics / body
        "rolloff":       (0.0, 3.0),
        "bright":        (0.0, 1.5),
        "bright_lo":     (0.0, 1.5),
        "bright_hi":     (0.0, 1.5),
        "vel_bright":    (0.0, 1.5),
        "hammer_hard":   (0.0, 5.0),
        "strike_pos":    (0.0, 0.6),
        "strike_depth":  (0.0, 1.0),
        "even_atten":    (0.0, 1.5),
        # inharmonicity / coupling
        "inh":           (0.0, 0.01),
        "inh_stretch":   (0.0, 5.0),
        "b1":            (0.0, 3.0),
        "b2":            (0.0, 1.0),
        "b3":            (0.0, 1.0),
        "rel_damp":      (0.0, 10.0),
        "coupling":      (0.0, 1.5),
        "phantom":       (0.0, 0.2),
        # envelope
        "d1":            (0.0, 2.0),
        "d1l":           (0.0, 1.0),
        "d2":            (0.0, 200.0),
        "d2s":           (0.0, 50.0),
        "pr":            (0.0, 1.0),
        # velocity / pitch modulation
        "va":            (0.0, 1.5),
        "vd":            (0.0, 1.0),
        "ps":            (0.0, 1.0),
        "pdm":           (0.0, 3.0),
        # noise
        "noise":         (0.0, 0.1),
        "vn":            (0.0, 1.5),
        "noise_peak":    (0.0, 30.0),
        "noise_hi":      (0.0, 5.0),
        # vibrato / tremolo
        "vib_r":         (0.0, 12.0),
        "vib_d":         (0.0, 25.0),
        "vib_del":       (0.0, 3.0),
        "trem_r":        (0.0, 15.0),
        "trem_d":        (0.0, 1.0),
        # detune
        "det_c":         (0.0, 30.0),
        "det_m":         (0.0, 1.0),
        # subharmonic
        "sub":           (0.0, 1.5),
        "sub_third":     (0.0, 1.5),
        # filter
        "fc_base":       (0.0, 20000.0),
        "fc_min":        (0.0, 1.0),
        "hammer_p":      (0.0, 6.0),
        "fc_alpha":      (0.0, 4.0),
        "decay_exp":     (0.0, 2.0),
        # spectral movement
        "spec_b":        (0.0, 1.5),
        "spec_tau":      (0.0, 2.0),
        "drive":         (0.0, 1.0),
        # character
        "live":          (0.0, 0.1),
        "micro":         (0.0, 1.5),
        "key_click":     (0.0, 1.0),
        "bow_noise":     (0.0, 0.1),
        "breath_noise":  (0.0, 0.1),
        "lip_shape":     (0.0, 1.0),
        "tw_leak":       (0.0, 1.0),
        # ks
        "ks_lp":         (0.0, 1.0),
        "ks_click":      (0.0, 1.0),
        # formant
        "formant_decay": (0.0, 10.0),
        "body_lf":       (0.0, 200.0),
        # strings / extra partials
        "n_strings":     (1.0, 8.0),
        "n_extra":       (0.0, 32.0),
    }

    def _validate(self):
        if self.n < 1:
            raise ValueError(f"n must be >= 1, got {self.n}")
        if self.att < 0:
            raise ValueError(f"att must be >= 0, got {self.att}")
        if self.rel < 0:
            raise ValueError(f"rel must be >= 0, got {self.rel}")
        if self.rolloff < 0:
            raise ValueError(f"rolloff must be >= 0, got {self.rolloff}")
        nyq = SR / 2
        if self.formant_freqs:
            for f in csv_parse(self.formant_freqs):
                if f >= nyq:
                    raise ValueError(f"formant freq {f} Hz >= Nyquist ({nyq} Hz)")
        for name, (lo, hi) in self._RANGES.items():
            val = getattr(self, name)
            if val < lo or val > hi:
                raise ValueError(
                    f"Timbre.{name}={val} out of range [{lo}, {hi}]. "
                    "If this is intentional, widen the range in Timbre._RANGES.")

    def copy(self, **ov) -> 'Timbre':
        return Timbre(**{k: ov.get(k, getattr(self, k)) for k in _FIELDS})

    def eff_bright(self, vel_curve: float) -> float:
        if self.hammer_hard > 0:
            t = 1 - math.exp(-self.hammer_hard * vel_curve)
            return self.bright_lo + (self.bright_hi - self.bright_lo) * t
        if self.vel_bright > 0:
            return self.bright * (1 - self.vel_bright * vel_curve * 0.5)
        return self.bright

    def eff_fc(self, vel_curve: float) -> float:
        if self.fc_base <= 0: return 0.0
        return self.fc_base * (self.fc_min + (1 - self.fc_min) * vel_curve ** self.hammer_p)

    def get_harm_amps(self) -> list:
        if self._ha_cache is None:
            self._ha_cache = csv_parse(self.harm_amps)
        return self._ha_cache

    def ref_amp(self) -> float:
        if self._ref_amp is not None:
            return self._ref_amp
        ha = self.get_harm_amps()
        if ha:
            total = max(sum(ha), 0.01)
        else:
            # Item 19: match additive._compute_partials which uses
            # max(abs(sin(...)), 0.15) to prevent the notch from pulling
            # the partial below the floor. Previously ref_amp did not
            # apply the 0.15 floor, so the normalization divisor was
            # under-estimated and per-note peak could drift 5-10%.
            total = sum(
                (1/k**self.rolloff) * math.exp(-self.bright*(k-1)) *
                (1 - self.strike_depth*(1 - max(abs(math.sin(k*math.pi*self.strike_pos)), 0.15))
                 if self.strike_pos > 0 else 1)
                for k in range(1, self.n+1)
            )
        total += self.sub + self.sub_third
        self._ref_amp = max(total, 0.01)
        return self._ref_amp
