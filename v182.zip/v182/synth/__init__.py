"""Synthesis dispatcher: engine selection, crossfade, peak cap."""
from __future__ import annotations

from typing import Optional

from .timbre import SR, A4, Timbre
from .instruments import TIMBRES
from .gm import (PROGRAM_MAP, ADDITIVE, FM, KS, SFX,
                 KS_DUR_THRESHOLD, inst_mix)
from .additive import synthesize as _additive, _apply_formants
from .fm import synthesize_fm as _fm
from .ks import synthesize_plucked as _ks_pluck
from .inharmonic import synthesize_sfx as _sfx
from .drums import drum
import numpy as np

_KS_BLEND_LO = KS_DUR_THRESHOLD - 0.25
_KS_BLEND_HI = KS_DUR_THRESHOLD + 0.15

_SFX_MIN_FREQ = 30.0
_PEAK_TARGET = 0.85


def _peak_cap(w):
    pk = np.max(np.abs(w))
    if pk > _PEAK_TARGET:
        return w * (_PEAK_TARGET / pk)
    return w


def _ks_with_formants(w: np.ndarray, tim: Timbre, freq: float = 0) -> np.ndarray:
    if tim.formant_freqs:
        w = _apply_formants(w, tim, freq)
    return _peak_cap(w)


def synthesize(freq: float, dur: float, vel: float, tim: Timbre, name: str = "default",
               nid: int = 0, pb_curve: Optional[np.ndarray] = None) -> np.ndarray:
    cfg = inst_mix(name)
    engine = cfg.engine

    if engine == SFX:
        if freq < _SFX_MIN_FREQ:
            return np.zeros(0)
        return _peak_cap(_sfx(freq, dur, vel, tim, name, nid, pb_curve=pb_curve))

    if engine == FM:
        return _peak_cap(_fm(freq, dur, vel, tim, name, nid, pb_curve=pb_curve))

    if engine == KS:
        if dur < _KS_BLEND_LO or cfg.ks_always:
            w = _ks_with_formants(
                _ks_pluck(freq, dur, vel, tim, name, nid, pb_curve=pb_curve),
                tim, freq)
            return _peak_cap(w)
        if dur <= _KS_BLEND_HI:
            w = _ks_with_formants(
                _ks_pluck(freq, dur, vel, tim, name, nid, pb_curve=pb_curve),
                tim, freq)
            w_add = _additive(freq, dur, vel, tim, name, nid, pb_curve=pb_curve)
            n = min(len(w), len(w_add))
            rms_ks = np.sqrt(np.mean(w[:n] ** 2)) + 1e-10
            rms_add = np.sqrt(np.mean(w_add[:n] ** 2)) + 1e-10
            w_add *= rms_ks / rms_add
            blend = (dur - _KS_BLEND_LO) / (_KS_BLEND_HI - _KS_BLEND_LO)
            out = np.zeros(max(len(w), len(w_add)))
            out[:len(w)] += np.sqrt(1 - blend) * w
            out[:len(w_add)] += np.sqrt(blend) * w_add
            return _peak_cap(out)
        w = _additive(freq, dur, vel, tim, name, nid, pb_curve=pb_curve)
        w *= cfg.ks_gain
        return _peak_cap(w)

    return _peak_cap(_additive(freq, dur, vel, tim, name, nid, pb_curve=pb_curve))