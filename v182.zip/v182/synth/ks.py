"""KS plucked string with LP-phase-delay pitch compensation.

Triangle pulse excitation, 2x oversampling, anti-harshness LP.
LP phase delay subtracted from delay line for sub-cent pitch accuracy.
"""
from __future__ import annotations
import math
from typing import Optional
import numpy as np
from .dsp import BoundedCache
from scipy.signal import resample_poly, butter, sosfilt
from .timbre import SR, Timbre, vc

OS = 2
SR_OS = SR * OS
KS_T60 = 2.0
KS_MUTE = 0.985
KS_LP_BASE = 0.55
KS_LP_VEL = 0.08
_AH_CACHE = BoundedCache(32, name="ks.anti_harsh")


def _lp_phase_delay(coeff, freq):
    """Phase delay of 1-pole LP: y = a*x + (1-a)*y_prev."""
    w0 = 2 * math.pi * freq / SR_OS
    if w0 < 1e-12:
        return (1.0 - coeff) / max(coeff, 1e-12)
    b = 1.0 - coeff
    phase = -math.atan2(b * math.sin(w0), 1.0 - b * math.cos(w0))
    return -phase / w0


def _anti_harshness(out, freq):
    fc = min(12000 + freq * 3, SR * 0.45)
    key = int(fc / 100)
    if key not in _AH_CACHE:
        _AH_CACHE[key] = butter(1, key * 100, btype='low', fs=SR, output='sos')
    return sosfilt(_AH_CACHE[key], out)


def synthesize_plucked(freq: float, dur: float, vel: float, tim: Timbre,
                       name: str = "guitar", nid: int = 0,
                       pb_curve: Optional[np.ndarray] = None) -> np.ndarray:
    """Karplus-Strong plucked string with optional per-sample pitch bend.

    v159 #16 fix: pitch bend is now handled INSIDE the engine instead of
    via the old ``_apply_pb_shift`` post-processor which used a different
    semantic from additive/FM (variable-rate read on a pre-rendered
    buffer). The delay-line read distance varies per sample so that
    ``freq_eff(t) = freq * 2 ** (pb_curve[t] / 12)``.

    Args:
        pb_curve: per-sample pitch bend in semitones (at SR, not SR_OS).
                  May be None.
    """
    tail = min(tim.rel * 1.2 + 0.35, 2.5)
    n = int(SR * (dur + tail))
    if n == 0:
        return np.zeros(0)
    n_os = n * OS
    v = vc(vel)
    rng = np.random.RandomState((int(freq * 100 + vel * 1000) + nid * 7919) % (2**31))

    # LP coefficient
    lp_base = (tim.ks_lp if tim.ks_lp > 0 else KS_LP_BASE) + KS_LP_VEL * v
    lp = 1.0 - (1.0 - lp_base) ** 0.5

    # Base period at nominal freq (no bend) and LP phase-delay compensation
    period = SR_OS / freq
    lp_delay = _lp_phase_delay(lp, freq)
    adj_base = period - lp_delay

    # Prepare pitch-bend ratio at SR_OS (repeat SR samples ×OS)
    pb_active = pb_curve is not None and np.max(np.abs(pb_curve[:n])) > 0.005
    if pb_active:
        pb_os = np.repeat(pb_curve[:n] if len(pb_curve) >= n
                          else np.pad(pb_curve, (0, n - len(pb_curve)), mode='edge'),
                          OS)
        if len(pb_os) < n_os:
            pb_os = np.pad(pb_os, (0, n_os - len(pb_os)), mode='edge')
        ratio = 2.0 ** (pb_os / 12.0)
        # Per-sample adj (accounts for both PB and LP delay)
        adj_arr = adj_base / ratio
        max_adj = float(np.max(adj_arr))
    else:
        adj_arr = None
        max_adj = adj_base

    # Allocate a ring buffer big enough for the deepest delay AND for
    # the initial excitation. PB up makes adj_arr < adj_base; PB down
    # makes adj_arr > adj_base. We need to cover the worst case of both.
    ring_span = max(max_adj, adj_base)
    dl_len_max = max(int(math.ceil(ring_span * 1.05)) + 4, 4)

    # Initial delay-line contents: classic triangle excitation
    pos = tim.strike_pos if tim.strike_pos > 0.01 else 0.14
    exc_len = max(int(math.ceil(adj_base)), 2)
    pk_idx = max(1, min(int(pos * exc_len), exc_len - 2))
    exc = np.zeros(dl_len_max)
    # ramp up 0..1 over pk_idx+1 samples, then ramp down 1..0 over the rest
    exc[:pk_idx + 1] = np.linspace(0, 1, pk_idx + 1)
    tail_len = exc_len - pk_idx
    if tail_len > 1:
        exc[pk_idx:exc_len] = np.linspace(1, 0, tail_len)
    exc[:exc_len] -= np.mean(exc[:exc_len])
    exc[:exc_len] *= v * 0.8
    click = tim.ks_click if tim.ks_click > 0 else 0.05
    click_noise = rng.randn(exc_len) * click * v * 0.5
    click_noise -= np.mean(click_noise)
    exc[:exc_len] += click_noise

    loss_base = 10 ** (-3 / (max(freq, 40) * KS_T60))
    loss = math.sqrt(loss_base)
    noff_os = int(SR_OS * dur)
    loss_mute = loss * KS_MUTE

    dl = exc.copy()
    out_os = np.zeros(n_os)
    # v160 #10 note: wptr starts just past the excitation content. If
    # PB happens to push adj_arr[0] beyond exc_len in the slow path,
    # the first few samples read a zero region (pre-excitation), which
    # produces a sub-millisecond silence at note onset. This only
    # triggers with extreme downward PB on the very first sample and
    # is inaudible in practice; not worth pre-filling the ring.
    wptr = exc_len % dl_len_max
    prev = 0.0

    if adj_arr is None:
        # Fixed-delay fast path (no pitch bend) — same behavior as v158
        adj_static = adj_base
        dl_len = max(int(math.ceil(adj_static)), 2)
        frac_static = dl_len - adj_static
        if frac_static < 0:
            dl_len += 1
            frac_static += 1.0
        elif frac_static >= 1.0:
            dl_len -= 1
            frac_static -= 1.0
        dl_len = max(dl_len, 2)
        ptr = 0
        for i in range(n_os):
            idx1 = (ptr + 1) % dl_len
            val = dl[ptr] + frac_static * (dl[idx1] - dl[ptr])
            filt = lp * val + (1 - lp) * prev
            prev = filt
            out_os[i] = val
            dl[ptr] = filt * (loss if i < noff_os else loss_mute)
            ptr = (ptr + 1) % dl_len
    else:
        # Pitch-bent path: variable read-back distance per sample.
        # v160 #9: precompute all read indices and write positions as
        # vectorized arrays outside the Python loop. The inner loop
        # still has to be sequential because each `filt` computation
        # depends on `prev` from the previous iteration (the 1-pole LP
        # is a recursive IIR), and the write-back to `dl[wptr]` changes
        # values read at future iterations. But integer index math,
        # modulo, and fractional coefficients can all be precomputed.
        i_range = np.arange(n_os, dtype=np.int64)
        wptr_arr = (wptr + i_range) % dl_len_max          # (n_os,)
        rpos_arr = (wptr + i_range - adj_arr) % dl_len_max  # (n_os,)
        ri0_arr = np.floor(rpos_arr).astype(np.int64)
        ri1_arr = (ri0_arr + 1) % dl_len_max
        f_arr = rpos_arr - ri0_arr                         # fractional part
        one_minus_f = 1.0 - f_arr
        loss_arr = np.where(i_range < noff_os, loss, loss_mute)
        lp_inv = 1.0 - lp
        for i in range(n_os):
            ri0 = ri0_arr[i]
            ri1 = ri1_arr[i]
            val = dl[ri0] * one_minus_f[i] + dl[ri1] * f_arr[i]
            filt = lp * val + lp_inv * prev
            prev = filt
            out_os[i] = val
            dl[wptr_arr[i]] = filt * loss_arr[i]

    out = resample_poly(out_os, 1, OS)[:n]
    # Decorrelate multi-track unison: shift output by a fraction of one
    # period.  KS steady-state converges to a unique waveform shape
    # regardless of excitation, so phase can only be varied by delaying
    # the output.  A sub-period delay is inaudible but decorrelates.
    if nid > 0 and freq > 20:
        period_samples = max(int(SR / freq), 1)
        delay = int(nid * period_samples / 5.3)  # spread ~evenly across period
        delay = max(1, min(delay, n - 1))
        out = np.roll(out, delay)
        fade = min(delay, 32)
        out[:fade] *= np.linspace(0, 1, fade)  # fade in to avoid click
    pk = np.max(np.abs(out))
    if pk > 1e-6:
        out *= 0.85 / pk    # leave headroom; matches synth/__init__._peak_cap target

    att_n = min(int(SR * max(tim.att, 0.002)), n)
    if att_n > 1:
        out[:att_n] *= np.linspace(0, 1, att_n) ** 0.5

    cn = min(int(SR * 0.003), n)
    if cn > 0:
        cs = rng.randn(cn) * click * v * np.exp(-np.arange(cn) * 12.0 / cn)
        cf = min(int(SR * 0.0004), cn)
        if cf > 1:
            cs[:cf] *= np.linspace(0, 1, cf)
        out[:cn] += cs
    bn = min(int(SR * 0.012), n)
    if bn > 1 and click > 0.03:
        body = rng.randn(bn) * click * v * 0.25
        body *= np.exp(-np.arange(bn) * 5.0 / bn)
        body *= np.sin(2 * np.pi * min(freq * 2.5, SR * 0.4) * np.arange(bn) / SR)
        out[:bn] += body

    if n > SR // 4:
        out -= np.mean(out)
    if n > 256:
        out = _anti_harshness(out, freq)

    pk2 = np.max(np.abs(out))
    if pk2 > 0.85:
        out *= 0.85 / pk2

    ac = min(128, n)
    if ac > 1:
        out[-ac:] *= 0.5 * (1 + np.cos(np.linspace(0, np.pi, ac)))
    return out * (0.15 + 0.85 * v)
