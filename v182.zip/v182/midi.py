"""MIDI parser. Supports GM standard CCs, aftertouch, pitch bend, RPN."""
from __future__ import annotations

import bisect
from typing import Dict, List, Tuple

import mido

from config import (MAX_PEDAL_SUSTAIN, MAX_NOTE_DUR, GHOST_DUR_THRESH,
                    LEGATO_MAX_GAP, LEGATO_INSTRUMENTS)
from schema import Note, ChannelData, ParseResult, NoteEvent, EventKind
from synth.gm import PROGRAM_MAP


def _tempo_map(mid: mido.MidiFile) -> Tuple[List[int], List[int], List[float]]:
    """Parse tempo changes into three parallel arrays for O(log T) lookup.

    Returns:
      ticks: sorted list of tempo-change ticks
      tempos: tempo (μs per beat) at each index
      sec_at_tick: cumulative seconds at each tempo-change tick

    This replaces v158's per-event linear scan over ``tmap`` in
    ``_tick2sec`` with a single ``bisect_right`` per query (#19 fix).
    """
    raw: List[Tuple[int, int]] = []
    for tr in mid.tracks:
        tick = 0
        for msg in tr:
            tick += msg.time
            if msg.type == "set_tempo":
                raw.append((tick, msg.tempo))
    raw.sort()
    if not raw or raw[0][0] != 0:
        raw.insert(0, (0, 500000))
    tpb = mid.ticks_per_beat
    ticks = [t for t, _ in raw]
    tempos = [tp for _, tp in raw]
    sec_at_tick = [0.0]
    for i in range(1, len(raw)):
        delta_ticks = ticks[i] - ticks[i - 1]
        sec_at_tick.append(sec_at_tick[-1] + delta_ticks / tpb * tempos[i - 1] / 1e6)
    return ticks, tempos, sec_at_tick


def _tick2sec(tick: int,
              tmap: Tuple[List[int], List[int], List[float]],
              tpb: int) -> float:
    """O(log T) via bisect. See _tempo_map docstring."""
    ticks, tempos, sec_at_tick = tmap
    # Find the tempo segment containing ``tick``
    # bisect_right gives us the insertion index; -1 is the current segment.
    i = bisect.bisect_right(ticks, tick) - 1
    if i < 0:
        i = 0
    return sec_at_tick[i] + (tick - ticks[i]) / tpb * tempos[i] / 1e6


def _ensure_ch(ch_data: Dict[int, ChannelData], ch: int) -> ChannelData:
    if ch not in ch_data:
        ch_data[ch] = ChannelData()
    return ch_data[ch]


def _dedup_cc(ch_data: Dict[int, ChannelData]) -> None:
    for _ch, cd in ch_data.items():
        for attr in ("vol", "expr", "mod", "pb", "aftertouch",
                     "brightness", "reverb", "chorus"):
            evts = getattr(cd, attr)
            if not evts:
                continue
            evts.sort(key=lambda x: x[0])
            deduped: list = []
            for t, v in evts:
                if deduped and abs(t - deduped[-1][0]) < 1e-9:
                    deduped[-1] = (t, v)
                else:
                    deduped.append((t, v))
            setattr(cd, attr, deduped)


def parse_events(
    path: str,
) -> Tuple[List[NoteEvent], Dict[int, ChannelData], Dict[int, int]]:
    """Parse MIDI into NoteEvents (with dur via forward scan) + ChannelData + pan.

    Returns (events, ch_data, channel_pan).

    Raises RuntimeError on read failure or if the file contains no events.
    """
    try:
        mid = mido.MidiFile(path)
    except Exception as e:
        raise RuntimeError(f"Failed to read MIDI file '{path}': {e}") from e

    tmap = _tempo_map(mid)
    ch_data: Dict[int, ChannelData] = {}
    raw_events: list = []
    channel_prog: Dict[int, int] = {}
    channel_pan: Dict[int, int] = {}
    rpn_msb: Dict[int, int] = {}
    rpn_lsb: Dict[int, int] = {}
    # v159 wave A fix #8: defer program binding for notes triggered before
    # any program_change on their channel. We collect the first program_change
    # seen per channel and retroactively patch early notes to use it.
    first_prog: Dict[int, int] = {}
    pending_notes: List[int] = []   # indices into raw_events of notes awaiting first_prog

    for track in mid.tracks:
        tick = 0
        for msg in track:
            tick += msg.time
            t = _tick2sec(tick, tmap, mid.ticks_per_beat)
            ch = msg.channel if hasattr(msg, "channel") else 0
            if msg.type == "program_change":
                channel_prog[ch] = msg.program
                # Retroactively bind any pending notes on this channel
                if ch not in first_prog:
                    first_prog[ch] = msg.program
                    still_pending = []
                    for idx in pending_notes:
                        ev = raw_events[idx]
                        if ev[4] == ch:
                            raw_events[idx] = (ev[0], ev[1], ev[2], ev[3], ev[4], msg.program)
                        else:
                            still_pending.append(idx)
                    pending_notes = still_pending
            elif msg.type == "note_on" and msg.velocity > 0:
                prog = channel_prog.get(ch, 0)
                idx = len(raw_events)
                raw_events.append((t, EventKind.NOTE_ON, msg.note,
                                   msg.velocity / 127.0, ch, prog))
                # If no program_change has occurred yet on this channel,
                # remember this note so a later program_change can patch it.
                if ch not in channel_prog:
                    pending_notes.append(idx)
            elif msg.type == "note_off" or (msg.type == "note_on"
                                            and msg.velocity == 0):
                raw_events.append((t, EventKind.NOTE_OFF, msg.note,
                                   0.0, ch, channel_prog.get(ch, 0)))
            elif msg.type == "pitchwheel":
                cd = _ensure_ch(ch_data, ch)
                cd.pb.append((t, msg.pitch / 8192.0 * cd.pb_range))
            elif msg.type == "aftertouch":
                _ensure_ch(ch_data, ch).aftertouch.append(
                    (t, msg.value / 127.0))
            elif msg.type == "polytouch":
                # #9 fix: degrade polyphonic aftertouch to channel aftertouch
                # using the max pressure across simultaneous notes.
                cd = _ensure_ch(ch_data, ch)
                if cd.aftertouch and cd.aftertouch[-1][0] == t:
                    cd.aftertouch[-1] = (t, max(cd.aftertouch[-1][1],
                                                msg.value / 127.0))
                else:
                    cd.aftertouch.append((t, msg.value / 127.0))
            elif msg.type == "control_change":
                cc, val = msg.control, msg.value
                if cc == 64:
                    raw_events.append((t, EventKind.PEDAL, 0,
                                       float(val >= 64), ch, 0))
                elif cc in (120, 123):
                    # #9 fix: CC 120 = All Sound Off, CC 123 = All Notes Off.
                    # Emit a synthetic event that _events_to_notes resolves
                    # by closing every active/held note on this channel.
                    raw_events.append((t, EventKind.ALL_OFF, 0, 0.0, ch, 0))
                elif cc == 10:
                    channel_pan[ch] = val
                elif cc == 7:
                    _ensure_ch(ch_data, ch).vol.append((t, val / 127.0))
                elif cc == 11:
                    _ensure_ch(ch_data, ch).expr.append((t, val / 127.0))
                elif cc == 1:
                    _ensure_ch(ch_data, ch).mod.append((t, val / 127.0))
                elif cc == 91:
                    _ensure_ch(ch_data, ch).reverb.append(
                        (t, val / 127.0))
                elif cc == 93:
                    _ensure_ch(ch_data, ch).chorus.append(
                        (t, val / 127.0))
                elif cc == 74:
                    _ensure_ch(ch_data, ch).brightness.append(
                        (t, val / 127.0))
                elif cc == 100:
                    rpn_lsb[ch] = val
                elif cc == 101:
                    rpn_msb[ch] = val
                elif cc == 6:
                    if rpn_msb.get(ch) == 0 and rpn_lsb.get(ch) == 0:
                        _ensure_ch(ch_data, ch).pb_range = float(val)
                elif cc == 121:
                    rpn_msb.pop(ch, None)
                    rpn_lsb.pop(ch, None)

    if not raw_events:
        raise RuntimeError(f"MIDI file '{path}' contains no note events")

    raw_events.sort(key=lambda e: (e[0], -e[1]))
    _dedup_cc(ch_data)

    # Single source of truth for note duration is _events_to_notes (active/held tracking).
    events: List[NoteEvent] = [
        NoteEvent(t, kind, midi_note, vel, ch, prog)
        for t, kind, midi_note, vel, ch, prog in raw_events
    ]
    return events, ch_data, channel_pan


def _events_to_notes(events: List[NoteEvent]) -> List[Note]:
    """Resolve NoteEvents into Notes, handling pedal-extended durations."""
    pedal_on: Dict[int, bool] = {}
    active: Dict[Tuple[int, int], NoteEvent] = {}
    held: Dict[Tuple[int, int], NoteEvent] = {}
    notes: List[Note] = []

    for ev in events:
        if ev.kind == EventKind.NOTE_ON:
            key = (ev.ch, ev.midi)
            for store in (active, held):
                if key in store:
                    old = store.pop(key)
                    notes.append(Note(old.time, old.midi,
                                      max(ev.time - old.time, 0.01),
                                      old.vel, old.ch, old.prog))
            active[key] = ev
        elif ev.kind == EventKind.NOTE_OFF:
            key = (ev.ch, ev.midi)
            if key in active:
                if pedal_on.get(ev.ch, False):
                    held[key] = active.pop(key)
                else:
                    old = active.pop(key)
                    notes.append(Note(old.time, old.midi,
                                      max(ev.time - old.time, 0.01),
                                      old.vel, old.ch, old.prog))
        elif ev.kind == EventKind.PEDAL:
            if ev.vel > 0.5:
                pedal_on[ev.ch] = True
            else:
                pedal_on[ev.ch] = False
                for key in list(held):
                    if key[0] == ev.ch:
                        old = held.pop(key)
                        dur = min(max(ev.time - old.time, 0.01),
                                  MAX_PEDAL_SUSTAIN)
                        notes.append(Note(old.time, old.midi, dur,
                                          old.vel, old.ch, old.prog))
        elif ev.kind == EventKind.ALL_OFF:
            # #9 fix: CC 120/123 — close every active/held note on this channel.
            # Critical for MIDI files from DAWs that use these to prevent stuck
            # notes instead of emitting matching note_offs.
            for store in (active, held):
                for key in list(store):
                    if key[0] == ev.ch:
                        old = store.pop(key)
                        notes.append(Note(old.time, old.midi,
                                          max(ev.time - old.time, 0.01),
                                          old.vel, old.ch, old.prog))
            pedal_on[ev.ch] = False

    max_time: float = events[-1].time + 2.0 if events else 0.0
    for store in (active, held):
        for _key, ev in list(store.items()):
            dur = min(max(max_time - ev.time, 0.01), MAX_PEDAL_SUSTAIN)
            notes.append(Note(ev.time, ev.midi, dur, ev.vel, ev.ch, ev.prog))
    return notes


def _legato_merge(notes: List[Note]) -> Tuple[List[Note], int]:
    """Merge consecutive same-pitch same-channel notes on sustained
    instruments when their gap is < LEGATO_MAX_GAP.

    See config.LEGATO_INSTRUMENTS for which instrument families this
    applies to and config.LEGATO_MAX_GAP for the threshold.

    Returns (merged_notes, n_merged) where n_merged is the count of
    notes absorbed (so original_len - len(merged_notes)).
    """
    from collections import defaultdict
    by_key: Dict[Tuple[int, int], List[Note]] = defaultdict(list)
    passthrough: List[Note] = []
    for n in notes:
        nm = "drums" if n.ch == 9 else PROGRAM_MAP.get(n.prog, "default")
        if nm in LEGATO_INSTRUMENTS:
            by_key[(n.ch, n.midi)].append(n)
        else:
            passthrough.append(n)

    merged: List[Note] = []
    n_merged = 0
    for group in by_key.values():
        group.sort(key=lambda x: x.start)
        cur = group[0]
        for nxt in group[1:]:
            gap = nxt.start - (cur.start + cur.dur)
            if 0 <= gap <= LEGATO_MAX_GAP:
                # Absorb nxt into cur. New end is later of the two; new
                # velocity is max so an accent stays an accent.
                new_end = max(cur.start + cur.dur, nxt.start + nxt.dur)
                cur = cur._replace(dur=new_end - cur.start,
                                   vel=max(cur.vel, nxt.vel))
                n_merged += 1
            else:
                merged.append(cur)
                cur = nxt
        merged.append(cur)
    return passthrough + merged, n_merged


def _dedup_cross_channel(notes: List[Note]) -> Tuple[List[Note], int]:
    """Remove duplicate notes: same instrument + pitch at near-same time
    on different channels.

    Common in GM MIDI: arrangers layer the same melody across channels
    for thickness. Our renderer gives each copy independent micro-variation,
    causing phase interference (beating, flanging) and doubled transients.
    Keep only the loudest per (instrument, pitch, start_time) cluster.
    """
    from collections import defaultdict
    DEDUP_WINDOW = 0.015  # 15 ms tolerance

    by_key: Dict[Tuple[str, int], List[Note]] = defaultdict(list)
    drums: List[Note] = []
    for n in notes:
        if n.ch == 9:
            drums.append(n)
        else:
            nm = PROGRAM_MAP.get(n.prog, "default")
            by_key[(nm, n.midi)].append(n)

    kept: List[Note] = list(drums)
    n_removed = 0
    for group in by_key.values():
        if len(group) <= 1:
            kept.extend(group)
            continue
        group.sort(key=lambda x: x.start)
        i = 0
        while i < len(group):
            cluster = [group[i]]
            j = i + 1
            while j < len(group) and group[j].start - group[i].start <= DEDUP_WINDOW:
                cluster.append(group[j])
                j += 1
            best = max(cluster, key=lambda n: n.vel)
            kept.append(best)
            n_removed += len(cluster) - 1
            i = j
    return kept, n_removed


def parse(path: str) -> ParseResult:
    """Parse MIDI file. Built on parse_events().

    Raises RuntimeError on read failure, empty file, or no-note file.
    """
    events, ch_data, channel_pans = parse_events(path)
    notes = _events_to_notes(events)
    if not notes:
        raise RuntimeError(f"MIDI file '{path}' produced no notes after parsing")

    # Cap unreasonably long notes (MIDI editor artifacts) and discard
    # ghost notes (sub-12 ms non-drum notes that produce clicks).
    cleaned: List[Note] = []
    n_ghost = 0
    n_capped = 0
    for n in notes:
        if n.ch != 9 and n.dur <= GHOST_DUR_THRESH:
            n_ghost += 1
            continue
        if n.dur > MAX_NOTE_DUR:
            n_capped += 1
            cleaned.append(n._replace(dur=MAX_NOTE_DUR))
        else:
            cleaned.append(n)
    if n_ghost or n_capped:
        print(f"  midi cleanup  {n_ghost} ghost notes removed, {n_capped} notes capped to {MAX_NOTE_DUR}s", flush=True)
    notes = cleaned

    notes, n_merged = _legato_merge(notes)
    if n_merged:
        print(f"  legato merge  {n_merged} notes merged "
              f"({sorted(LEGATO_INSTRUMENTS)}, gap ≤ {LEGATO_MAX_GAP*1000:.0f} ms)",
              flush=True)

    notes, n_dedup = _dedup_cross_channel(notes)
    if n_dedup:
        print(f"  dedup         {n_dedup} duplicate notes removed "
              f"(cross-channel, ≤15 ms window)", flush=True)

    return ParseResult(notes=notes, channel_pans=channel_pans, ch_data=ch_data)
