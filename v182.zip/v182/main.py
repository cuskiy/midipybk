"""Entry point: render one MIDI file to one FLAC file. That is the whole job.

Defaults produce the best quality the renderer can deliver. Use --jobs
to control parallelism (default: auto, 0 = serial).
"""
import argparse
import os
import sys

from _version import VERSION, VERSION_PUBLIC, PROJECT_NAME   # noqa: F401 (re-exported for callers)


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Render a Standard MIDI File to a 24-bit/44.1 kHz FLAC.")
    ap.add_argument("input", help="Input .mid file")
    ap.add_argument("-o", "--output", default=None,
                    help="Output .flac (default: <input>.flac)")
    ap.add_argument("--spatial", action="store_true",
                    help="Binaural HRTF mode (recommended for headphones)")
    ap.add_argument("--stems", action="store_true",
                    help="Also export per-instrument stems next to the mix")
    ap.add_argument("--stems-dir", default=None,
                    help="Custom output directory for stems")
    ap.add_argument("--start", type=float, default=None,
                    help="Start time in seconds (partial render)")
    ap.add_argument("--end", type=float, default=None,
                    help="End time in seconds (partial render)")
    ap.add_argument("-j", "--jobs", type=int, default=None,
                    help="Max parallel workers (0=serial, default=auto)")
    a = ap.parse_args()

    if not os.path.isfile(a.input):
        print(f"Error: file not found: {a.input}", file=sys.stderr)
        sys.exit(1)

    from midi import parse
    from mix import render

    try:
        result = parse(a.input)
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    out = a.output or a.input.rsplit(".", 1)[0] + ".flac"
    render(result, out, spatial=a.spatial, stems=a.stems,
           stems_dir=a.stems_dir, region=(a.start, a.end),
           max_jobs=a.jobs)


if __name__ == "__main__":
    main()
