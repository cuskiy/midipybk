# PROGRAM_MAP History

`synth/gm.py::PROGRAM_MAP` routes GM program numbers (0–127) to internal
instrument names. This file logs every change since v78 with reason and
audible impact, so a regression in any old MIDI is traceable.

The bound contract: a baseline of these mappings is pinned by
`test/test_v159_fixes.py::test_program_map_baseline`. Edit that test in
the same commit when you change a mapping.

## Current map (v159)

| Program range | Name        | Notes                                |
|---------------|-------------|--------------------------------------|
| 0–3           | piano       | acoustic + electric grands           |
| 4–5           | epiano      | rhodes / dx                          |
| 6–7           | harpsichord |                                      |
| 8–10          | celesta     |                                      |
| 11            | vibes       |                                      |
| 12–13         | marimba     |                                      |
| 14            | vibes       | tubular bells routed to vibes        |
| 15            | harp        | dulcimer routed to harp              |
| 16–23         | organ       |                                      |
| 24            | nylon       |                                      |
| 25            | guitar      | acoustic steel                       |
| 26–31         | guitar      |                                      |
| 32–37         | bass        |                                      |
| 38–39         | synbass     |                                      |
| 40–41         | strings     | violin + viola                       |
| 42            | cello       |                                      |
| 43            | contrabass  |                                      |
| 44–45         | strings     |                                      |
| 45            | pluck       | tremolo strings                      |
| 46            | harp        |                                      |
| 47            | marimba     | timpani routed to marimba            |
| 48–51         | strings     | string ensembles + synth strings     |
| 52–55         | choir       |                                      |
| 56–63         | brass       |                                      |
| 64–71         | woodwind    |                                      |
| 72–75         | flute       |                                      |
| 76–79         | woodwind    |                                      |
| 80–87         | lead        |                                      |
| 88–99         | pad         |                                      |
| 100–103       | lead        |                                      |
| 104–107       | guitar      | ethnic strings routed to guitar      |
| 108–109       | celesta     |                                      |
| 110–111       | vibes       |                                      |
| 112–115       | marimba     |                                      |
| 116–119       | pluck       |                                      |
| 120–127       | sfx         |                                      |

## Changes since v78

### v158 → v159
No PROGRAM_MAP changes.

### v140 → v158 (approximate, not all reasons recorded in source)
- `0–5 → piano` split into `0–3 → piano`, `4–5 → epiano`. Reason: GM
  programs 4 and 5 are "Electric Piano 1/2", not acoustic. Old MIDIs that
  used program 4–5 expecting acoustic piano will now sound like rhodes.
- `14 → epiano` changed to `14 → vibes`. Reason: GM 14 is "Tubular Bells",
  closer to vibes than to electric piano.
- `15` newly mapped to `harp` (was implicit default in v78).
- `42–43 → cello` split into `42 → cello`, `43 → contrabass`. Reason:
  GM 42 is Cello, GM 43 is Contrabass; v78 lumped them.
- `45 → pluck` (Tremolo Strings) carved out of the strings range.
- `47 → marimba` (Timpani) — chosen because the marimba engine has the
  closest mallet character available.
- New names introduced post-v78: `synbass` (38–39), `contrabass` (43),
  `pluck` (45, 116–119), `sfx` (120–127).

### v78 baseline
```
0–5     piano
6–7     harpsichord
8–10    celesta
11      vibes
12–13   marimba
14–15   epiano
16–23   organ
24–25   nylon
26–31   guitar
32–37   bass
38–39   synbass        (already present in v78)
40–41   strings
42–43   cello
44–45   strings
46–47   harp
48–51   strings
52–55   choir
56–63   brass
64–71   woodwind
72–75   flute
76–79   woodwind
80–87   lead
88–99   pad
100–103 lead
104–107 guitar
108–109 celesta
110–111 vibes
112–115 marimba
116–119 pluck
120–127 sfx
```

## How to add a change entry

1. Edit `synth/gm.py::PROGRAM_MAP`.
2. Update the table above and add a bullet under the new version section.
3. Update `test/test_v159_fixes.py::test_program_map_baseline` to reflect
   the new expected mapping (or add new asserts).
4. If you have a MIDI file that exercises the changed range, drop a
   minimal copy under `test/fixtures/program_<n>.mid` for future regression.
