# v49

## Changes from v48

### Performance
- **Scalar math**: numpy→math for per-partial scalar ops in additive setup (piano 155→98ms/note, strings 45→15ms/note)
- **Cached ref_amp/harm_amps**: computed once per Timbre, not per note
- **KS calibration**: 12→6 synthesis calls (0.95→0.5s startup)
- **FDN reverb IR**: inline Hadamard (no matrix multiply per sample)
- **Compressor**: vectorized block-peak with reshape

### No audio quality changes
- v48 vs v49 max sample difference: 4.4e-16 (machine epsilon)

## Cumulative changes from v46
- Per-instrument HP filtering for mix clarity
- Drum VOLUME 0.55→0.78
- Piano/epiano/guitar/nylon spectral improvements
- KS/additive equal-power crossfade with gain calibration
- track_peak_cap 0.85→2.5
- Buffer tail formula fix
- Lazy reverb IR, HRTF center bypass
