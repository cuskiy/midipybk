"""GM routing — single source of truth for per-instrument mix parameters."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

# ── Engine enum ──────────────────────────────────────────────────────
ADDITIVE = "additive"
FM = "fm"
KS = "ks"
SFX = "sfx"


@dataclass(frozen=True)
class InstrumentMix:
    """All per-instrument routing and mix parameters in one place.

    A new instrument only touches INSTRUMENT_MIX (below) and the
    Timbre preset in synth/instruments.py. Previously it required
    thirteen separate dicts to be kept in sync, with no error if you
    forgot one.
    """
    engine:       str = ADDITIVE   # "additive" | "fm" | "ks" | "sfx"
    pan:          float = 0.0      # degrees, + = right
    center_lock:  bool = False     # bypass auto-spread
    volume:       float = 1.0      # relative mix gain
    hp:           float = 45.0     # track high-pass cutoff Hz
    chorus_cap:   float = 1.0      # clamp on CC93 before chorus module
    reverb_send:  float = 1.0      # scale on CC91 to reverb bus
    sympa:        bool = False     # participates in sympathetic resonance
    ks_always:    bool = False     # KS engine at all durations (not just short)
    ks_gain:      float = 1.0      # KS→additive calibration multiplier
    # Per-instrument low-mid boom cut (center, gain_dB, Q); None = no cut
    boom_cut:     Optional[Tuple[float, float, float]] = None


# ── The master table ─────────────────────────────────────────────────
#
# Defaults come from InstrumentMix(). Only specify fields that differ.

INSTRUMENT_MIX: Dict[str, InstrumentMix] = {
    # v165: boom_cut removed from most instruments. The master EQ is now
    # nearly flat, so track-level scooping is unnecessary and harmful.
    # Only contrabass keeps a gentle one to prevent sub buildup.
    "piano":       InstrumentMix(pan=0,    hp=35.0, sympa=True,
                                 boom_cut=(120.0, -0.8, 0.5)),
    "epiano":      InstrumentMix(pan=-12,  hp=30.0, engine=FM),
    "organ":       InstrumentMix(pan=5,    hp=40.0),
    "harpsichord": InstrumentMix(pan=-8,   hp=28.0, engine=KS, sympa=True,
                                 ks_gain=3.6226),

    "guitar":      InstrumentMix(pan=-25,  hp=55.0, engine=KS, ks_gain=1.9971),
    "nylon":       InstrumentMix(pan=-20,  hp=55.0, engine=KS, ks_gain=1.6414,
                                 ks_always=True),

    "bass":        InstrumentMix(pan=0, center_lock=True, hp=35.0,
                                 volume=0.82, chorus_cap=0.15, reverb_send=0.40),
    "synbass":     InstrumentMix(pan=0, center_lock=True, hp=35.0,
                                 volume=0.70, chorus_cap=0.15, reverb_send=0.30),

    "strings":     InstrumentMix(pan=22,   hp=45.0, chorus_cap=0.40),
    "cello":       InstrumentMix(pan=15,   hp=35.0, chorus_cap=0.30),
    "contrabass":  InstrumentMix(pan=10,   hp=48.0, volume=0.90,
                                 boom_cut=(200.0, -0.8, 0.8)),

    "brass":       InstrumentMix(pan=30,   hp=45.0),
    "woodwind":    InstrumentMix(pan=-22,  hp=65.0),
    "flute":       InstrumentMix(pan=-18,  hp=95.0),
    "choir":       InstrumentMix(pan=0, center_lock=True, hp=55.0),

    "celesta":     InstrumentMix(pan=12,   hp=130.0, engine=FM),
    "vibes":       InstrumentMix(pan=-16,  hp=70.0, engine=FM),
    "marimba":     InstrumentMix(pan=-12,  hp=60.0, engine=FM),

    "harp":        InstrumentMix(pan=18,   hp=25.0, engine=KS, sympa=True,
                                 ks_gain=2.8367),

    "pad":         InstrumentMix(pan=0, center_lock=True, hp=65.0, volume=0.62,
                                 boom_cut=(350.0, -1.0, 0.7)),
    "lead":        InstrumentMix(pan=10,   hp=120.0, volume=0.95, reverb_send=0.50),
    "pluck":       InstrumentMix(pan=-14,  hp=40.0),

    "drums":       InstrumentMix(pan=0, center_lock=True, hp=25.0,
                                 volume=0.78, chorus_cap=0.0, reverb_send=0.50),
    "sfx":         InstrumentMix(pan=0, center_lock=True, hp=55.0,
                                 volume=0.65, reverb_send=0.45, engine=SFX),
    "default":     InstrumentMix(),
}


def inst_mix(name: str) -> InstrumentMix:
    """Lookup with fallback to default. Single entry point for consumers."""
    return INSTRUMENT_MIX.get(name, INSTRUMENT_MIX["default"])


# ── Program → instrument name mapping ────────────────────────────────
PROGRAM_MAP: Dict[int, str] = {}
for _r, _n in [
    (range(0, 4), "piano"), (range(4, 6), "epiano"),
    (range(6, 8), "harpsichord"),
    (range(8, 11), "celesta"), ([11], "vibes"),
    ([12, 13], "marimba"),
    ([14], "vibes"), ([15], "harp"),
    (range(16, 24), "organ"),
    ([24], "nylon"), ([25], "guitar"),
    (range(26, 32), "guitar"),
    (range(32, 38), "bass"), (range(38, 40), "synbass"),
    (range(40, 42), "strings"),
    ([42], "cello"), ([43], "contrabass"), ([44], "strings"),
    ([45], "pluck"), ([46], "harp"), ([47], "marimba"),
    (range(48, 52), "strings"),
    (range(52, 56), "choir"), (range(56, 64), "brass"),
    (range(64, 72), "woodwind"), (range(72, 76), "flute"),
    (range(76, 80), "woodwind"), (range(80, 88), "lead"),
    (range(88, 100), "pad"), (range(100, 104), "lead"),
    (range(104, 108), "guitar"),
    (range(108, 110), "celesta"), (range(110, 112), "vibes"),
    (range(112, 116), "marimba"), (range(116, 120), "pluck"),
    (range(120, 128), "sfx"),
]:
    for _p in _r:
        PROGRAM_MAP[_p] = _n


# ── KS/additive crossover threshold (not per-instrument) ────────────
# Read by synth/__init__.py to decide whether a note of duration `dur`
# uses the KS engine (short plucks), the additive engine (long sustains),
# or a crossfade blend between them (near the threshold). Not legacy —
# removing this would break the dispatcher.
KS_DUR_THRESHOLD: float = 0.8