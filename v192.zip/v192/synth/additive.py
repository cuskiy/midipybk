"""Additive synthesis with inline spectral envelope.

Refactored from a 280-line monolith into focused helpers:
  _compute_partials   - parameter setup, partial list construction
  _render_partials    - the harmonic loop (hot path; reuses scratch buffers)
  _apply_phantom      - combination tones for inharmonic instruments
  _apply_detune       - sympathetic detune partials
  _apply_subs         - sub-octave / sub-third oscillators
  _apply_nonlinear    - oversampled saturation stage (skipped when subtle)
  synthesize          - top-level orchestrator

Per-partial decay buffer (`he`) is now allocated once and reused via
in-place ops to avoid millions of n-sized allocations.
"""
from __future__ import annotations

import math
from typing import List, NamedTuple, Optional, Tuple

import numpy as np
from scipy.signal import sosfilt, resample_poly

from config import (ADDITIVE_PARTIAL_THRESHOLD, ADDITIVE_NID_PHASE_OFFSET,
                    ADDITIVE_NYQUIST_FADE_RATIO)
from .dsp import BoundedCache
from .timbre import (SR, MAX_DET, TUNE, Timbre, pr, lf, vc, strings_for_freq,
                     detune_scale, csv_parse, get_bp, biquad_peak)
from .envelope import envelope


class _PartialData(NamedTuple):
    k: int
    am: float
    fk: float
    a: float
    R: float
    phi: float


_SE_CACHE = BoundedCache(64, name="additive.formants")
_PEAK_CACHE = BoundedCache(64, name="additive.peak_filt")


# ── Formant helpers ──────────────────────────────────────────────────

def _parse_formants(tim: Timbre) -> list:
    key = (tim.formant_freqs, tim.formant_gains, tim.formant_qs)
    if key in _SE_CACHE:
        return _SE_CACHE[key]
    freqs, gains, qs = csv_parse(tim.formant_freqs), csv_parse(tim.formant_gains), csv_parse(tim.formant_qs)
    result = []
    for i, fc in enumerate(freqs):
        g = gains[i] if i < len(gains) else 0.3
        q = qs[i] if i < len(qs) else 2.0
        bw = fc / (2 * max(q, 0.3))
        g_lin = 10 ** (g * 24.0 / 20.0) - 1.0
        result.append((fc, bw, g_lin))
    _SE_CACHE[key] = result
    return result


def _spectral_gain(f, formants):
    g = 1.0
    for fc, bw, g_lin in formants:
        g += g_lin / (1.0 + ((f - fc) / bw) ** 2)
    return g


def _get_peak_filters(tim: Timbre) -> list:
    key = (tim.formant_freqs, tim.formant_gains, tim.formant_qs)
    if key in _PEAK_CACHE:
        return _PEAK_CACHE[key]
    freqs, gains, qs = csv_parse(tim.formant_freqs), csv_parse(tim.formant_gains), csv_parse(tim.formant_qs)
    filters = []
    for i, f in enumerate(freqs):
        g = gains[i] if i < len(gains) else 0.3
        q = qs[i] if i < len(qs) else 2.0
        sos = biquad_peak(f, g * 24.0, q)
        if sos is not None:
            filters.append(sos)
    _PEAK_CACHE[key] = filters
    return filters


def _apply_formants(w: np.ndarray, tim: Timbre, freq: float = 0) -> np.ndarray:
    """Post-synthesis EQ formants for KS/FM engines.

    No RMS normalization: formant coloring is intentional and should
    change the spectral balance. Per-note peak_cap and per-track RMS
    normalization in mix/track_render.py handle overall level.
    Previous RMS normalization undid the formant effect when the boost
    frequency aligned with the fundamental (harp, nylon).
    """
    filters = _get_peak_filters(tim)
    if not filters:
        return w
    out = w.copy()
    for sos in filters:
        out = sosfilt(sos, out)
    return out


def _brass_shape(w: np.ndarray, vel: float, tim: Timbre) -> np.ndarray:
    if tim.lip_shape <= 0:
        return w
    amount = tim.lip_shape * vel ** 1.5
    if amount < 0.01:
        return w
    gain = 1 + amount * 4
    shaped = np.tanh(w * gain)
    td = np.tanh(gain)
    if td > 1e-6:
        shaped /= td
    return (1 - amount * 0.5) * w + amount * 0.5 * shaped


# ── Partial computation ──────────────────────────────────────────────

def _compute_partials(freq: float, vel_curve: float, tim: Timbre,
                      formants: list, rng: np.random.RandomState
                      ) -> Tuple[List[_PartialData], int, float]:
    """Build the partial list for one note. Returns (partials, n_partials, B)."""
    eb = tim.eff_bright(vel_curve)
    fc = tim.eff_fc(vel_curve)
    fc_al = tim.fc_alpha
    _l = lf(freq)
    n_partials = tim.n + int(tim.n_extra * _l)
    B = (tim.inh * math.exp(tim.inh_stretch * pr(freq)) if tim.inh > 0 and tim.inh_stretch > 0
         else tim.inh * (1 + 3 * _l) if tim.inh > 0 else 0.0)
    pscale = (freq / 261.63) ** tim.decay_exp if tim.decay_exp > 0 else 1.0
    ha = tim.get_harm_amps()

    eff_strike = tim.strike_pos
    if eff_strike > 0.25 and freq > 300:
        t = min((freq - 300) / 700, 1.0)
        eff_strike = eff_strike * (1 - t) + 0.12 * t
    if fc > 0 and freq > 400:
        fc *= 1.0 + min((freq - 400) / 1000, 1.5) * 0.6

    nyq = SR * 0.5
    nyq_lo = nyq * ADDITIVE_NYQUIST_FADE_RATIO
    nyq_rng = nyq - nyq_lo

    pdata: List[_PartialData] = []
    for k in range(1, n_partials + 1):
        am = k * math.sqrt(1 + B * k * k) if B > 0 else float(k)
        fk = freq * am
        if fk >= nyq:
            break
        a = ha[k - 1] if ha and k <= len(ha) else (1 / k ** tim.rolloff) * math.exp(-eb * (k - 1))
        if ha and k <= len(ha) and tim.vel_bright > 0:
            a *= math.exp(-tim.vel_bright * (1 - vel_curve) * (k - 1) * 0.1)
        if tim.even_atten > 0 and k % 2 == 0:
            a *= 1 - tim.even_atten
        if fc > 0:
            a *= math.exp(-(fk / fc) ** fc_al)
        if fk > nyq_lo:
            a *= 0.5 * (1 + math.cos(math.pi * (fk - nyq_lo) / nyq_rng))
        if eff_strike > 0:
            pos = math.sin(k * math.pi * eff_strike)
            a *= 1 - tim.strike_depth * (1 - max(abs(pos), 0.15))
            phi = math.pi if pos < 0 else 0.0
        else:
            # No hammer/strike → bowed/blown/sustained excitation has
            # continuous noise drive, so each partial's phase is
            # independent in the real instrument. Phase-coherent
            # partials sum into a periodic pulse train at the
            # fundamental period — at sub-bass that's perceived as a
            # motorcycle engine. Random per-partial phase makes the
            # time-domain waveform smooth without changing RMS or
            # spectrum. Applies to strings, brass, woodwinds, voice,
            # organ, synth pads, leads, etc.
            phi = rng.random() * 2 * math.pi
        if formants:
            a *= _spectral_gain(fk, formants)
        # Body radiation efficiency: soundboards/bodies can't radiate
        # efficiently below their first plate mode. Partials below
        # body_lf are attenuated with a gentle curve. The fundamental
        # of a low piano note (55Hz) is physically produced by the
        # string but the board barely radiates it — the 2nd-4th
        # harmonics carry the perceived pitch instead.
        if tim.body_lf > 0 and fk < tim.body_lf:
            a *= max(0.15, (fk / tim.body_lf) ** 2)
        if a < ADDITIVE_PARTIAL_THRESHOLD:
            continue
        a *= 1 + 0.03 * (rng.random() - 0.5)
        R = tim.b1 * max(k - 1, 0.05) + tim.b2 * k ** 1.5 + tim.b3 * k * k
        R *= pscale * (1 + 0.05 * (rng.random() - 0.5))
        pdata.append(_PartialData(k, am, fk, a, R, phi))
    return pdata, n_partials, B


def _render_partials(pdata: List[_PartialData], n_partials: int,
                     ph_strings: list, n_str: int, freq: float,
                     tune_tab: list, tv: np.ndarray, n: int, noff: int,
                     tim: Timbre, mod_slow: np.ndarray, mod_mid: np.ndarray,
                     mod_fast: np.ndarray, sf_mod: Optional[np.ndarray],
                     rd_tail: Optional[np.ndarray], coup_env: Optional[np.ndarray],
                     rng: np.random.RandomState) -> np.ndarray:
    """Hot path: sum all partials with reused scratch buffers.

    v160 #15-perf investigation: a batched (K, n) outer-product form
    was tried but LOST vs the sequential loop at realistic (K≈14,
    n≈90k) sizes because the envelope matrix allocation thrashes L2
    cache. The sequential loop with per-partial scratch buffers is
    the faster choice for this problem size. The note is kept here
    as a signpost for future performance work: if you rewrite this,
    benchmark against strings.mid / pad.mid / piano.mid end-to-end,
    not synthetic micro-benchmarks.
    """
    micro = tim.micro
    lf_sc = max(1 - 0.35 * lf(freq), 0.1)
    he = np.empty(n)
    sin_scratch = np.empty(n)
    rd_buf = np.empty(n - noff) if rd_tail is not None else None
    w = np.zeros(n)
    # Reuse the primary string's phase array by reference
    ph0 = ph_strings[0]

    for (k, am, fk, a, R, phi) in pdata:
        # he = exp(-R * tv) — in place
        np.multiply(tv, -R, out=he)
        np.exp(he, out=he)
        if coup_env is not None:
            np.multiply(he, coup_env, out=he)
        if sf_mod is not None:
            kn = (k - 1) / max(n_partials - 1, 1)
            he *= 1 + sf_mod * kn
        if rd_tail is not None and k > 1 and rd_buf is not None:
            np.multiply(rd_tail, -k * tim.rel_damp, out=rd_buf)
            np.exp(rd_buf, out=rd_buf)
            he[noff:] *= rd_buf

        if micro > 0.01 and a > 0.02 and k <= 10:
            shared = max(1.0 - (k - 1) * 0.12, 0.2)
            kf = min(k / 5, 1.0)
            d_s = micro * (0.25 + 0.15 * kf) * lf_sc
            d_i = micro * (0.08 + 0.03 * kf) * lf_sc
            jitter = d_s * (0.7 * mod_slow + 0.3 * mod_mid) + d_i * rng.randn() * mod_fast
            ad = micro * (0.02 + 0.015 * min(k / 6, 1.0)) * lf_sc
            am_mod = 1 + ad * (shared * mod_mid + (1 - shared) * mod_fast)
        else:
            jitter, am_mod = 0.0, 1.0

        # Primary string phase + sin into sin_scratch (no fresh alloc)
        if isinstance(jitter, float):
            # No jitter: phase = ph0*am + phi. Use in-place ops.
            np.multiply(ph0, am, out=sin_scratch)
            sin_scratch += phi
        else:
            # Jitter: vector add required; can't avoid temp on this path
            np.multiply(ph0, am, out=sin_scratch)
            sin_scratch += phi
            sin_scratch += jitter
        np.sin(sin_scratch, out=sin_scratch)
        for si in range(1, n_str):
            if freq * tune_tab[si] * am < SR / 2:
                sin_scratch += np.sin(ph_strings[si] * am + phi + jitter)
        if not isinstance(am_mod, float):
            sin_scratch *= am_mod
        sin_scratch *= he
        # w += a * sin_scratch, fused
        w += a * sin_scratch
    return w


def _apply_phantom(w: np.ndarray, pdata: list, tim: Timbre, B: float,
                   tv: np.ndarray, rng: np.random.RandomState) -> None:
    if tim.phantom <= 0 or B <= 0 or len(pdata) < 2:
        return
    pt = tim.phantom
    for i in range(len(pdata)):
        km, _, fk_m, a_m, R_m, _ = pdata[i]
        if a_m < 0.005:
            continue
        for j in range(i + 1, len(pdata)):
            kn, _, fk_n, a_n, R_n, _ = pdata[j]
            if km + kn > 8:
                break
            if pt * a_m * a_n < 0.0005:
                continue
            fp = fk_m + fk_n
            if fp >= SR / 2:
                continue
            s = pt * a_m * a_n * np.sin(2 * np.pi * fp * tv + rng.random() * 6.28)
            if R_m + R_n > 0.005:
                s *= np.exp(-(R_m + R_n) * tv)
            w += s


def _apply_detune(w: np.ndarray, pdata: list, tim: Timbre, freq: float,
                  tv: np.ndarray, n: int, noff: int,
                  rng: np.random.RandomState) -> None:
    if tim.det_c <= 0 or tim.det_m <= 0 or not pdata:
        return
    _l = lf(freq)
    ec = tim.det_c * (1 + _l)
    em = tim.det_m * (1 + 0.6 * _l)
    dr = 2 ** (ec / 1200)
    det_decay = np.exp(-tim.b1 * tv)
    if noff < n:
        det_decay[noff:] *= np.exp(-8.0 * np.arange(n - noff, dtype=np.float64) / SR)
    for r in (dr, 1 / dr):
        dp = 2 * np.pi * freq * r * tv
        for mk, am_k, _, amp, R, _ in pdata[:MAX_DET]:
            if freq * r * am_k >= SR / 2:
                break
            s = np.sin(dp * am_k + rng.random() * 6.28) * det_decay
            if R > 0.005:
                s *= np.exp(-R * tv)
            w += em * 0.5 * amp * s


def _apply_subs(w: np.ndarray, tim: Timbre, freq: float, tv: np.ndarray) -> None:
    if tim.sub > 0 and freq / 2 > 20:
        sub_sc = max(1.0 - max(freq - 300, 0) / 500, 0.0)
        if sub_sc > 0.01:
            sub_s = tim.sub * sub_sc * np.sin(2 * np.pi * (freq / 2) * tv)
            if tim.d2 < 10:
                sub_s *= np.exp(-2.5 * tv)
            w += sub_s
    if tim.sub_third > 0 and freq * 1.5 < SR / 2:
        sub3_sc = max(1.0 - max(freq - 400, 0) / 600, 0.0)
        if sub3_sc > 0.01:
            st = tim.sub_third * sub3_sc * np.sin(2 * np.pi * (freq * 1.5) * tv)
            if tim.d2 < 10:
                st *= np.exp(-2.5 * tv)
            w += st


def _apply_nonlinear(w: np.ndarray, vel_curve: float, dur: float,
                     tim: Timbre) -> np.ndarray:
    """Brass shape + tanh saturation. Oversampled 2× to keep sidebands
    below Nyquist; DC removal afterwards (asymmetric saturation introduces
    a small offset).

    v162 perf fix: skip when effective drive < 0.05 — the tanh is
    essentially linear there and resample_poly costs ~50 ms per note
    for zero audible benefit.
    """
    has_lip = tim.lip_shape > 0 and vel_curve > 0.01
    has_drive = tim.drive >= 0.05
    if not (has_lip or has_drive):
        return w

    n_orig = len(w)
    w = resample_poly(w, 2, 1)
    w = _brass_shape(w, vel_curve, tim)
    if has_drive:
        d = tim.drive * (1 + 0.3 * vel_curve) * (min(dur / 0.2, 1) if dur < 0.2 else 1)
        td_v = np.tanh(d)
        if td_v > 1e-6:
            w = np.tanh(w * d) / td_v
    w = resample_poly(w, 1, 2)[:n_orig]
    w -= np.mean(w)
    return w


# ── Top-level orchestrator ───────────────────────────────────────────

def synthesize(freq: float, dur: float, vel: float, tim: Timbre,
               name: str = "default", nid: int = 0,
               pb_curve: Optional[np.ndarray] = None) -> np.ndarray:
    """Render one note via additive synthesis.

    Args:
        pb_curve: pitch-bend curve in semitones, one element per audio sample
                  (cents = pb_curve * 100). May be None.
    """
    # v160 #22 note: the static tail estimate `tim.rel * 1.2 + 0.15` is
    # already tight (capped at 2.5 s). A dynamic "-60 dB truncation"
    # would require computing the envelope before the partial loop
    # which is a chicken/egg; the existing bound already amortizes the
    # tail cost across what any audible content would need. Profiling
    # shows the partial loop consumes the full [0, n) range only when
    # tim.rel is the actual audible release — which is desired.
    tail = min(tim.rel * 1.2 + 0.15, 2.5) if dur >= 0.2 else min(tim.rel + 0.20, 1.0)
    td = dur + tail
    n = int(SR * td)
    if n == 0:
        return np.zeros(0)
    tv = np.linspace(0, td, n, endpoint=False)
    v = vc(vel)
    short = dur < 0.2
    rng = np.random.RandomState((int(freq * 100 + vel * 1000) + nid * 7919) % (2**31))
    noff = int(SR * dur)
    formants = _parse_formants(tim)

    # v188: formants are ALWAYS applied post-synthesis via IIR biquad,
    # never during partial computation. This unifies the formant path
    # across all engines (additive/KS/FM all use _apply_formants).
    # Previously, additive used _spectral_gain in _compute_partials
    # (Lorentzian per-partial scaling) while KS/FM used biquad IIR —
    # the two gave different results for the same formant parameters,
    # making cross-engine tuning inconsistent.
    synth_formants = []  # never pass to _compute_partials
    has_formants = bool(formants) and bool(tim.formant_freqs)

    pdata, n_partials, B = _compute_partials(freq, v, tim, synth_formants, rng)

    # Vibrato + pitch bend (semitones → cents)
    pitch_mod = None
    if tim.vib_d > 0:
        ve = np.clip((tv - tim.vib_del) / 0.2, 0, 1)
        pitch_mod = ve * tim.vib_d * np.sin(2 * np.pi * tim.vib_r * tv)
    if pb_curve is not None:
        if len(pb_curve) >= n:
            pb_cents = pb_curve[:n] * 100.0
        else:
            pb_cents = np.pad(pb_curve, (0, n - len(pb_curve)), mode='edge') * 100.0
        pitch_mod = (pitch_mod + pb_cents) if pitch_mod is not None else pb_cents

    n_str = strings_for_freq(freq, tim.n_strings)
    tune_tab = TUNE.get(n_str, TUNE[1])
    n_str = min(n_str, len(tune_tab))
    ds = detune_scale(freq)

    mod_slow = np.sin(2 * np.pi * (0.5 + rng.random() * 2.0) * tv + rng.random() * 6.283)
    mod_mid = np.sin(2 * np.pi * (2.5 + rng.random() * 3.5) * tv + rng.random() * 6.283)
    mod_fast = np.sin(2 * np.pi * (5.0 + rng.random() * 4.0) * tv + rng.random() * 6.283)

    body_mod = np.ones(n)
    if tim.bow_noise > 0:
        onset = np.clip(tv / 0.08, 0, 1)
        body_mod += tim.bow_noise * vel * onset * (0.6 * mod_mid + 0.4 * mod_fast)
    if tim.breath_noise > 0:
        onset = np.clip(tv / 0.05, 0, 1)
        bp_lo = max(freq * 4, 400)
        bp_hi = min(freq * 12, SR * 0.45)
        bp = get_bp(bp_lo, bp_hi) if n > 256 and bp_hi > bp_lo + 100 else None
        breath = sosfilt(bp, rng.randn(n)) * 0.3 if bp is not None else rng.randn(n) * 0.15
        pitch_scale = min(1.0, max(0.15, (freq - 180) / 320))
        body_mod += tim.breath_noise * pitch_scale * vel * onset * breath

    if not pdata:
        return np.zeros(n)

    # v187: compute ref from actual partial amplitudes in pdata, which
    # already include all frequency-dependent effects (body_lf, fc_base,
    # strike_pos). v188: formants removed from partials (unified path),
    # so pdata no longer includes formant scaling — formants are applied
    # post-synthesis via IIR for all engines consistently.
    ref = sum(p.a for p in pdata)
    # Add expected sub contribution at this frequency
    if tim.sub > 0 and freq / 2 > 20:
        ref += tim.sub * max(1.0 - max(freq - 300, 0) / 500, 0.0)
    if tim.sub_third > 0 and freq * 1.5 < SR / 2:
        ref += tim.sub_third * max(1.0 - max(freq - 400, 0) / 600, 0.0)
    # Headroom for non-partial contributions
    if tim.phantom > 0:
        ref *= 1.0 + 12.0 * tim.phantom
    if tim.coupling > 0 and tim.n_strings > 1:
        ref *= 1.0 + 0.30 * tim.coupling
    if tim.micro > 0.10:
        ref *= 1.0 + 0.25 * tim.micro
    if tim.drive > 0.05:
        ref *= 1.0 + 0.5 * tim.drive

    ph_nid = nid * ADDITIVE_NID_PHASE_OFFSET
    ph_strings = []
    for si in range(n_str):
        dt = 1.0 + (tune_tab[si] - 1.0) * ds
        fr = freq * dt
        if pitch_mod is not None:
            ph_strings.append(2 * np.pi * np.cumsum(fr * 2 ** (pitch_mod / 1200.0)) / SR + ph_nid)
        else:
            ph_strings.append(2 * np.pi * fr * tv + ph_nid)

    sf_mod = tim.spec_b * v * np.exp(-tv / max(tim.spec_tau, 0.001)) if tim.spec_b > 0 else None
    rd_tail = np.arange(max(n - noff, 0), dtype=np.float64) / SR if tim.rel_damp > 0 and noff < n else None
    coup = tim.coupling * (((freq / 261.63) ** tim.decay_exp) ** 0.3 if tim.decay_exp > 0 else 1.0) if tim.coupling > 0 else 0
    coup_env = None
    if coup > 0 and n_str > 1:
        ff = 1.0 / n_str
        coup_env = ff * np.exp(-(n_str - 1) * coup * tv) + (1.0 - ff)

    w = _render_partials(pdata, n_partials, ph_strings, n_str, freq, tune_tab,
                         tv, n, noff, tim, mod_slow, mod_mid, mod_fast,
                         sf_mod, rd_tail, coup_env, rng)

    if n_str > 1:
        w /= math.sqrt(n_str)

    _apply_phantom(w, pdata, tim, B, tv, rng)
    _apply_detune(w, pdata, tim, freq, tv, n, noff, rng)
    _apply_subs(w, tim, freq, tv)

    if tim.tw_leak > 0:
        for semi_off in [-1, 1]:
            lf_ = freq * 2 ** (semi_off / 12.0)
            if 20 < lf_ < SR / 2:
                w += tim.tw_leak * np.sin(2 * np.pi * lf_ * tv + rng.random() * 6.28)

    if tim.noise > 0:
        nl = tim.noise * (1 + tim.vn * v) * (1 + tim.noise_hi * pr(freq) - 0.3 * lf(freq))
        if short:
            nl *= max(dur / 0.2, 0.2)
        ns = rng.randn(n)
        bp_lo = max(freq * 1.5, 120) if tim.noise_d < 10 else max(freq * 0.5, 80)
        bp = get_bp(bp_lo, min(freq * tim.noise_peak * (1 + 0.3 * v), SR * 0.45)) if n > 512 else None
        if bp is not None:
            ns = sosfilt(bp, ns)
        w += nl * ns * np.exp(-tim.noise_d * (1 + 0.3 * lf(freq)) * tv)

    if ref > 0:
        w /= ref

    # Post-synthesis formant coloring (unified path for all cases)
    if has_formants:
        w_colored = _apply_formants(w, tim, freq)
        if tim.formant_decay > 0:
            # Formant fades: full coloring at t=0, flat by t=formant_decay
            f_env = np.exp(-tv[:len(w)] / tim.formant_decay)
            w = w + (w_colored - w) * f_env
        else:
            w = w_colored

    w = _apply_nonlinear(w, v, dur, tim)

    if tim.trem_d > 0:
        w *= 1 - tim.trem_d * 0.5 * (1 + np.sin(2 * np.pi * tim.trem_r * tv))

    w *= body_mod

    env_out = envelope(tim, dur, n, vel, freq, noff)
    out = w * env_out * (0.15 + 0.85 * v)

    if tim.key_click > 0:
        cn = min(int(SR * 0.003), n)
        if cn > 0:
            out[:cn] += tim.key_click * v * rng.randn(cn) * np.exp(-np.arange(cn) * 8.0 / cn)

    if short:
        fade = min(int(SR * 0.004), n)
        if fade > 1:
            out[:fade] *= np.linspace(0, 1, fade) ** 0.5

    # Trailing cosine taper (5 ms): prevents clicks when this note's tail
    # abuts the next note's attack. Applied after the nonlinear stage so
    # any saturation discontinuity is also smoothed out.
    tail_n = min(int(SR * 0.005), n)
    if tail_n > 1:
        out[-tail_n:] *= 0.5 * (1 + np.cos(np.linspace(0, np.pi, tail_n)))
    return out