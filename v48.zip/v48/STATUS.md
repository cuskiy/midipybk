# v48

## Changes from v46

### Mix clarity
- **Per-instrument HP filtering**: frequency-appropriate HP per instrument (strings 120Hz, woodwind 110Hz, flute 180Hz, guitar 55Hz, bass/drums 30Hz, piano 22Hz, etc.) — clears low-mid mud while preserving fundamentals (max -1.5dB at lowest note)
- **Drum level**: VOLUME 0.55→0.78 (was 52% quieter than piano, now -3.4dB relative)
- **Master HP**: 20Hz/order-3 on stereo bus after per-track HP

### Spectral quality
- **Piano**: b1 0.25→0.18, b3 0.04→0.03, fc_base 4000→5000, fc_alpha 2.0→1.5, bright_lo 0.48→0.35, spec_tau 60→120ms, decay_exp 1.0→0.65
- **E-piano**: b1 0.65→0.40, spec_tau 30→60ms
- **Guitar**: b1 0.65→0.42, fc_alpha 2.0→1.6, fc_base 4000→4500
- **Nylon**: bright_lo 0.75→0.62, b1 0.45→0.40

### KS/additive crossover
- Calibrated per-instrument gain for additive path (was 3-7dB cliff)
- Equal-power crossfade, zone widened to 0.30s

### Engine
- track_peak_cap 0.85→2.5
- Buffer tail uses actual synth formula
- Lazy reverb IR init
- HRTF center bypass at |az|<0.5°
- Fixed docstring version
