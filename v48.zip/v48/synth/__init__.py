from .timbre import SR, A4
from .instruments import TIMBRES
from .gm import PROGRAM_MAP, PANNING, KS_PLUCKED, KS_DUR_THRESHOLD
from .additive import synthesize as _additive, _apply_formants
from .ks import synthesize_plucked as _ks_pluck
from .drums import drum
import numpy as np

_KS_BLEND_LO = KS_DUR_THRESHOLD - 0.20
_KS_BLEND_HI = KS_DUR_THRESHOLD + 0.10
_KS_CAL = {}


def _ks_gain(name, tim):
    """Per-instrument KS/additive RMS ratio, computed once."""
    if name in _KS_CAL:
        return _KS_CAL[name]
    ratios = []
    for midi in range(48, 85, 12):
        freq = A4 * 2 ** ((midi - 69) / 12.0)
        for vel in [0.4, 0.7, 1.0]:
            ks = _ks_pluck(freq, 0.6, vel, tim, name, 0)
            if tim.formant_freqs:
                ks = _apply_formants(ks, tim)
            ad = _additive(freq, 0.6, vel, tim, name, 0)
            n = min(len(ks), len(ad))
            rk = np.sqrt(np.mean(ks[:n] ** 2)) + 1e-10
            ra = np.sqrt(np.mean(ad[:n] ** 2)) + 1e-10
            ratios.append(rk / ra)
    _KS_CAL[name] = float(np.median(ratios))
    return _KS_CAL[name]


def synthesize(freq, dur, vel, tim, name="default", nid=0):
    if name in KS_PLUCKED:
        if dur < _KS_BLEND_LO:
            w = _ks_pluck(freq, dur, vel, tim, name, nid)
            if tim.formant_freqs:
                w = _apply_formants(w, tim)
            return w
        if dur <= _KS_BLEND_HI:
            w = _ks_pluck(freq, dur, vel, tim, name, nid)
            if tim.formant_freqs:
                w = _apply_formants(w, tim)
            w_add = _additive(freq, dur, vel, tim, name, nid)
            n = min(len(w), len(w_add))
            rms_ks = np.sqrt(np.mean(w[:n] ** 2)) + 1e-10
            rms_add = np.sqrt(np.mean(w_add[:n] ** 2)) + 1e-10
            w_add *= rms_ks / rms_add
            blend = (dur - _KS_BLEND_LO) / (_KS_BLEND_HI - _KS_BLEND_LO)
            out = np.zeros(max(len(w), len(w_add)))
            out[:len(w)] += np.sqrt(1 - blend) * w
            out[:len(w_add)] += np.sqrt(blend) * w_add
            return out
        # Pure additive for KS instruments — apply calibrated gain
        w = _additive(freq, dur, vel, tim, name, nid)
        w *= _ks_gain(name, tim)
        return w
    return _additive(freq, dur, vel, tim, name, nid)
