import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt
from synth.timbre import SR

HEAD_R = 0.0875
C_SOUND = 343.0

def apply_hrtf(mono, az_deg, length=64):
    az = np.radians(az_deg)
    sa = abs(np.sin(az))
    itd = abs(HEAD_R/C_SOUND*(az+np.sin(az))) if sa > 1e-6 else 0
    gn, gf = 10**(abs(1.5*np.sin(az))/20), 10**(-abs(1.5*np.sin(az))/20)
    near, far = np.zeros(length), np.zeros(length)
    near[0] = 1.0
    ds = itd*SR; d0 = min(int(ds), length-2); frac = ds-d0
    far[d0] = 1-frac
    if d0+1 < length: far[d0+1] = frac
    fc = 8000-3500*sa
    if sa > 0.05 and fc < SR*0.45:
        far = sosfilt(butter(1, fc, btype='low', fs=SR, output='sos'), far)
    near *= gn; far *= gf
    li, ri = (far, near) if az_deg >= 0 else (near, far)
    nn = len(mono)
    return fftconvolve(mono, li, mode='full')[:nn], fftconvolve(mono, ri, mode='full')[:nn]
