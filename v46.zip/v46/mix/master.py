import numpy as np
from synth.timbre import SR

_H8 = np.array([[1.0]])
for _ in range(3): _H8 = np.block([[_H8, _H8], [_H8, -_H8]])
_H8 /= np.sqrt(8.0)

def fdn_reverb_ir(room_size=1.0, rt60=1.6, damping=0.3, dur=None):
    if dur is None: dur = min(rt60*1.5, 3.0)
    n = int(SR*dur)
    primes = [743,829,911,1013,1109,1213,1321,1429]
    delays = [max(int(p*room_size), 1) for p in primes]
    gains = np.array([10**(-3*d/(SR*max(rt60,0.1))) for d in delays])
    bufs = [np.zeros(d) for d in delays]
    ptrs, filt = [0]*8, np.zeros(8)
    ir_l, ir_r = np.zeros(n), np.zeros(n)
    out = np.zeros(8)
    ig = 1/np.sqrt(8)
    for i in range(n):
        for ch in range(8): out[ch] = bufs[ch][ptrs[ch]]
        mixed = _H8 @ out
        inp = ig if i == 0 else 0
        for ch in range(8):
            x = (1-damping)*mixed[ch] + damping*filt[ch] + inp
            filt[ch] = x
            bufs[ch][ptrs[ch]] = x*gains[ch]
            ptrs[ch] = (ptrs[ch]+1) % delays[ch]
        ir_l[i] = out[0]+out[2]+out[4]+out[6]
        ir_r[i] = out[1]+out[3]+out[5]+out[7]
    return ir_l, ir_r

def compress(l, r, thresh=0.55, ratio=2.0, att_ms=25, rel_ms=120):
    n = len(l)
    lk = np.maximum(np.abs(l), np.abs(r))
    ca = np.exp(-1/max(int(SR*att_ms/1000), 1))
    cr = np.exp(-1/max(int(SR*rel_ms/1000), 1))
    BLK = 64; nb = (n+BLK-1)//BLK
    env_blk = np.empty(nb); env_blk[0] = np.max(lk[:BLK])
    for i in range(1, nb):
        s, e = i*BLK, min(i*BLK+BLK, n)
        pk = np.max(lk[s:e])
        cb = (ca if pk > env_blk[i-1] else cr)**BLK
        env_blk[i] = cb*env_blk[i-1] + (1-cb)*pk
    env = np.repeat(env_blk, BLK)[:n]
    g = np.ones(n); m = env > thresh
    g[m] = (thresh + (env[m]-thresh)/ratio)/env[m]
    return l*g, r*g
