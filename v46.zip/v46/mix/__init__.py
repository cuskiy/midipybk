"""Render pipeline: synth → split-by-program → HP → normalize → HRTF → reverb → compress."""
import numpy as np
import soundfile as sf
from collections import defaultdict
from scipy.signal import fftconvolve, butter, sosfilt

from synth import SR, A4, TIMBRES, PROGRAM_MAP, PANNING
from synth.gm import VOLUME
from synth import synthesize, drum
from .spatial import apply_hrtf
from .master import fdn_reverb_ir, compress

PIPELINE = dict(
    hp_freq=20.0, hp_order=2, target_rms=0.15, track_peak_cap=0.85,
    reverb_wet=0.045, reverb_rt60=1.6, reverb_room=1.0,
    comp_thresh=0.55, comp_ratio=2.0, comp_att_ms=25, comp_rel_ms=120,
    peak_limit=0.92,
)

print("  generating reverb IR...", end="", flush=True)
_IRL, _IRR = fdn_reverb_ir(room_size=PIPELINE['reverb_room'], rt60=PIPELINE['reverb_rt60'])
_RV_HP = butter(2, 120.0, btype='high', fs=SR, output='sos')
_IRL, _IRR = sosfilt(_RV_HP, _IRL), sosfilt(_RV_HP, _IRR)
_rv_e = max(np.sqrt(np.sum(_IRL**2)), np.sqrt(np.sum(_IRR**2)), 1e-10)
_IRL /= _rv_e; _IRR /= _rv_e
print(" done")
_HP = butter(3, PIPELINE['hp_freq'], btype='high', fs=SR, output='sos')

def _split_tracks(tracks, pans):
    subs = []
    for ti, notes in enumerate(tracks):
        if not notes: continue
        pan_cc = pans[ti] if ti < len(pans) else None
        by_name = defaultdict(list)
        for note in notes:
            nm = "drums" if note[4] == 9 else PROGRAM_MAP.get(note[5], "default")
            by_name[nm].append(note)
        for nm, sub in by_name.items():
            subs.append((nm, sub, pan_cc))
    return subs

def render(tracks, track_pans, out_file):
    P = PIPELINE
    sub_tracks = _split_tracks(tracks, track_pans)
    mx = 0
    for nm, notes, _ in sub_tracks:
        tb = TIMBRES.get(nm, TIMBRES["default"])
        for st, note, dur, vel, ch, prog in notes:
            e = int((st + dur + min(tb.rel+0.35, 0.55))*SR) + SR
            if e > mx: mx = e
    mx += SR
    ml, mr = np.zeros(mx), np.zeros(mx)
    used_az = set()

    for ti, (tn, notes, pan_cc) in enumerate(sub_tracks):
        nn = len(notes)
        print(f"  [{ti+1}/{len(sub_tracks)}] {tn:<12s} {nn:>4d} notes", flush=True)
        buf = np.zeros(mx)
        drng = np.random.RandomState(42+ti)
        for ni, (st, note, dur, vel, ch, prog) in enumerate(notes):
            if ch == 9:
                tone = drum(note, dur, vel, drng)
            else:
                nm = PROGRAM_MAP.get(prog, "default")
                tb = TIMBRES.get(nm, TIMBRES["default"])
                tone = synthesize(A4*2**((note-69)/12.0), dur, vel, tb, nm, ni)
            s = int(st*SR)
            e = min(s+len(tone), mx)
            buf[s:e] += tone[:e-s]

        buf = sosfilt(_HP, buf)
        rms = np.sqrt(np.mean(buf*buf))
        if rms > 1e-6: buf *= P['target_rms']/rms
        vol = VOLUME.get(tn, 1.0)
        if vol != 1.0: buf *= vol
        pk = np.max(np.abs(buf))
        if pk > P['track_peak_cap']: buf *= P['track_peak_cap']/pk

        if pan_cc is not None:
            az = (pan_cc-64)/64.0*55.0
        elif tn == "drums":
            az = 0.0
        else:
            az = PANNING.get(tn, 0)
            if az in used_az:
                for off in [8,-8,16,-16]:
                    c = az+off
                    if abs(c) <= 60 and c not in used_az: az = c; break
            used_az.add(az)
        l, r = apply_hrtf(buf, np.clip(az, -65, 65))
        ml += l; mr += r

    if sub_tracks:
        wet = P['reverb_wet']; dry = 1-wet
        ml = ml*dry + fftconvolve(ml, _IRL, mode='full')[:mx]*wet
        mr = mr*dry + fftconvolve(mr, _IRR, mode='full')[:mx]*wet
        ml, mr = compress(ml, mr, P['comp_thresh'], P['comp_ratio'], P['comp_att_ms'], P['comp_rel_ms'])
        pk = max(np.max(np.abs(ml)), np.max(np.abs(mr)), 1e-10)
        ml *= P['peak_limit']/pk; mr *= P['peak_limit']/pk

    sf.write(out_file, np.clip(np.column_stack((ml, mr)), -1, 1), SR, format="FLAC", subtype="PCM_24")
    print(f"  {out_file}  ({mx/SR:.1f}s, {len(sub_tracks)} sub-tracks)")
