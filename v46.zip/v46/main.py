"""v33 MIDI synthesizer — entry point."""
import argparse, os


def main():
    p = argparse.ArgumentParser(description="Render MIDI to FLAC")
    p.add_argument("input", help="MIDI file path")
    p.add_argument("-o", "--output", help="output FLAC path")
    a = p.parse_args()
    print("v46")
    from midi import parse
    from mix import render
    tracks, pans = parse(a.input)
    out = a.output or os.path.splitext(a.input)[0] + ".flac"
    render(tracks, pans, out)


if __name__ == "__main__":
    main()
