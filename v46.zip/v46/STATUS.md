# v46

## Changes from v44

### Engine
- **Formant: peaking EQ biquads** replacing bandpass dry/wet mix (stronger timbral shaping)
- **Formants apply to KS output** (was additive-only; root cause of harp≈guitar)
- **KS excitation by pluck position** (triangle shape at strike_pos, not fixed half-sine)
- **New synthesis layers**: bow_noise, breath_noise, lip_shape, tw_leak
- **Release tail fix**: cap raised from 0.35s to rel*1.2+0.15 (pad was losing 1.17s)
- **Release rate adaptive**: 5/rel instead of hardcoded 15/s (pad/choir now fade naturally)
- **KS/Additive crossover**: RMS normalization (fixes 51% volume drop)
- **Velocity range**: 0.15+0.85v (was 0.25+0.75v, ~16dB vs ~7dB)
- **HRTF center fix**: skip head-shadow lowpass at small angles (was 50% L/R imbalance)

### Piano
- b1: 0.60→0.25, b3: 0.10→0.04 (upper partials ring 2.5x longer)
- spec_tau: 0.015→0.060 (brilliance 4x longer)
- coupling: 1.5→0.7, d1l: 0.30→0.42, phantom: 0.04→0.06

### All 21 instruments optimized
| Instrument | Key | Physics |
|---|---|---|
| piano | b1/b3 halved, shimmer extended | Two-stage decay |
| epiano | h2>h1, 200Hz body formant, spec_tau=30ms | Asymmetric tuning fork |
| harpsichord | 500+2200Hz formant, bright quill | Plucked string body |
| organ | tw_leak, key_click, drive | Tonewheel + tube |
| guitar | 480+2800Hz formant, ks_click=0.14 | Steel body + bridge |
| nylon | 350+1600Hz formant, ks_lp=0.35 | Classical warmth |
| bass | 120Hz cabinet formant, VOLUME=0.78 | Cabinet resonance |
| harp | strike_pos=0.42, 350+1200Hz formant | Center pluck + body |
| pluck | 2200+4500Hz resonant formant | Synth filter peak |
| strings | bow_noise=0.020, 450+2800Hz | Rosin friction |
| cello | bow_noise=0.030, 700+2200Hz, vib=4.2Hz | Schleske a-formant |
| brass | lip_shape=0.35, att=0.050 | Lip-reed nonlinearity |
| woodwind | even_atten=0.75, breath=0.022, att=0.030 | Closed bore odd harmonics |
| flute | n=4, breath=0.040 | Near-sinusoidal |
| choir | F1/F2/F3 peaking EQ, breath=0.012 | Vocal formants |
| lead | sawtooth, spec_b=0.50, drive=0.22 | Filter sweep |
| pad | vd=0, det_c=9.0, rel=1.4 | Thick chorus |
| celesta | inh=0.0006, b1=1.10 | Metal bar inharmonics |
| vibes | 1500+3500Hz formant, trem=0.15 | Metallic + motor |
| marimba | 800Hz tube formant, b1=2.0 | Wood bar decay |
| drums | Reduced cymbal metal levels | Balanced |

### Audit results (8/8 pass)
1. Audio health: no clipping, NaN, or silence ✓
2. Musical character: attack/sustain/decay match instrument type ✓
3. Release tails: match rel parameter (pad 1.4s works) ✓
4. HRTF: center balanced, lateralization correct ✓
5. Spectral balance: no muddy/harsh instruments ✓
6. Differentiation: no critical similarity (avg 0.275) ✓
7. Configuration: VOLUME/PANNING/CONDUCT rules ✓
8. Code: 1287 lines, 21 FLAC samples ✓
