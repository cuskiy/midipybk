import numpy as np
from scipy.signal import butter, sosfilt
from .timbre import SR, MAX_DET, TUNE, pr, lf, vc
from .envelope import envelope

_BP_CACHE = {}
_PEAK_CACHE = {}

def _csv(s):
    return [float(x) for x in s.split(",")] if s else []

def _get_bp(lo, hi):
    key = (int(lo/10)*10, int(hi/50)*50)
    if key not in _BP_CACHE:
        lo_c, hi_c = max(key[0], 20), min(key[1], int(SR*0.45))
        _BP_CACHE[key] = butter(2, [lo_c, hi_c], btype='band', fs=SR, output='sos') if hi_c > lo_c+50 else None
    return _BP_CACHE[key]

def _make_peak_sos(fc, gain_db, q):
    """Peaking EQ biquad: boost at fc with Q bandwidth."""
    fc = max(fc, 30.0)
    if fc >= SR * 0.45: return None
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * np.pi * fc / SR
    alpha = np.sin(w0) / (2 * max(q, 0.3))
    b0 = 1 + alpha * A; b1 = -2 * np.cos(w0); b2 = 1 - alpha * A
    a0 = 1 + alpha / A; a1 = -2 * np.cos(w0); a2 = 1 - alpha / A
    return np.array([[b0/a0, b1/a0, b2/a0, 1.0, a1/a0, a2/a0]])

def _get_peak_filters(tim):
    key = (tim.formant_freqs, tim.formant_gains, tim.formant_qs)
    if key in _PEAK_CACHE: return _PEAK_CACHE[key]
    freqs, gains, qs = _csv(tim.formant_freqs), _csv(tim.formant_gains), _csv(tim.formant_qs)
    filters = []
    for i, f in enumerate(freqs):
        g = gains[i] if i < len(gains) else 0.3
        q = qs[i] if i < len(qs) else 2.0
        sos = _make_peak_sos(f, g * 24.0, q)
        if sos is not None: filters.append(sos)
    _PEAK_CACHE[key] = filters
    return filters

def _apply_formants(w, tim):
    """Cascaded peaking EQ — shapes spectrum without dry/wet mixing."""
    filters = _get_peak_filters(tim)
    if not filters: return w
    out = w.copy()
    for sos in filters: out = sosfilt(sos, out)
    rms_in = np.sqrt(np.mean(w*w)) + 1e-10
    rms_out = np.sqrt(np.mean(out*out)) + 1e-10
    return out * (rms_in / rms_out)

def _bow_noise(n, freq, vel, tim, rng, tv):
    """Pitch-correlated rosin friction noise for bowed strings."""
    if tim.bow_noise <= 0: return 0.0
    ns = rng.randn(n)
    bp = _get_bp(max(freq*0.8, 80), min(freq*5.0, SR*0.45)) if n > 256 else None
    if bp is not None: ns = sosfilt(bp, ns)
    mod = 1 + 0.3*np.sin(2*np.pi*(2.5+rng.random()*3)*tv)
    env = np.clip(tv/0.08, 0, 1)
    return tim.bow_noise * vel * ns * mod * env

def _breath_mod(n, freq, vel, tim, rng, tv):
    """Breath-modulated turbulence noise for wind instruments."""
    if tim.breath_noise <= 0: return 0.0
    ns = rng.randn(n)
    bp = _get_bp(max(freq*1.5, 200), min(freq*12.0, SR*0.45)) if n > 256 else None
    if bp is not None: ns = sosfilt(bp, ns)
    flutter = 1 + 0.15*np.sin(2*np.pi*(4+rng.random()*4)*tv)
    env = np.clip(tv/0.05, 0, 1)
    return tim.breath_noise * vel * ns * flutter * env

def _brass_shape(w, vel, tim):
    """Lip-reed nonlinearity: low vel≈sine, high vel→squared waveform."""
    if tim.lip_shape <= 0: return w
    amount = tim.lip_shape * vel**1.5
    if amount < 0.01: return w
    gain = 1 + amount * 4
    shaped = np.tanh(w * gain)
    td = np.tanh(gain)
    if td > 1e-6: shaped /= td
    return (1 - amount*0.5) * w + amount*0.5 * shaped

def synthesize(freq, dur, vel, tim, name="default", nid=0):
    tail = min(tim.rel * 1.2 + 0.15, 2.5) if dur >= 0.2 else min(tim.rel + 0.20, 1.0)
    td = dur + tail
    n = int(SR * td)
    if n == 0: return np.zeros(0)
    tv = np.linspace(0, td, n, endpoint=False)
    v = vc(vel)
    short = dur < 0.2
    rng = np.random.RandomState((int(freq*100+vel*1000)+nid*7919) % (2**31))
    noff = int(SR * dur)
    _l = lf(freq)

    eb = tim.eff_bright(v)
    fc = tim.eff_fc(v)
    fc_al = tim.fc_alpha
    n_partials = tim.n + int(tim.n_extra * _l)
    B = (tim.inh * np.exp(tim.inh_stretch * pr(freq)) if tim.inh > 0 and tim.inh_stretch > 0
         else tim.inh * (1+3*_l) if tim.inh > 0 else 0.0)
    pscale = (freq/261.63)**tim.decay_exp if tim.decay_exp > 0 else 1.0
    ha = _csv(tim.harm_amps)

    vb = None
    if tim.vib_d > 0:
        ve = np.clip((tv-tim.vib_del)/0.2, 0, 1)
        vb = ve * tim.vib_d * np.sin(2*np.pi*tim.vib_r*tv)

    tune = TUNE.get(min(tim.n_strings, 3), TUNE[1])
    n_str = min(tim.n_strings, len(tune))
    w = np.zeros(n)

    pdata = []
    for k in range(1, n_partials+1):
        am = k * np.sqrt(1+B*k*k) if B > 0 else float(k)
        fk = freq * am
        if fk >= SR/2: break
        a = ha[k-1] if ha and k <= len(ha) else (1/k**tim.rolloff)*np.exp(-eb*(k-1))
        if tim.even_atten > 0 and k % 2 == 0: a *= 1-tim.even_atten
        if fc > 0: a *= np.exp(-(fk/fc)**fc_al)
        if tim.strike_pos > 0:
            pos = np.sin(k*np.pi*tim.strike_pos)
            a *= 1-tim.strike_depth*(1-max(abs(pos), 0.15))
            phi = np.pi if pos < 0 else 0.0
        else: phi = 0.0
        a *= 1+0.03*(rng.random()-0.5)
        R = tim.b1*max(k-1, 0.05) + tim.b3*k*k
        R *= pscale*(1+0.05*(rng.random()-0.5))
        pdata.append((k, am, fk, a, R, phi))

    ph_strings = []
    for si in range(n_str):
        fr = freq*tune[si]
        ph_strings.append(2*np.pi*np.cumsum(fr*2**(vb/1200.0))/SR if vb is not None else 2*np.pi*fr*tv)

    sf_base = np.exp(-tv/max(tim.spec_tau, 0.001)) if tim.spec_b > 0 else None
    sf_scale = tim.spec_b*v if tim.spec_b > 0 else 0
    rd_tail = np.arange(max(n-noff, 0), dtype=np.float64)/SR if tim.rel_damp > 0 and noff < n else None
    coup = tim.coupling*(pscale**0.3 if tim.decay_exp > 0 else 1.0) if tim.coupling > 0 else 0
    micro = tim.micro

    for (k, am, fk, a, R, phi) in pdata:
        if coup > 0 and n_str > 1:
            ff = 1/n_str
            he = ff*np.exp(-(R+(n_str-1)*coup)*tv) + (1-ff)*np.exp(-R*tv)
        elif R > 0.005: he = np.exp(-R*tv)
        else: he = None

        if sf_base is not None:
            kn = (k-1)/max(n_partials-1, 1)
            sf = 1+sf_scale*sf_base*kn
            he = he*sf if he is not None else sf

        if rd_tail is not None and k > 1:
            rd = np.exp(-k*tim.rel_damp*rd_tail)
            if he is not None: he[noff:] *= rd
            else: he = np.ones(n); he[noff:] = rd

        if micro > 0.01:
            kf = min(k/5, 1.0)
            r1, r2 = 0.3+rng.random()*1.5, 3+rng.random()*5
            d1m = micro*(0.30+0.20*kf)*(1+0.4*_l)
            d2m = micro*(0.08+0.04*kf)*(1+0.2*_l)
            jitter = d1m*np.sin(2*np.pi*r1*tv+rng.random()*6.283) + d2m*np.sin(2*np.pi*r2*tv+rng.random()*6.283)
            ad = micro*(0.03+0.025*min(k/6, 1.0))
            am_mod = 1+ad*np.sin(2*np.pi*(0.8+rng.random()*3.2)*tv+rng.random()*6.283)
        else: jitter, am_mod = 0.0, 1.0

        for si in range(n_str):
            if freq*tune[si]*am >= SR/2: continue
            s = np.sin(ph_strings[si]*am + phi + jitter) * am_mod
            if he is not None: s *= he
            w += a * s
    if n_str > 1: w /= np.sqrt(n_str)

    if tim.phantom > 0 and B > 0 and len(pdata) >= 2:
        for i in range(len(pdata)):
            km, _, fk_m, a_m, R_m, _ = pdata[i]
            for j in range(i+1, len(pdata)):
                kn, _, fk_n, a_n, R_n, _ = pdata[j]
                if km+kn > 8: break
                fp = fk_m+fk_n
                if fp >= SR/2: continue
                s = tim.phantom*a_m*a_n*np.sin(2*np.pi*fp*tv+rng.random()*6.28)
                if R_m+R_n > 0.005: s *= np.exp(-(R_m+R_n)*tv)
                w += s

    if tim.det_c > 0 and tim.det_m > 0 and pdata:
        ec = tim.det_c*(1+_l)
        em = tim.det_m*(1+0.6*_l)
        dr = 2**(ec/1200)
        for r in (dr, 1/dr):
            dp = 2*np.pi*freq*r*tv
            for mk, am_k, _, amp, R, _ in pdata[:MAX_DET]:
                if freq*r*am_k >= SR/2: break
                s = np.sin(dp*am_k + rng.random()*6.28)
                if R > 0.005: s *= np.exp(-R*tv)
                w += em*0.5*amp*s

    if tim.sub > 0 and freq/2 > 20:
        sub_s = tim.sub*np.sin(2*np.pi*(freq/2)*tv)
        if tim.d2 < 10: sub_s *= np.exp(-2.5*tv)
        w += sub_s
    if tim.sub_third > 0 and freq*1.5 < SR/2:
        st = tim.sub_third*np.sin(2*np.pi*(freq*1.5)*tv)
        if tim.d2 < 10: st *= np.exp(-2.5*tv)
        w += st

    # Tonewheel leakage
    if tim.tw_leak > 0:
        for semi_off in [-1, 1]:
            lf_ = freq * 2**(semi_off/12.0)
            if 20 < lf_ < SR/2:
                w += tim.tw_leak*np.sin(2*np.pi*lf_*tv + rng.random()*6.28)

    # Standard noise
    if tim.noise > 0:
        nl = tim.noise*(1+tim.vn*v)*((1+tim.noise_hi*pr(freq)) if tim.noise_hi > 0 else (1-0.4*_l))
        if short: nl *= max(dur/0.2, 0.2)
        ns = rng.randn(n)
        bp = _get_bp(max(freq*0.5, 80), min(freq*tim.noise_peak*(1+0.3*v), SR*0.45)) if n > 512 else None
        if bp is not None: ns = sosfilt(bp, ns)
        w += nl*ns*np.exp(-tim.noise_d*(1+0.5*_l)*tv)

    ref = tim.ref_amp()
    if ref > 0: w /= ref

    w = _brass_shape(w, v, tim)

    if tim.drive > 0:
        d = tim.drive*(1+0.3*v)*(min(dur/0.2, 1) if short else 1)
        td_v = np.tanh(d)
        if td_v > 1e-6: w = np.tanh(w*d)/td_v

    if tim.trem_d > 0:
        w *= 1-tim.trem_d*0.5*(1+np.sin(2*np.pi*tim.trem_r*tv))

    if tim.formant_freqs: w = _apply_formants(w, tim)

    env = envelope(tim, dur, n, vel, freq, noff)
    out = w * env * (0.15 + 0.85*v)

    if tim.key_click > 0:
        cn = min(int(SR*0.003), n)
        if cn > 0: out[:cn] += tim.key_click*v*rng.randn(cn)*np.exp(-np.arange(cn)*8.0/cn)

    if tim.bow_noise > 0:
        out += _bow_noise(n, freq, vel, tim, rng, tv) * env
    if tim.breath_noise > 0:
        out += _breath_mod(n, freq, vel, tim, rng, tv) * env

    if short:
        fade = min(int(SR*0.004), n)
        if fade > 1: out[:fade] *= np.linspace(0, 1, fade)**0.5
    return out
