from .timbre import SR, A4
from .instruments import TIMBRES
from .gm import PROGRAM_MAP, PANNING, KS_PLUCKED, KS_DUR_THRESHOLD
from .additive import synthesize as _additive, _apply_formants
from .ks import synthesize_plucked as _ks_pluck
from .drums import drum
import numpy as np


def synthesize(freq, dur, vel, tim, name="default", nid=0):
    if name in KS_PLUCKED and dur < KS_DUR_THRESHOLD:
        w = _ks_pluck(freq, dur, vel, tim, name, nid)
        # Apply formants to KS output — critical for differentiating plucked instruments
        if tim.formant_freqs:
            w = _apply_formants(w, tim)
        if dur > KS_DUR_THRESHOLD - 0.15:
            w_add = _additive(freq, dur, vel, tim, name, nid)
            n = min(len(w), len(w_add))
            rms_ks = np.sqrt(np.mean(w[:n]**2)) + 1e-10
            rms_add = np.sqrt(np.mean(w_add[:n]**2)) + 1e-10
            w_add *= rms_ks / rms_add
            blend = (dur - (KS_DUR_THRESHOLD - 0.15)) / 0.15
            out = np.zeros(max(len(w), len(w_add)))
            out[:len(w)] += (1 - blend) * w
            out[:len(w_add)] += blend * w_add
            return out
        return w
    return _additive(freq, dur, vel, tim, name, nid)
