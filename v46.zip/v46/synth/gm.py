PROGRAM_MAP = {}
for _r, _n in [
    (range(0, 6), "piano"), (range(6, 8), "harpsichord"),
    (range(8, 11), "celesta"), ([11], "vibes"), ([12, 13], "marimba"),
    (range(14, 16), "epiano"), (range(16, 24), "organ"),
    (range(24, 26), "nylon"), (range(26, 32), "guitar"),
    (range(32, 40), "bass"), (range(40, 42), "strings"),
    (range(42, 44), "cello"), (range(44, 46), "strings"),
    (range(46, 48), "harp"), (range(48, 52), "strings"),
    (range(52, 56), "choir"), (range(56, 64), "brass"),
    (range(64, 72), "woodwind"), (range(72, 76), "flute"),
    (range(76, 80), "woodwind"), (range(80, 88), "lead"),
    (range(88, 100), "pad"), (range(100, 104), "lead"),
    (range(104, 108), "guitar"),
    (range(108, 110), "celesta"), (range(110, 112), "vibes"),
    (range(112, 116), "marimba"), (range(116, 120), "pluck"),
    (range(120, 128), "default"),
]:
    for _p in _r:
        PROGRAM_MAP[_p] = _n

PANNING = {
    "piano": 0, "epiano": -12, "organ": 5, "harpsichord": -8,
    "guitar": -25, "nylon": -20, "bass": 0, "strings": 22, "cello": 15,
    "brass": 30, "woodwind": -22, "flute": -18, "choir": 0, "celesta": 12,
    "vibes": -16, "marimba": -12, "harp": 18, "pad": 0, "lead": 10,
    "pluck": -14, "default": 0, "drums": 0,
}

VOLUME = {
    "piano": 1.15, "epiano": 1.0, "organ": 1.0, "harpsichord": 1.0,
    "guitar": 1.0, "nylon": 1.0, "bass": 0.78, "strings": 1.0, "cello": 1.0,
    "brass": 1.0, "woodwind": 1.0, "flute": 1.0, "choir": 1.0, "celesta": 1.0,
    "vibes": 1.0, "marimba": 1.0, "harp": 1.0, "pad": 1.0, "lead": 1.0,
    "pluck": 1.0, "default": 1.0, "drums": 0.55,
}

KS_PLUCKED = {"guitar", "nylon", "harp", "harpsichord"}
KS_DUR_THRESHOLD = 0.8
