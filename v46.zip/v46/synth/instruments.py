from .timbre import Timbre

TIMBRES = {
    "piano": Timbre(
        # 3-string coupled oscillator. Two-stage decay: loud attack → quiet shimmer.
        # b1/b3 low: upper partials ring long for clarity. spec_tau=60ms for brilliance.
        n=14, rolloff=1.0, bright=0.28, bright_lo=0.48, bright_hi=0.18, hammer_hard=2.0,
        strike_pos=0.12, strike_depth=0.35, inh=0.00015, inh_stretch=3.0,
        b1=0.25, b3=0.04, rel_damp=3.5, coupling=0.7, phantom=0.06,
        att=0.003, d1=0.28, d1l=0.42, d2=0.9, d2s=3.5, pr=0.55, rel=0.35,
        va=0.6, vd=0.3, ps=0.25, pdm=1.8, n_strings=3,
        noise=0.010, noise_d=55.0, noise_peak=10.0, noise_hi=2.5, vn=0.8, live=0.012,
        spec_b=1.2, spec_tau=0.060, drive=0.08, n_extra=4,
        fc_base=4000.0, fc_min=0.35, hammer_p=2.5, fc_alpha=2.0, decay_exp=1.0,
        micro=1.0,
    ),
    "epiano": Timbre(
        # Rhodes asymmetric tuning fork: tine+tonebar. h2>h1 at on-axis pickup.
        # Bell-like transient from tonebar inharmonics. Pickup saturation at forte.
        # Body resonance ~200Hz from tone bar vibration.
        harm_amps="0.75,1.0,0.60,0.35,0.18,0.10,0.05,0.03",
        n=8, inh=0.00025, inh_stretch=2.8,
        b1=0.65, b3=0.10, rel_damp=3.0,
        att=0.002, d1=0.10, d1l=0.18, d2=2.8, d2s=5.5, pr=0.50, rel=0.30,
        va=0.55, vd=0.2, ps=0.05, pdm=1.2, n_strings=1,
        trem_r=4.8, trem_d=0.10,
        noise=0.004, noise_d=140.0, noise_peak=14.0, noise_hi=1.5, vn=0.2,
        spec_b=0.90, spec_tau=0.030, drive=0.22,
        fc_base=5000.0, fc_min=0.25, hammer_p=2.0, fc_alpha=1.5, decay_exp=0.7,
        formant_freqs="200", formant_gains="0.20", formant_qs="1.2",
        micro=1.0,
    ),
    "harpsichord": Timbre(
        # Plucked string with quill: very bright, sharp attack, fast decay.
        # Body resonance ~500Hz. More metallic than piano.
        n=12, rolloff=0.7, bright=0.15, vel_bright=0.12,
        strike_pos=0.15, strike_depth=0.30, inh=0.00004,
        b1=0.85, b3=0.14, rel_damp=5.5, coupling=0.8, phantom=0.03,
        att=0.001, d1=0.06, d1l=0.10, d2=1.5, rel=0.10,
        va=0.15, vn=0.6, ps=0.06, pdm=1.3, n_strings=2,
        noise=0.020, noise_d=160.0, noise_peak=15.0, noise_hi=1.2,
        spec_b=0.9, spec_tau=0.006, drive=0.08,
        fc_base=5500.0, fc_min=0.40, fc_alpha=2.0, decay_exp=0.6,
        formant_freqs="500,2200", formant_gains="0.18,0.10", formant_qs="1.5,1.2",
        micro=0.7, ks_lp=0.65, ks_click=0.22,
    ),
    "organ": Timbre(
        # Hammond B3 888000000: sub-octave + quint + fundamental.
        # Tonewheel leakage, key click, Leslie vibrato, tube preamp drive.
        harm_amps="1.0,0.06,0.03",
        n=3, sub=0.80, sub_third=0.80,
        att=0.001, d1=0.005, d1l=0.99, d2=80.0, rel=0.012,
        va=0.0, vd=0.0,
        vib_r=6.7, vib_d=4, vib_del=0.05,
        key_click=0.10, micro=0.0,
        tw_leak=0.08, drive=0.06,
    ),
    "guitar": Timbre(
        # Steel string acoustic: bright pick attack, body ~480Hz, bridge hill ~2800Hz.
        n=10, rolloff=1.0, bright=0.35, bright_lo=0.50, bright_hi=0.22, hammer_hard=1.8,
        strike_pos=0.14, strike_depth=0.30, inh=0.00003,
        b1=0.65, b3=0.10, phantom=0.03,
        att=0.001, d1=0.12, d1l=0.18, d2=2.5, d2s=5.0, pr=0.68, rel=0.20,
        va=0.5, vd=0.3, ps=0.10, pdm=1.5, det_c=0.6, det_m=0.03,
        noise=0.012, noise_d=100.0, noise_peak=8.0, noise_hi=1.0, vn=0.7,
        rel_damp=4.0, live=0.005, spec_b=0.5, spec_tau=0.020,
        drive=0.06, fc_base=4000.0, fc_min=0.30, fc_alpha=2.0, decay_exp=0.6,
        formant_freqs="480,2800", formant_gains="0.35,0.18", formant_qs="2.0,1.5",
        micro=0.6, ks_lp=0.58, ks_click=0.14,
    ),
    "nylon": Timbre(
        # Classical guitar: warm finger pluck, lower body formant, rounder.
        # Key diff from steel: much lower LP, no metal click, body ~350Hz.
        n=7, rolloff=1.5, bright=0.60, bright_lo=0.75, bright_hi=0.45, hammer_hard=1.0,
        strike_pos=0.20, strike_depth=0.15, b1=0.45, b3=0.05,
        att=0.004, d1=0.20, d1l=0.14, d2=1.6, d2s=3.0, pr=0.75, rel=0.25,
        va=0.30, vn=0.3, ps=0.05, pdm=1.2,
        noise=0.002, noise_d=40.0, noise_peak=4.0, noise_hi=0.2,
        rel_damp=2.5, spec_b=0.20, spec_tau=0.028,
        drive=0.02, fc_base=2500.0, fc_min=0.50, fc_alpha=2.5, decay_exp=0.35,
        formant_freqs="350,1600", formant_gains="0.40,0.15", formant_qs="1.8,1.2",
        micro=0.5, ks_lp=0.35, ks_click=0.02,
    ),
    "bass": Timbre(
        # Electric bass: strong fundamental, sub presence, cabinet resonance ~120Hz.
        n=6, rolloff=1.8, bright=0.55, strike_pos=0.50, strike_depth=0.35,
        b1=0.45, b3=0.08, sub=0.22,
        att=0.004, d1=0.05, d1l=0.48, d2=0.9, rel=0.08,
        va=0.30, vn=0.2, ps=0.12, pdm=1.2,
        noise=0.004, noise_d=50.0, noise_peak=3.5,
        drive=0.18, fc_base=1800.0, fc_min=0.50, fc_alpha=2.5,
        formant_freqs="120", formant_gains="0.25", formant_qs="1.0",
        micro=0.4,
    ),
    "harp": Timbre(
        # Pedal harp: center pluck → round, but harp sound is clear not muddy.
        # Formants at 350+1200Hz for body warmth + string clarity (not bass boost).
        n=10, rolloff=0.75, bright=0.20, vel_bright=0.15,
        strike_pos=0.42, strike_depth=0.35, inh=0.00003,
        b1=0.35, b3=0.05, phantom=0.08, coupling=0.6,
        att=0.002, d1=0.08, d1l=0.28, d2=4.5, d2s=9.0, pr=0.50, rel=0.55,
        va=0.40, vn=0.3, ps=0.08, pdm=1.5, det_c=0.4, det_m=0.015,
        noise=0.002, noise_d=50.0, noise_peak=5.0, noise_hi=0.3,
        rel_damp=2.0, spec_b=0.45, spec_tau=0.025,
        drive=0.02, fc_base=5500.0, fc_min=0.40, fc_alpha=1.8, decay_exp=0.45,
        formant_freqs="350,1200", formant_gains="0.25,0.20", formant_qs="1.5,1.2",
        micro=0.5, ks_lp=0.42, ks_click=0.03,
    ),
    "pluck": Timbre(
        # Synth pluck: snappy attack, resonant filter peak, detuning.
        n=10, rolloff=0.85, bright=0.20, vel_bright=0.20,
        strike_pos=0.20, strike_depth=0.30, b1=0.85, b3=0.14,
        att=0.001, d1=0.12, d1l=0.08, d2=2.0, d2s=4.5, pr=0.65, rel=0.22,
        va=0.45, vn=0.5, ps=0.06, pdm=1.3, det_c=1.5, det_m=0.05,
        noise=0.008, noise_d=120.0, noise_peak=9.0, noise_hi=0.8,
        rel_damp=3.5, spec_b=0.55, spec_tau=0.015, drive=0.10,
        fc_base=4500.0, fc_min=0.25, fc_alpha=1.8, decay_exp=0.5,
        formant_freqs="2200,4500", formant_gains="0.30,0.15", formant_qs="3.0,2.5",
        micro=0.5,
    ),
    "strings": Timbre(
        # Violin section: bow-locked harmonics, bridge hill ~2800Hz.
        # Rosin friction noise is the key bowed-string identifier.
        n=8, rolloff=1.0, bright=0.18, b1=0.03, b3=0.002,
        att=0.08, d1=0.10, d1l=0.75, d2=2.5, rel=0.25,
        va=0.3, vib_r=5.5, vib_d=5, vib_del=0.30,
        noise=0.002, noise_d=2.0,
        formant_freqs="450,2800", formant_gains="0.30,0.18", formant_qs="2.0,1.5",
        bow_noise=0.020, micro=0.0,
    ),
    "cello": Timbre(
        # Schleske: body ~170-250Hz, a-formant 600-900Hz, bridge 2200Hz.
        # Slower deeper vibrato than violin. Stronger bow noise. Richer harmonics.
        n=12, rolloff=0.80, bright=0.06, b1=0.018, b3=0.001,
        att=0.12, d1=0.14, d1l=0.70, d2=2.5, rel=0.35,
        va=0.20, vib_r=4.2, vib_d=7, vib_del=0.45,
        noise=0.005, noise_d=1.5,
        formant_freqs="700,2200", formant_gains="0.40,0.15", formant_qs="1.8,1.5",
        bow_noise=0.030, micro=0.0,
    ),
    "brass": Timbre(
        # Lip-reed: louder=brighter (nonlinear lip opening → waveshaping).
        # Backus formants F1=1300 F2=2500. Attack needs time for lip establishment.
        n=14, rolloff=0.35, bright=0.04, vel_bright=0.45,
        b1=0.06, b3=0.003,
        att=0.050, d1=0.06, d1l=0.72, d2=2.5, rel=0.14,
        va=0.35, det_c=0.5, det_m=0.015,
        vib_r=5.0, vib_d=5, vib_del=0.35,
        noise=0.008, noise_d=6.0, live=0.008,
        drive=0.06, spec_b=0.20, spec_tau=0.05,
        formant_freqs="1300,2500", formant_gains="0.35,0.15", formant_qs="1.8,1.5",
        lip_shape=0.35, breath_noise=0.008, micro=0.0,
    ),
    "woodwind": Timbre(
        # Closed cylindrical bore (clarinet): odd harmonics dominant.
        # even_atten=0.75 strongly suppresses even harmonics.
        # Reed chiff via breath_noise. Formant cutoff ~1500Hz.
        n=14, rolloff=0.55, bright=0.08, vel_bright=0.15, even_atten=0.75,
        b1=0.04, b3=0.002,
        att=0.030, d1=0.04, d1l=0.70, d2=2.5, rel=0.10,
        va=0.35, vn=0.5, vib_r=4.5, vib_d=5, vib_del=0.35,
        noise=0.010, noise_d=2.5, noise_peak=5.0, noise_hi=0.3,
        live=0.008, drive=0.04,
        formant_freqs="1500,2800", formant_gains="0.28,0.12", formant_qs="2.2,1.8",
        breath_noise=0.022, micro=0.0,
    ),
    "flute": Timbre(
        # Open cylindrical bore: nearly sinusoidal, heavy air noise.
        # Few harmonics (n=4). Strong breathy quality is the key identifier.
        n=4, rolloff=1.8, bright=0.06, vel_bright=0.08,
        b1=0.02, b3=0.001,
        att=0.035, d1=0.05, d1l=0.74, d2=3.0, rel=0.20,
        va=0.15, vn=0.7, vib_r=5.0, vib_d=5, vib_del=0.30,
        noise=0.008, noise_d=1.8, noise_peak=4.0, noise_hi=0.3, live=0.006,
        formant_freqs="800", formant_gains="0.20", formant_qs="2.0",
        fc_base=2200.0, fc_min=0.45, fc_alpha=2.0,
        breath_noise=0.040, micro=0.0,
    ),
    "choir": Timbre(
        # Vocal "aah": F1=700 F2=1100 F3=2600 (strong peaking EQ).
        # Ensemble detuning. Breath noise for air quality.
        n=8, rolloff=0.95, bright=0.12, b1=0.018, b3=0.001,
        att=0.16, d1=0.10, d1l=0.80, d2=2.5, rel=0.45,
        va=0.12, det_c=5.0, det_m=0.16, vib_r=5.5, vib_d=5, vib_del=0.50,
        noise=0.006, noise_d=1.5, live=0.010,
        formant_freqs="700,1100,2600", formant_gains="0.55,0.30,0.12", formant_qs="2.5,2.2,2.0",
        breath_noise=0.012, micro=0.0,
    ),
    "lead": Timbre(
        # Synth lead: sawtooth (1/k), filter sweep, drive for edge.
        # Stronger filter sweep (spec_b) for synth character.
        harm_amps="1.0,0.50,0.33,0.25,0.20,0.17,0.14,0.12,0.11,0.10",
        n=10, att=0.003, d1=0.05, d1l=0.62, d2=1.5, rel=0.10,
        va=0.55, det_c=4.5, det_m=0.14, vib_r=5.5, vib_d=7, vib_del=0.10,
        drive=0.22, spec_b=0.50, spec_tau=0.06,
        fc_base=4000.0, fc_min=0.30, fc_alpha=1.8,
        micro=0.15,
    ),
    "pad": Timbre(
        # Synth pad: extremely slow attack, thick chorus, long release.
        # vd=0 explicitly: sustained sound must not decay with velocity.
        n=6, rolloff=1.1, bright=0.22,
        att=0.45, d1=0.18, d1l=0.82, d2=25.0, rel=1.4,
        va=0.06, vd=0.0, det_c=9.0, det_m=0.25,
        vib_r=3.0, vib_d=3, vib_del=1.2,
        noise=0.003, noise_d=1.0, micro=0.0,
    ),
    "celesta": Timbre(
        # Steel bars struck by hammers: strong inharmonicity, bell-like shimmer.
        # Fast high-partial decay (b1=1.1) leaves ringing fundamental.
        n=8, rolloff=0.45, bright=0.12, bright_lo=0.22, bright_hi=0.06, hammer_hard=2.2,
        strike_pos=0.50, strike_depth=0.12, inh=0.0006, inh_stretch=3.0,
        b1=1.10, b3=0.22,
        att=0.001, d1=0.05, d1l=0.06, d2=2.5, d2s=5.0, pr=0.45, rel=0.40,
        va=0.25, noise=0.004, noise_d=180.0, noise_peak=14.0, noise_hi=2.0,
        rel_damp=3.5, spec_b=0.75, spec_tau=0.006, drive=0.02,
        fc_base=7500.0, fc_min=0.25, fc_alpha=1.6, decay_exp=1.0, micro=0.8,
    ),
    "vibes": Timbre(
        # Aluminum bars: motor tremolo, metallic resonance ~1500Hz, long sustain.
        n=8, rolloff=0.45, bright=0.06, bright_lo=0.12, bright_hi=0.04, hammer_hard=1.6,
        inh=0.0003, inh_stretch=2.0, b1=0.40, b3=0.05,
        att=0.002, d1=0.10, d1l=0.25, d2=3.8, d2s=7.5, pr=0.45, rel=0.55,
        va=0.30, trem_r=5.5, trem_d=0.15,
        noise=0.003, noise_d=50.0, noise_peak=6.0, noise_hi=0.5,
        spec_b=0.35, spec_tau=0.020, drive=0.02,
        formant_freqs="1500,3500", formant_gains="0.22,0.10", formant_qs="2.0,1.5",
        micro=0.6,
    ),
    "marimba": Timbre(
        # Rosewood bars: overtones die extremely fast (b1=2.0) → "woody" thunk.
        # Resonator tube emphasis ~800Hz. Warm fundamental, dry attack.
        n=5, rolloff=0.35, bright=0.35, bright_lo=0.50, bright_hi=0.22, hammer_hard=2.0,
        b1=2.0, b3=0.35,
        att=0.001, d1=0.03, d1l=0.04, d2=1.4, rel=0.10,
        va=0.5, vn=0.5,
        noise=0.015, noise_d=80.0, noise_peak=6.0, noise_hi=0.6,
        spec_b=0.65, spec_tau=0.005, drive=0.03,
        formant_freqs="800", formant_gains="0.28", formant_qs="1.5",
        micro=0.35,
    ),
    "default": Timbre(
        n=8, rolloff=1.0, bright=0.35, vel_bright=0.15,
        strike_pos=0.12, strike_depth=0.25, b1=0.50, b3=0.08,
        att=0.005, d1=0.20, d1l=0.30, d2=1.5, rel=0.20,
        va=0.3, vn=0.3, ps=0.08, pdm=1.3, det_c=1.2, det_m=0.05,
        noise=0.004, noise_d=40.0, noise_peak=8.0, noise_hi=0.5, drive=0.05, micro=0.3,
    ),
}
