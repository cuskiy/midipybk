import numpy as np

SR = 44100
A4 = 440.0
MAX_DET = 5
TUNE = {1: [1.0], 2: [0.9997, 1.0003], 3: [1.0001, 1.0003, 0.9996]}

def pr(f): return np.clip((np.log2(f / 261.63) + 2) / 4, 0, 1)
def lf(f): return np.clip(1 - pr(f), 0, 1)
def vc(v): return v ** 0.65

_FIELDS = dict(
    n=10, rolloff=1.0, bright=0.3, bright_lo=0.0, bright_hi=0.0, hammer_hard=0.0,
    vel_bright=0.0, strike_pos=0.0, strike_depth=0.0,
    noise=0.0, noise_d=30.0, noise_peak=8.0, noise_hi=0.0, vn=0.5,
    inh=0.0, inh_stretch=0.0, b1=0.50, b3=0.08, rel_damp=0.0,
    coupling=0.0, phantom=0.0, n_strings=1, n_extra=0,
    spec_b=0.0, spec_tau=0.015, drive=0.0,
    att=0.005, d1=0.4, d1l=0.35, d2=2.0, d2s=0.0, pr=1.0, rel=0.3,
    va=0.5, vd=0.3, ps=0.0, pdm=1.0, det_c=0.0, det_m=0.0,
    vib_r=5.0, vib_d=0.0, vib_del=0.3, trem_r=0.0, trem_d=0.0,
    sub=0.0, sub_third=0.0, live=0.0,
    fc_base=0.0, fc_min=0.3, hammer_p=2.5, fc_alpha=2.0, decay_exp=0.0,
    micro=0.5, even_atten=0.0, key_click=0.0,
    ks_lp=0.0, ks_click=0.0,
    formant_freqs="", formant_gains="", formant_qs="",
    harm_amps="",
    bow_noise=0.0, breath_noise=0.0, lip_shape=0.0, tw_leak=0.0,
)

class Timbre:
    __slots__ = tuple(_FIELDS.keys())
    def __init__(self, **kw):
        for k, v in _FIELDS.items(): setattr(self, k, kw.get(k, v))
    def copy(self, **ov):
        return Timbre(**{k: ov.get(k, getattr(self, k)) for k in self.__slots__})
    def eff_bright(self, vc):
        if self.hammer_hard > 0:
            t = 1 - np.exp(-self.hammer_hard * vc)
            return self.bright_lo + (self.bright_hi - self.bright_lo) * t
        if self.vel_bright > 0: return self.bright * (1 - self.vel_bright * vc * 0.5)
        return self.bright
    def eff_fc(self, vc):
        if self.fc_base <= 0: return 0.0
        return self.fc_base * (self.fc_min + (1 - self.fc_min) * vc ** self.hammer_p)
    def ref_amp(self):
        s = 0.0
        if self.harm_amps:
            s = max(sum(float(x) for x in self.harm_amps.split(",")), 0.01)
        else:
            s = sum((1/k**self.rolloff) * np.exp(-self.bright*(k-1)) *
                    (1 - self.strike_depth*(1 - abs(np.sin(k*np.pi*self.strike_pos)))
                     if self.strike_pos > 0 else 1)
                    for k in range(1, self.n+1))
        s += self.sub + self.sub_third
        return max(s, 0.01)
