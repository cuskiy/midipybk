"""Single source of truth for project version.

Keep this file import-free — it is read by pyproject.toml's dynamic
version attribute at build time, and importing numpy/scipy from here
would drag the full dep tree into `pip install` build isolation.
"""
VERSION_PUBLIC = "1.95.0"         # PEP 440 form used by pyproject
VERSION = f"v{VERSION_PUBLIC.split('.')[0]}{VERSION_PUBLIC.split('.')[1]}"

PROJECT_NAME = "GoldenScore"
