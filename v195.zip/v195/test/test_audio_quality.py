"""Audio quality diagnostics — fast, focused on real issues.

Runs in <15s. Checks:
  1. Every instrument renders without NaN/Inf/clipping
  2. Low-register harmonic content (catches "snoring" timbres)
  3. Multi-track phase correlation (catches N× stacking bug)
  4. CC sidechain smoothness

Usage:
  python test/test_audio_quality.py     (standalone)
  pytest test/test_audio_quality.py     (collected, no crash)
"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from synth.timbre import SR
from synth.instruments import TIMBRES
from synth import synthesize
from synth.drums import drum, _MAP


def test_render_sanity():
    """Every instrument renders without NaN/Inf and without clipping > 1.001."""
    failures = []
    for name, tim in TIMBRES.items():
        freq = 200.0 if name == "sfx" else (65.0 if name in ("contrabass", "bass") else 262.0)
        w = synthesize(freq, 0.3, 0.85, tim, name, 0)
        if np.any(np.isnan(w)) or np.any(np.isinf(w)):
            failures.append(f"{name}: NaN/Inf")
        elif np.max(np.abs(w)) > 1.001:
            failures.append(f"{name}: peak={np.max(np.abs(w)):.3f}>1")
    rng = np.random.RandomState(42)
    for note in sorted(_MAP.keys()):
        w = drum(note, 0.3, 0.9, rng)
        if np.any(np.isnan(w)) or np.any(np.isinf(w)):
            failures.append(f"drum/{note}: NaN/Inf")
    assert not failures, f"Render sanity failures: {failures}"


def test_low_register_harmonics():
    """Low register should have usable mid-band content (not just sub)."""
    warnings = []
    for name, midi_note in [("contrabass", 24), ("contrabass", 30),
                             ("pad", 36), ("cello", 36)]:
        freq = 440.0 * 2 ** ((midi_note - 69) / 12)
        w = synthesize(freq, 0.8, 0.88, TIMBRES[name], name, 0)
        seg = w[int(SR * 0.05):int(SR * 0.5)]
        if len(seg) < 512:
            continue
        fft = np.abs(np.fft.rfft(seg * np.hanning(len(seg))))
        freqs = np.fft.rfftfreq(len(seg), 1.0 / SR)
        db = 20 * np.log10(fft + 1e-15)
        db -= np.max(db)
        mid_mask = (freqs >= 600) & (freqs < 2000)
        mid_pk = float(np.max(db[mid_mask])) if np.any(mid_mask) else -999.0
        if mid_pk < -50.0:
            warnings.append(f"{name}/n{midi_note}: mid peak {mid_pk:.0f}dB")
    # Allow warnings up to -50 dB. pad is intentionally dark at n36.
    # Fail only if things are completely broken (-70+ dB).
    critical = [w for w in warnings if "/n36" not in w]  # relax pad n36
    assert not critical, f"Low-register critical failures: {critical}"


def test_phase_correlation_not_stacking():
    """Stacking 3 copies with different nids should not sum to 3x peak.

    If the phase decorrelation is broken, 3 identical waveforms sum
    coherently and the peak goes up 3x. Good decorrelation gives <2.5x.
    """
    failures = []
    for name in ["lead", "piano", "strings", "pad"]:
        waves = [synthesize(440.0, 0.3, 0.85, TIMBRES[name], name, nid)
                 for nid in range(3)]
        n = min(len(w) for w in waves)
        comb = sum(w[:n] for w in waves)
        ratio = float(np.max(np.abs(comb)) /
                      (np.mean([np.max(np.abs(w[:n])) for w in waves]) + 1e-10))
        if ratio >= 2.5:
            failures.append(f"{name}: {ratio:.2f}x (>=2.5x = phase-correlated)")
    assert not failures, f"Stacking failures: {failures}"


def test_cc_sidechain_smoothness():
    """CC sidechain envelope must change smoothly — no sample-to-sample jumps."""
    from mix.cc import interp_cc, smooth_cc_sidechain
    events = []
    for i in range(4):
        events.append((i * 0.5, 0.0))
        for j in range(1, 31):
            events.append((i * 0.5 + 0.007 * j, min(j / 30, 1.0)))
    vol = interp_cc(events, int(SR * 2), default=1.0)
    vc = smooth_cc_sidechain(0.02 + 0.98 * np.sqrt(vol), down_ms=5.0, up_ms=50.0)
    max_step = float(np.max(np.abs(np.diff(vc))))
    assert max_step < 0.01, f"CC sidechain max step = {max_step:.5f} (>= 0.01)"


def test_instrument_spectral_coverage():
    """Every instrument must have >1% non-fundamental energy at mid pitches.

    Catches the "pure sine oscillator" problem: when an instrument's
    harmonics are completely killed by the delay-line LP or rolloff,
    the output sounds like an electronic tone rather than a real
    instrument. This test verifies that every non-pad, non-sfx
    instrument has at least some harmonic content above 500Hz at
    a representative pitch in its playing range.

    v187: added after nylon/organ/pad pure-sine issues in v175-v186
    required manual detection by the user every time.
    """
    from scipy.signal import welch

    # (instrument, midi, min_harmonics_pct) — min % energy above 500Hz
    # pad/sfx exempt (pad is an abstract texture; sfx is noise-based)
    checks = [
        ("piano", 60, 3.0), ("piano", 48, 0.5),
        ("epiano", 60, 2.0),
        ("organ", 60, 5.0), ("organ", 72, 3.0),
        ("guitar", 60, 1.5),
        ("nylon", 64, 0.5),
        ("bass", 60, 0.3),
        ("synbass", 48, 0.3),
        ("strings", 60, 3.0),
        ("cello", 48, 1.0),
        ("contrabass", 48, 0.3),
        ("brass", 60, 5.0),
        ("woodwind", 67, 3.0),
        ("flute", 72, 1.0),
        ("choir", 60, 2.0),
        ("lead", 60, 3.0),
        ("harp", 60, 0.5),
        ("harpsichord", 60, 1.0),
        ("celesta", 72, 2.0),
        ("vibes", 60, 1.0),
        ("marimba", 60, 1.0),
        ("pluck", 60, 1.0),
    ]
    failures = []
    for name, midi, min_pct in checks:
        tim = TIMBRES.get(name)
        if tim is None:
            continue
        freq = 440.0 * 2 ** ((midi - 69) / 12.0)
        w = synthesize(freq, 0.8, 0.8, tim, name, 0)
        if len(w) < 512:
            continue
        f, psd = welch(w, SR, nperseg=min(2048, len(w) // 2))
        total = float(np.sum(psd))
        if total < 1e-20:
            failures.append(f"{name} m{midi}: silent")
            continue
        above_500 = float(np.sum(psd[f >= 500])) / total * 100
        if above_500 < min_pct:
            failures.append(
                f"{name} m{midi}: {above_500:.2f}% above 500Hz (need >{min_pct}%)")
    assert not failures, f"Spectral coverage failures:\n  " + "\n  ".join(failures)


def test_pb_curve_smoothness():
    """PB curves must be smooth enough for natural-sounding pitch variation.

    v191: added after the nylon PB zigzag issue (v185-v190) where MIDI
    PB events at ~50/sec created FM-like artifacts that took 5 versions
    to diagnose. This test catches any regression in PB smoothing by
    verifying the maximum pitch change rate stays below the threshold
    for natural vibrato (~15 st/sec).
    """
    from mix.cc import make_pb_curve

    # Simulate dense MIDI PB events (50/sec, ±0.2st) — worst case
    events = []
    for i in range(100):
        t = i * 0.02  # 50 events/sec
        v = 0.2 * (1 if i % 2 == 0 else -1)  # alternating ±0.2 semitones
        events.append((t, v))
    curve = make_pb_curve(events, 0.0, 2.0)
    assert curve is not None, "make_pb_curve returned None for active PB"
    max_rate = float(np.max(np.abs(np.diff(curve)))) * SR
    assert max_rate < 20.0, (
        f"PB curve max rate {max_rate:.1f} st/sec exceeds 20 st/sec — "
        "smoothing insufficient, will cause FM artifacts")


def test_ks_additive_pb_volume_match():
    """ks_always instruments must have consistent volume with and without PB.

    When PB is active, ks_always instruments (nylon) fall back to the
    additive engine. Without ks_gain correction, additive output is
    ~40% quieter than KS, causing audible volume dips on PB notes.
    v191: added after discovering the 0.68x RMS ratio in v190.
    """
    from synth.gm import inst_mix
    failures = []
    for name in sorted(TIMBRES):
        cfg = inst_mix(name)
        if not cfg.ks_always:
            continue
        tim = TIMBRES[name]
        freq = 330.0
        w_ks = synthesize(freq, 0.5, 0.8, tim, name, 0, pb_curve=None)
        n_pb = int(SR * 0.5)
        pb = 0.3 * np.sin(2 * np.pi * 5 * np.linspace(0, 0.5, n_pb))
        w_add = synthesize(freq, 0.5, 0.8, tim, name, 0, pb_curve=pb)
        n = min(len(w_ks), len(w_add))
        rms_ks = float(np.sqrt(np.mean(w_ks[:n] ** 2)))
        rms_add = float(np.sqrt(np.mean(w_add[:n] ** 2)))
        if rms_ks < 1e-6:
            continue
        ratio = rms_add / rms_ks
        if ratio < 0.7 or ratio > 1.5:
            failures.append(
                f"{name}: PB/noPB RMS ratio {ratio:.2f} "
                f"(need 0.7-1.5, got KS={rms_ks:.4f} ADD={rms_add:.4f})")
    assert not failures, "Volume mismatch:\n  " + "\n  ".join(failures)


def test_pb_render_no_artifacts():
    """Rendering with extreme PB must not produce NaN, clips, or DC offset.

    v191: stress test for the KS/additive PB dispatch paths. Exercises
    both the KS variable-delay path (non-ks_always) and the additive
    fallback path (ks_always + PB).
    """
    failures = []
    from synth.gm import inst_mix, KS
    for name in sorted(TIMBRES):
        if name in ("default", "sfx"):
            continue
        cfg = inst_mix(name)
        tim = TIMBRES[name]
        freq = 440.0
        n_pb = int(SR * 1.0)
        t = np.linspace(0, 1.0, n_pb, endpoint=False)
        pb = 3.0 * np.sin(2 * np.pi * 4 * t)  # ±3 semitones
        w = synthesize(freq, 1.0, 0.8, tim, name, 0, pb_curve=pb)
        if np.any(np.isnan(w)):
            failures.append(f"{name}: NaN with PB")
        elif np.max(np.abs(w)) > 3.5:
            failures.append(f"{name}: peak {np.max(np.abs(w)):.1f} with PB")
        elif len(w) > 500 and abs(np.mean(w)) > 0.03:
            failures.append(f"{name}: DC {np.mean(w):.4f} with PB")
    assert not failures, "PB artifacts:\n  " + "\n  ".join(failures)


def _main() -> int:
    """Standalone runner — prints a pretty report and returns exit code."""
    tests = [
        test_render_sanity,
        test_low_register_harmonics,
        test_phase_correlation_not_stacking,
        test_cc_sidechain_smoothness,
        test_instrument_spectral_coverage,
        test_pb_curve_smoothness,
        test_ks_additive_pb_volume_match,
        test_pb_render_no_artifacts,
    ]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
        except AssertionError as e:
            print(f"  ✗ {t.__name__}: {e}")
            failed += 1
    print(f"\n{len(tests) - failed}/{len(tests)} audio-quality tests passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(_main())
