"""CC interpolation, smoothing, and pitch bend curve generation."""
from typing import Optional, Union
import numpy as np
from scipy.signal import lfilter, lfilter_zi
from synth.timbre import SR


def smooth_cc(curve: np.ndarray, tau_ms: float = 50.0) -> np.ndarray:
    """1-pole LP with zero-transient init. Safe on empty input (#24)."""
    if len(curve) == 0:
        return curve
    alpha = 1.0 - np.exp(-1000.0 / (SR * tau_ms))
    b, a = [alpha], [1.0, -(1.0 - alpha)]
    zi = lfilter_zi(b, a) * curve[0]
    return lfilter(b, a, curve, zi=zi)[0]


def smooth_cc_sidechain(curve: np.ndarray, down_ms: float = 5.0,
                        up_ms: float = 30.0) -> np.ndarray:
    """Asymmetric envelope: fast attack on dips, slow release."""
    if len(curve) == 0:
        return curve
    fast = smooth_cc(curve, tau_ms=down_ms)
    slow = smooth_cc(curve, tau_ms=up_ms)
    return np.minimum(fast, slow)


def interp_cc(events: list, mx: int,
              default: float = 1.0) -> Union[float, np.ndarray]:
    """True zero-order hold via searchsorted.

    Returns a **scalar float** when ``events`` is empty (#17 fix: avoid
    the 100+ MB full-buffer allocation for unused CC channels), and an
    ``np.ndarray`` of length ``mx`` otherwise.

    GM CC values take effect at their event time and hold until the next
    event. The v158 ``_LATE_EVENT_THRESH=0.1`` look-ahead window has
    been removed (#5 fix): it produced a 0.113 prelude-value jump for
    a 20 ms input-time shift — pure magic-number pollution.
    """
    if not events:
        return float(default)

    # v192: short-circuit for constant channels. Most CC channels have
    # exactly one event at t=0. Allocating full-buffer arange + searchsorted
    # for a constant wastes ~30MB per call on a 3-minute song.
    if len(events) == 1 and events[0][0] <= 0.0:
        return float(events[0][1])

    times = np.fromiter((t for t, _ in events), dtype=np.float64, count=len(events))
    vals = np.fromiter((v for _, v in events), dtype=np.float64, count=len(events))

    # Prelude (t < first event time) is ALWAYS the default, unless a
    # real event exists at t <= 0.
    init = vals[0] if times[0] <= 0.0 else default

    t_arr = np.arange(mx, dtype=np.float64) / SR
    idx = np.searchsorted(times, t_arr, side='right') - 1
    out = np.empty(mx, dtype=np.float64)
    pre_mask = idx < 0
    out[pre_mask] = init
    valid = ~pre_mask
    out[valid] = vals[idx[valid]]
    return out


def interp_cc_array(events: list, mx: int,
                    default: float = 1.0) -> np.ndarray:
    """Always-ndarray wrapper around interp_cc.

    Use when downstream code cannot handle the scalar short-circuit path.
    Prefer interp_cc + isinstance check when possible.
    """
    result = interp_cc(events, mx, default)
    if isinstance(result, np.ndarray):
        return result
    return np.full(mx, result, dtype=np.float64)


def make_pb_curve(pb_events: list, start: float, dur: float) -> Optional[np.ndarray]:
    """Per-sample pitch bend curve in semitones for one note.

    v190: output is smoothed with a gentle 8ms LP. MIDI files often
    encode vibrato as rapid PB events (~50/sec), creating a zigzag
    that sounds like FM modulation artifacts rather than natural pitch
    variation. 8ms smoothing rounds the corners without affecting
    musical gestures (portamento, slow bends).
    """
    if not pb_events:
        return None
    end = start + dur
    init_val = 0.0
    for t, v in pb_events:
        if t <= start + 1e-6:
            init_val = v
        else:
            break
    margin = 0.002
    during = [(t, v) for t, v in pb_events if start - 1e-6 <= t <= end + margin]
    final_val = init_val
    for _, v in during:
        final_val = v
    all_vals = [init_val] + [v for _, v in during]
    if all(abs(v) < 0.01 for v in all_vals):
        return None
    n = int(SR * dur)
    if n == 0:
        return None
    ts = [0.0]
    vs = [init_val]
    for t, v in during:
        rt = max(0.0, min(t - start, dur))
        if ts and abs(rt - ts[-1]) < 1e-9:
            vs[-1] = v
        else:
            ts.append(rt)
            vs.append(v)
    if ts[-1] < dur - 1e-6:
        ts.append(dur)
        vs.append(final_val)
    t_arr = np.linspace(0, dur, n, endpoint=False)
    curve = np.interp(t_arr, ts, vs)
    # v190: smooth the PB curve. MIDI pitch bend events are typically
    # sparse (~6-20ms apart), and np.interp produces a zigzag that at
    # ~50 events/sec sounds like FM modulation artifacts rather than
    # natural pitch variation. A 20ms LP smooths the zigzag into gentle
    # curves without affecting intentional slides (a 2-semitone slide
    # over 500ms is barely affected).
    if n > 64:
        curve = smooth_cc(curve, tau_ms=20.0)
    return curve
